package com.abrothers.swiftplayer

import android.content.Context
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Safe active tests use isolated files/preferences and a muted player. User media is never deleted or renamed. */
object SwiftPlayerTester {
    data class Finding(val state:String,val feature:String,val detail:String,val action:String="")
    internal var playbackProbe:((Context,File)->List<Finding>)?=null
    internal var apkProbe:((GitHubRepository.Snapshot,File)->Unit)?=null
    enum class Mode(val label:String) {
        FULL("Full player scan"), PLAYBACK("Playback and controls"), ACCESS("Storage and permissions"), UPDATE("GitHub update and signature")
    }
    fun scan(context:Context,mode:Mode=Mode.FULL):File {
        check(AppLog.enabled(context)) { "Check Test all bugs and features in this app before scanning" }
        val results=mutableListOf<Finding>()
        val sandbox=File(context.cacheDir,"swift-tester-${System.nanoTime()}").apply { mkdirs() }
        val prefsName="swift_tester_${System.nanoTime()}"
        val prefs=PlayerPrefs(context,prefsName)
        val repo=MediaRepository(context,prefs)
        fun check(feature:String,action:String,run:()->String) {
            runCatching(run).onSuccess { results.add(Finding("CHECKED",feature,it)) }
                .onFailure { results.add(Finding(if(feature.startsWith("Video decoding"))"NOT VERIFIED" else "PROBLEM",feature,it.message ?: it.javaClass.simpleName,action));AppLog.record(context,feature,it) }
        }
        val playback=mode==Mode.FULL || mode==Mode.PLAYBACK
        val storage=mode==Mode.FULL || mode==Mode.ACCESS
        val update=mode==Mode.FULL || mode==Mode.UPDATE
        try {
            if(storage || playback)check("Audio and video list filtering","Rescan the folder and check media permission.") {
                val nested=File(sandbox,"Parent/Child").apply { mkdirs() }
                File(nested,"sample.mp3").writeText("test")
                File(sandbox,"ignore.txt").writeText("test")
                val audio=repo.list(sandbox.absolutePath,"audio",true)
                require(audio.size==1 && audio[0].name=="sample.mp3") { "Audio list is not filtering the test folder correctly." }
                val folders=repo.list(sandbox.absolutePath,"audio",false)
                require(folders.size==1 && folders[0].name=="Parent") { "Browse Folders is showing incorrect folder levels." }
                require(repo.video.all { repo.matches("sample.$it","video") } && repo.audio.all { repo.matches("sample.$it","audio") })
                "Nested audio folders and file-extension filters work in the private test folder. Real library access is checked separately."
            }
            if(playback)check("Settings and toggle storage","Settings may not be saving. Reopen the app and send this report.") {
                val keys=listOf("background","autoPlay","showSpeed","showBoost","showSleep","bypass","multiSelect","autoUpdate","playAppSounds","showWhatsApp","waOfficial","waBusiness","wa_official_audio","wa_official_video","wa_official_voice","wa_official_statuses","wa_business_audio","wa_business_video","wa_business_voice","wa_business_statuses","voiceNotesInAll","statusImages","statusVideos")
                keys.forEach { key -> prefs.put(key,true);require(PlayerPrefs(context,prefsName).bool(key,false));prefs.put(key,false);require(!PlayerPrefs(context,prefsName).bool(key,true)) }
                prefs.speed=1.5f;require(PlayerPrefs(context,prefsName).speed==1.5f)
                prefs.ff=27000L;prefs.durations=prefs.durations+27000L
                require(PlayerPrefs(context,prefsName).ff==27000L && 27000L in prefs.durations)
                "Both states of ${keys.size} settings, custom seek time and playback-speed persistence work in an isolated store. This does not prove each toggle's visible effect."
            }
            if(storage)check("More Options: Rename and Delete","File changes failed even in a private test folder. Real external files may also need Android permission.") {
                val first=File(sandbox,"original.mp3").apply { writeText("original data") }
                val updated=repo.rename(repo.fromFile(first),"renamed.mp3")
                require(File(updated.location).readText()=="original data") { "Rename changed or lost test data." }
                File(sandbox,"existing.mp3").writeText("keep")
                require(runCatching { repo.rename(updated,"existing.mp3") }.exceptionOrNull() is DuplicateNameException) { "Rename is not blocking duplicate names." }
                require(File(sandbox,"existing.mp3").readText()=="keep")
                require(repo.delete(updated)) { "Delete did not remove the private test file." }
                "Rename, duplicate-name protection and Delete work on private test files. External provider permissions still need a real-file test."
            }
            if(playback)check("Favorites and last-resume data","Saved playback or favorites are not being restored. Send this report.") {
                val item=MediaEntry(File(sandbox,"resume.mp3").absolutePath,"resume.mp3")
                require(prefs.toggleFavorite(item));require(PlayerPrefs(context,prefsName).favorite(item))
                prefs.put("queue",MediaEntry.encode(listOf(item)));prefs.put("lastPosition",23456L)
                val restored=PlayerPrefs(context,prefsName)
                require(restored.long("lastPosition")==23456L && MediaEntry.decode(restored.str("queue")).first()==item)
                "Favorite and exact timestamp data survive reopening the isolated settings store. Reopening actual media after app exit still needs manual verification."
            }
            val sample=File(sandbox,"playback-sample.aac")
            if(playback)check("Startup and Exit sound assets","Reinstall the original signed APK if a bundled sound cannot be decoded.") {
                val start=ProtectedAssets.bytes(context,"s");val exit=ProtectedAssets.bytes(context,"e")
                try { require(start.isNotEmpty() && exit.isNotEmpty());sample.writeBytes(start) }
                finally { start.fill(0);exit.fill(0) }
                "Both protected sound files authenticate and can be read. The active playback check below tests the startup AAC silently."
            }
            if(sample.isFile)results.addAll(playbackProbe?.invoke(context,sample) ?: testPlayback(context,sample))
            if(playback && playbackProbe==null)check("Video decoding and seek","Try a standard H.264 MP4 on this phone.") {
                val video=File(sandbox,"sample.mp4")
                context.assets.open("tester/sample.mp4").use { input -> video.outputStream().use { input.copyTo(it) } }
                val decoder=android.media.MediaMetadataRetriever()
                try {
                    decoder.setDataSource(video.absolutePath)
                    val frame=decoder.getFrameAtTime(1_000_000,android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                    check(frame!=null) { "The device did not return a video frame from the test MP4." }
                    frame.recycle()
                } finally { decoder.release() }
                "Android decoded a frame after seeking in the bundled H.264 sample. Full-screen rendering is not covered by this probe."
            }
            if(storage)check("Sort, search, WhatsApp filtering and share URI","Check media browsing settings and repeat the scan.") {
                val folder=File(sandbox,"Parent/Child")
                val first=repo.fromFile(File(folder,"sample.mp3"));val second=first.copy(name="Another.mp3")
                require(repo.sorted(listOf(first,second),"A-Z").first()==second)
                require(repo.sorted(listOf(first,second),"Z-A").first()==first)
                require(repo.list(sandbox.absolutePath,"audio",true).any { it.name.contains("sample",true) })
                val voice=first.copy(diskPath="/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes/PTT.opus")
                prefs.put("voiceNotesInAll",false);require(!repo.allowedInAllFiles(voice))
                prefs.put("voiceNotesInAll",true);require(repo.allowedInAllFiles(voice))
                val shared=repo.shareUri(first)
                try { require(shared.scheme=="content" && context.contentResolver.openInputStream(shared)?.use { it.read() }!=null) }
                finally { context.getSharedPreferences("shared_files",Context.MODE_PRIVATE).edit().remove(shared.pathSegments.first()).apply() }
                "Sort order, file discovery, voice-note exclusion and reading a granted share URI were checked without launching another app."
            }
            if(update)check("Private download filenames and update rules","Check app storage and version.txt.") {
                val original="How to use Swift Player created by A brothers.mp3"
                require(PrivateDownloads.target(sandbox,original).name==original)
                require(runCatching { PrivateDownloads.target(sandbox,"../outside.apk") }.isFailure)
                require(UpdateVersion.newer(UpdateVersion.parse("2.0"),0,"1.0"))
                require(!UpdateVersion.newer(UpdateVersion.parse("versionName=1.0\nversionCode=999"),0,"1.0"))
                "Exact filename handling and version-only update comparison passed. No download or installer was launched by this check."
            }
            if(storage)probeGrantedStorage(context,results)
            if(update) {
            val network=java.util.concurrent.Executors.newSingleThreadExecutor()
            val future=network.submit<Finding> {
                val scratch=File.createTempFile("tester-update-",".apk",context.cacheDir)
                try {
                    val snapshot=GitHubRepository.discover()
                    if(apkProbe!=null)apkProbe!!.invoke(snapshot,scratch) else fetchApk(snapshot,scratch)
                    ApkArchive.validate(scratch)
                    if(apkProbe==null) ReleaseIdentity.verify(context,scratch)
                    Finding(if(apkProbe==null) "CHECKED" else "NOT VERIFIED","GitHub download",if(apkProbe==null) "Downloaded APK structure, package and signing certificate match the installed application. Play Protect and installation were not run." else "Only the synthetic APK fixture structure was checked.")
                } catch(e:Exception) {
                    val malformed=e is IllegalArgumentException && e.message.orEmpty().contains("APK",true) && !(e.message.orEmpty().contains("HTTP") || e.message.orEmpty().contains("timed out"))
                    Finding(if(malformed)"PROBLEM" else "NOT VERIFIED","GitHub download",e.message.orEmpty(),"Check network or replace a damaged repository APK with the original signed release.")
                } finally { scratch.delete() }
            }
            try { results.add(future.get(18L,TimeUnit.SECONDS)) }
            catch(e:java.util.concurrent.TimeoutException) { results.add(Finding("NOT VERIFIED","GitHub download","The network check exceeded its time budget; this does not indicate an app defect.")) }
            finally { future.cancel(true);network.shutdownNow() }
            }
            val existing=runCatching { AppLog.scan(context,false).readText() }.getOrDefault("Device permission details could not be collected.")
            val recorded=File(context.filesDir,"app-log-errors.txt").takeIf { it.isFile }?.readText().orEmpty()
            val report=StringBuilder()
            report.append("Mobile model: ${Build.MODEL}\n")
            report.append("Brand/Company: ${Build.MANUFACTURER} / ${Build.BRAND}\n")
            report.append("Android version: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            val processor=if(Build.VERSION.SDK_INT>=31)"${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "${Build.HARDWARE} / ${Build.BOARD}"
            report.append("Processor: $processor\nApplication: ${context.getString(R.string.app_name)}\nVersion: ${BuildConfig.VERSION_NAME}\n\nSWIFT PLAYER TESTER\n")
            report.append("Scan: ${mode.label}\n\n")
            report.append("Your files and settings were not changed. Playback tests used a separate silent sample. Nothing is uploaded automatically.\n\n")
            val problems=results.filter { it.state=="PROBLEM" }
            report.append("PROBLEMS FOUND\n")
            if(problems.isEmpty())report.append("No problem was found in the active checks below. This does not mean every feature is bug-free.\n")
            problems.forEachIndexed { index,f -> report.append("${index+1}. ${f.feature}\nWhat happened: ${f.detail}\nWhat to do: ${f.action}\n\n") }
            report.append("FEATURE CHECK RESULTS\n")
            results.filterNot { it.state=="PROBLEM" }.forEach { report.append("[${it.state}] ${it.feature}\n${it.detail}\n\n") }
            report.append("TEST THESE WITH YOUR PHONE\n")
            listOf(
                "File-list clicks and TalkBack/Jieshuo focus: open a folder and double-tap a file; it should act like a button and keep its extension.",
                "Playback Speed and Volume Boost UI: select a value and check that both the visible label and spoken label match. Normal means 1.0x.",
                "Video and full screen: play an actual video, enter landscape, seek and return. The decoder check does not exercise a physical video surface.",
                "Completion replay: listen to the end of your file and press Play; it should restart at 00:00. The separate sample tests decoder replay, not every user file.",
                "More Options Share, WhatsApp sharing/saving, notifications, sleep-timer expiry and launching another app need your interaction; the tester does not post/share anything automatically.",
                "Bluetooth Bypass: another screen reader's actual output cannot be inspected or forced by this test.",
                "Sounds checkbox: verify normal startup, Exit and Open with Back with the setting checked and unchecked.",
                "Permissions and installation: Android may require file access or installer confirmation. A test cannot grant those permissions silently."
            ).forEach { report.append("[MANUAL TEST NEEDED] $it\n\n") }
            if(recorded.isNotBlank()) {
                report.append("RECORDED ERRORS — DEVELOPER DETAILS\n")
                report.append("If playback stopped, describe the file format and action. If Rename/Delete failed, the source provider may be read-only. If the update failed, check the APK published in GitHub.\n")
                report.append("Historical entries are not results of this scan.\n")
                report.append(recorded.takeLast(64000)).append('\n')
            }
            report.append("DEVICE PERMISSIONS AND TECHNICAL CHECKS\n").append(existing)
            val folder=File(context.filesDir,"tester-reports").apply { mkdirs() }
            val file=File(folder,"Swift-Player-Tester-${System.currentTimeMillis()}.txt").apply { writeText(report.toString()) }
            folder.listFiles()?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
            return file
        } finally { repo.close();sandbox.deleteRecursively();prefs.raw.edit().clear().commit();context.deleteSharedPreferences(prefsName) }
    }
    private fun probeGrantedStorage(context:Context,results:MutableList<Finding>) {
        val resolver=context.contentResolver
        val signal=android.os.CancellationSignal()
        val timer=Handler(android.os.Looper.getMainLooper())
        val cancel=Runnable { signal.cancel() };timer.postDelayed(cancel,3500L)
        try {
            val collections=listOf("Audio library" to android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                "Video library" to android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                "Image library" to android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            for((label,collection) in collections) {
                val state=runCatching {
                    resolver.query(collection,arrayOf("_id"),null,null,null,signal)?.use { cursor ->
                        if(!cursor.moveToFirst())return@use "No visible indexed files under the current grant."
                        val item=android.content.ContentUris.withAppendedId(collection,cursor.getLong(0))
                        resolver.openFileDescriptor(item,"r",signal)?.use { descriptor ->
                            "An indexed file opened read-only using existing access (size ${descriptor.statSize} bytes if known)."
                        } ?: "The provider did not open the sample read-only."
                    } ?: "Provider unavailable."
                }
                val detail=state.getOrNull() ?: when(state.exceptionOrNull()) {
                    is SecurityException -> "Current permissions do not allow this read; no new access was requested."
                    else -> "The provider did not complete the requested check."
                }
                results.add(Finding(if(detail.startsWith("An indexed file"))"CHECKED" else "NOT VERIFIED",label,detail))
            }
            val trees=resolver.persistedUriPermissions.filter { it.isReadPermission && android.provider.DocumentsContract.isTreeUri(it.uri) }.take(4)
            for(grant in trees) {
                val readable=runCatching {
                    val doc=android.provider.DocumentsContract.buildDocumentUriUsingTree(grant.uri,android.provider.DocumentsContract.getTreeDocumentId(grant.uri))
                    resolver.query(doc,arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID),null,null,null,signal)?.use { it.moveToFirst() }==true
                }.getOrDefault(false)
                results.add(Finding(if(readable)"CHECKED" else "NOT VERIFIED","Saved folder grant", "Provider readable: $readable; write grant recorded by Android: ${grant.isWritePermission}. No real files changed."))
            }
            val all=Build.VERSION.SDK_INT>=30 && runCatching { android.os.Environment.isExternalStorageManager() }.getOrDefault(false)
            if(all) {
                val root=android.os.Environment.getExternalStorageDirectory()
                val available=runCatching { root.list()!=null }.getOrDefault(false)
                results.add(Finding(if(available)"CHECKED" else "NOT VERIFIED","Shared-storage grant","Root directory listing available: $available. Names are not included in the report."))
            }
        } finally { timer.removeCallbacks(cancel) }
    }
    private fun fetchApk(snapshot:GitHubRepository.Snapshot,target:File) {
        val c=URL(snapshot.apk.url).openConnection() as HttpURLConnection
        c.connectTimeout=7000;c.readTimeout=7000;c.useCaches=false
        c.setRequestProperty("User-Agent","Swift-Player-Tester")
        val started=android.os.SystemClock.elapsedRealtime()
        try {
            require(c.responseCode==200) { "APK download failed with HTTP ${c.responseCode}." }
            c.inputStream.use { input -> target.outputStream().use { output ->
                val buffer=ByteArray(32768);var bytes=0L
                while(true) {
                    check(!Thread.currentThread().isInterrupted)
                    require(android.os.SystemClock.elapsedRealtime()-started<10000) { "APK download test timed out. Check your internet connection." }
                    val n=input.read(buffer);if(n<0)break;bytes+=n
                    require(bytes<=32L*1024*1024) { "Published APK is too large for the automatic tester download. Test it with Check for update." }
                    output.write(buffer,0,n)
                }
            } }
            require(GitHubRepository.gitBlob(target)==snapshot.apk.sha) { "Downloaded bytes do not match the APK published in the checked repository commit." }
        } finally { c.disconnect() }
    }
    private fun testPlayback(context:Context,sample:File):List<Finding> {
        val result=java.util.concurrent.CopyOnWriteArrayList<Finding>()
        val finished=CountDownLatch(1)
        val thread=HandlerThread("SwiftTesterPlayback").apply { start() }
        val handler=Handler(thread.looper)
        var engine:PlaybackEngine?=null
        var replay=false
        handler.post {
            try {
                val player=Media3PlaybackEngine(context,"media");engine=player
                player.setVolume(0f,0f)
                player.open(Uri.fromFile(sample),{
                    try {
                        player.playbackSpeed=1.5f
                        require(kotlin.math.abs(player.playbackSpeed-1.5f)<0.01f)
                        result.add(Finding("CHECKED","Playback Speed","The separate silent player accepted and returned 1.5x."))
                        player.seekTo(200);player.start()
                        handler.postDelayed({
                            runCatching {
                                require(player.currentPosition>200) { "Player is not moving forward on the bundled AAC sample." }
                                player.pause();result.add(Finding("CHECKED","Play, Pause and Seek","The silent AAC sample moved after a seek and accepted Pause."))
                                runCatching {
                                    require(player.audioSessionId>0) { "Android did not expose an audio session for this test." }
                                    val effect=LoudnessEnhancer(player.audioSessionId)
                                    try { for(gain in intArrayOf(0,1200,2500,4000)) { effect.setTargetGain(gain);effect.enabled=gain!=0 } }
                                    finally { effect.release() }
                                }.onSuccess { result.add(Finding("CHECKED","Volume Boost backend","All four gain stages were accepted on the muted test session.")) }
                                    .onFailure { result.add(Finding("MANUAL TEST NEEDED","Volume Boost",it.message.orEmpty(),"Try Volume Boost on your playing file; some devices do not expose audio effects for the test session.")) }
                                player.seekTo((player.duration-100).coerceAtLeast(0));player.start()
                            }.onFailure { result.add(Finding("PROBLEM","Player playback",it.message.orEmpty(),"Try a known working file and send this report."));finished.countDown() }
                        },450)
                    } catch(e:Exception) { result.add(Finding("PROBLEM","Player playback",e.message.orEmpty(),"Reopen the file and send this report."));finished.countDown() }
                },{
                    if(!replay) {
                        replay=true;player.seekTo(0);player.start()
                        handler.postDelayed({
                            if(player.currentPosition>0)result.add(Finding("CHECKED","Decoder replay after completion","The silent sample restarted from the beginning after completing."))
                            else result.add(Finding("PROBLEM","Replay after completion","Player did not move after restarting the silent sample.","Send this report and the affected file type."))
                            finished.countDown()
                        },350)
                    }
                },{ detail -> result.add(Finding("PROBLEM","Player is not playing the test sample",detail,"Check device media decoder support and send this report."));finished.countDown() })
            } catch(e:Exception) { result.add(Finding("PROBLEM","Playback test",e.message.orEmpty(),"Try a media file manually and send this report."));finished.countDown() }
        }
        try {
            if(!finished.await(7,TimeUnit.SECONDS))result.add(Finding("MANUAL TEST NEEDED","Playback probe","The silent decoder test did not finish within seven seconds.","Try playback, seeking and replay manually; a timeout alone does not prove the player is broken."))
        } finally {
            handler.post { runCatching { engine?.release() };thread.quitSafely() }
        }
        return result.toList()
    }
}
