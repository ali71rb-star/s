package com.abrothers.swiftplayer

import android.Manifest
import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaCodecList
import android.os.Build
import android.os.Environment
import android.view.accessibility.AccessibilityManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local, opt-in diagnostics. Never uploads device information or claims to find every bug. */
object AppLog {
    private val lock=Any()
    fun enabled(context:Context)=PlayerPrefs(context).bool("appLog",false)
    fun enable(context:Context,value:Boolean) { PlayerPrefs(context).put("appLog",value) }
    private fun stamp()=SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z",Locale.US).format(Date())
    fun record(context:Context,area:String,error:Throwable) {
        if(!enabled(context))return
        runCatching { synchronized(lock) {
            val file=File(context.filesDir,"app-log-errors.txt")
            val old=if(file.isFile)file.readText().takeLast(96000) else ""
            val stack=android.util.Log.getStackTraceString(error).take(12000)
            file.writeText((old+"\n[${stamp()}] $area\n$stack\n").takeLast(128000))
        } }
    }
    private fun recommendation(error:String):String=when {
        error.contains("SecurityException",true) || error.contains("permission",true) -> "Check Permission Manager and original provider write access. Use Android consent for editable MediaStore files; read-only providers must be changed in their owner app."
        error.contains("GitHub",true) || error.contains("HTTP",true) || error.contains("network",true) -> "Check internet access, GitHub status/rate limit, repository version.txt, APK availability, package identity and signing key."
        error.contains("codec",true) || error.contains("Playback",true) -> "Try the same file again and another known working file. Verify the device decoder supports the codec; send this log with reproduction steps."
        error.contains("asset",true) || error.contains("startup",true) -> "Verify packaged protected assets and startup lifecycle. Startup must remain visible until its cue completes."
        else -> "Review this stack trace at the first Swift Player frame. Reproduce the exact action and send this log with the affected screen and steps."
    }
    fun scan(context:Context,includeNetwork:Boolean=true):File {
        check(enabled(context)) { "Enable Swift Player Tester before scanning" }
        val out=StringBuilder()
        fun line(s:String="") { out.append(s).append('\n') }
        fun result(level:String,area:String,detail:String,fix:String="") {
            line("[$level] $area");line("Details: $detail")
            if(fix.isNotBlank())line("Action to fix: $fix")
            line()
        }
        line("SWIFT PLAYER — DEVICE CHECK DETAILS");line("Generated: ${stamp()}")
        line("Purpose: local troubleshooting only. Nothing is uploaded automatically.")
        line("Scope: current device configuration, permissions, assets, decoders, updates and recorded errors.")
        line("This scan cannot discover every bug, inspect other apps' private logs, or prove TalkBack/Bluetooth routing.")
        line();line("DEVICE AND APPLICATION")
        line("Application: ${context.getString(R.string.app_name)}")
        line("Package: ${context.packageName}")
        line("Version: ${BuildConfig.VERSION_NAME}; internal build: ${BuildConfig.VERSION_CODE}")
        line("Brand/Company: ${Build.MANUFACTURER} / ${Build.BRAND}")
        line("Model: ${Build.MODEL}; Device: ${Build.DEVICE}")
        line("Android: ${Build.VERSION.RELEASE}; API: ${Build.VERSION.SDK_INT}; Security patch: ${Build.VERSION.SECURITY_PATCH}")
        val processor=if(Build.VERSION.SDK_INT>=31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "${Build.HARDWARE} / ${Build.BOARD}"
        line("Processor: $processor");line("CPU ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        line("App storage free bytes: ${context.filesDir.usableSpace}");line()
        val permissions=if(Build.VERSION.SDK_INT>=33)listOf(Manifest.permission.READ_MEDIA_AUDIO,Manifest.permission.READ_MEDIA_VIDEO,Manifest.permission.POST_NOTIFICATIONS)
            else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        permissions.forEach { permission ->
            val granted=context.checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED
            result(if(granted)"PASS" else "WARNING",permission.substringAfterLast('.'),if(granted)"Granted" else "Not granted; URI-granted files may still work.",if(granted)"" else "Open Permission Manager if this capability is needed.")
        }
        if(Build.VERSION.SDK_INT>=30) {
            val granted=runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
            result(if(granted)"PASS" else "INFO","All files access",granted.toString(),if(granted)"" else "Grant only if filesystem browsing/editing is needed. This does not override every provider.")
        }
        result("INFO","Saved provider access","Persisted read grants: ${context.contentResolver.persistedUriPermissions.count { it.isReadPermission }}; write grants: ${context.contentResolver.persistedUriPermissions.count { it.isWritePermission }}","A received read-only URI cannot be upgraded silently. Use a provider's supported consent flow.")
        listOf("g" to "Markhor image","s" to "Startup sound","e" to "Exit sound").forEach { (id,name) ->
            runCatching {
                val bytes=ProtectedAssets.bytes(context,id)
                try {
                    check(bytes.isNotEmpty()) { "Asset is empty" }
                    if(id=="g") {
                        val options=BitmapFactory.Options().apply { inJustDecodeBounds=true }
                        BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
                        check(options.outWidth>0 && options.outHeight>0) { "Image cannot be decoded" }
                    }
                    result("PASS",name,"Protected asset authenticates and ${if(id=="g")"image dimensions decode" else "audio bytes are present; playback still needs device verification"}.")
                } finally { bytes.fill(0) }
            }.onFailure { result("ERROR",name,it.toString(),"Rebuild the affected protected asset and verify decryption and device rendering/playback.");record(context,name,it) }
        }
        runCatching {
            val decoders=MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filterNot { it.isEncoder }
            line("DEVICE MEDIA DECODERS")
            decoders.forEach { line("${it.name}: ${it.supportedTypes.joinToString()}") };line()
            if(decoders.isEmpty())result("WARNING","Decoders","No decoders reported.","Test a known working media file; device API reporting may be incomplete.")
        }.onFailure { result("WARNING","Decoder inspection",it.toString(),"Test playback on the device and include file codec information.") }
        runCatching {
            val audio=context.getSystemService(AudioManager::class.java)
            line("AUDIO OUTPUT DEVICES")
            audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).forEach { line("Output device type: ${it.type}") }
            val accessibility=context.getSystemService(AccessibilityManager::class.java)
            line("Accessibility enabled: ${accessibility.isEnabled}; touch exploration: ${accessibility.isTouchExplorationEnabled}")
            result("NOT VERIFIED","Screen reader output routing","Other apps' actual speech routes cannot be inspected or controlled by this scan.","With earbuds connected, test TalkBack/Jieshuo and player separately; configure speaker output in the screen reader if supported.")
        }.onFailure { result("WARNING","Audio inspection",it.toString(),"Verify audio/nearby-device permissions and repeat the scan.") }
        runCatching {
            val prefs=PlayerPrefs(context)
            val apk=prefs.str("privateUpdateName")
            if(apk.isNotBlank())result("INFO","Private APK storage","A saved update is tracked in app data; use Check for update to download again if needed.")
            if(includeNetwork) {
            val snapshot=GitHubRepository.discover()
            result("PASS","GitHub repository","version.txt: ${snapshot.release.name}; versionCode: ${snapshot.release.code ?: "not specified"}; APK: ${snapshot.apk.path}; release notes length: ${snapshot.changes.length}")
            result("INFO","Update publication","App display version: ${BuildConfig.VERSION_NAME}.","Update detection uses only the Version Number in version.txt. Publish a valid signed APK before changing that version number. Android itself may reject incompatible or older builds.")
            }
        }.onFailure { result("ERROR","GitHub update check",it.toString(),recommendation(it.toString()));record(context,"GitHub diagnostic",it) }
        line("RECORDED APP ERRORS")
        val recorded=synchronized(lock) { File(context.filesDir,"app-log-errors.txt").takeIf { it.isFile }?.readText().orEmpty() }
        if(recorded.isBlank())line("No errors were recorded while the tester was enabled. This is not proof that the app has no bugs.")
        else { line(recorded);line("FIX GUIDANCE");line(recommendation(recorded)) }
        line();line("NOT AUTOMATICALLY TESTED")
        line("UI focus on a physical screen reader, each media codec/file, provider-specific rename/delete, actual Bluetooth speech routing and APK installation require manual reproduction.")
        val folder=File(context.filesDir,"app-logs").apply { mkdirs() }
        val file=File(folder,"Swift-Player-App-Log-${System.currentTimeMillis()}.txt")
        file.writeText(out.toString())
        folder.listFiles()?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
        return file
    }
}

class SwiftApplication:Application() {
    override fun onCreate() {
        super.onCreate()
        val previous=Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread,error ->
            AppLog.record(this,"Uncaught exception on ${thread.name}",error)
            if(previous!=null)previous.uncaughtException(thread,error)
            else { android.os.Process.killProcess(android.os.Process.myPid());kotlin.system.exitProcess(1) }
        }
    }
}
