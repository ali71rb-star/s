package com.abrothers.swiftplayer

import android.content.*
import android.database.Cursor
import android.database.MatrixCursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileNotFoundException
import java.io.InputStream
import java.util.UUID

/** Native Kotlin port: no Lua interpreter, shell copying, or file:// URI sharing. */
data class MediaEntry(val location: String, val name: String, val directory: Boolean = false,
                      val size: Long = 0, val modified: Long = 0, val diskPath: String = "", val resumeLocation: String = "") {
    fun json() = JSONObject().put("location", location).put("name", name).put("directory", directory)
        .put("size", size).put("modified", modified).put("diskPath", diskPath).put("resumeLocation",resumeLocation)
    companion object {
        fun from(o: JSONObject) = MediaEntry(o.getString("location"), o.getString("name"),
            o.optBoolean("directory"), o.optLong("size"), o.optLong("modified"), o.optString("diskPath"),o.optString("resumeLocation"))
        fun encode(items: List<MediaEntry>) = JSONArray().apply { items.forEach { put(it.json()) } }.toString()
        fun decode(text: String): List<MediaEntry> = runCatching {
            val a = JSONArray(text); (0 until a.length()).map { from(a.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }
}

class PlayerPrefs(context: Context,storeName:String="smart_player") {
    val raw = context.getSharedPreferences(storeName, Context.MODE_PRIVATE)
    fun bool(key: String, default: Boolean = true) = raw.getBoolean(key, default)
    fun str(key: String, default: String = "") = raw.getString(key, default) ?: default
    fun long(key: String, default: Long = 0) = raw.getLong(key, default)
    fun put(key: String, value: Boolean) { raw.edit().putBoolean(key, value).apply() }
    fun put(key: String, value: String) { raw.edit().putString(key, value).apply() }
    fun put(key: String, value: Long) { raw.edit().putLong(key, value).apply() }
    var speed: Float
        get() = raw.getFloat("speed", 1f)
        set(value) { raw.edit().putFloat("speed", value).apply() }
    var ff: Long
        get() = long("ff", 10000)
        set(value) = put("ff", value)
    var durations: List<Long>
        get() = str("durations", "5000,10000,20000,30000,60000").split(',').mapNotNull { it.toLongOrNull() }.filter { it > 0 }
        set(value) = put("durations", value.joinToString(","))
    fun favorites() = MediaEntry.decode(str("favorites", "[]"))
    fun favorite(item: MediaEntry) = favorites().any { it.location == item.location }
    fun toggleFavorite(item: MediaEntry): Boolean {
        val all = favorites().toMutableList()
        val added = !all.removeAll { it.location == item.location }
        if (added) all.add(item)
        put("favorites", MediaEntry.encode(all)); return added
    }
    fun removeFavorite(location: String) = put("favorites", MediaEntry.encode(favorites().filterNot { it.location == location }))
    fun renameFavorite(old: String, item: MediaEntry) {
        put("favorites", MediaEntry.encode(favorites().map { if (it.location == old) item else it }))
    }
}

class MediaRepository(val context: Context, private val prefs:PlayerPrefs=PlayerPrefs(context)) {
    private val resolver get() = context.contentResolver
    private data class Cached(val at: Long, val entries: List<MediaEntry>)
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Cached>()
    private val observer = object : android.database.ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { invalidate() }
    }
    init { runCatching { resolver.registerContentObserver(MediaStore.Files.getContentUri("external"), true, observer) } }
    fun invalidate() { cache.clear() }
    fun close() { runCatching { resolver.unregisterContentObserver(observer) }; invalidate() }
    fun allowedInAllFiles(entry: MediaEntry): Boolean {
        if (prefs.bool("voiceNotesInAll")) return true
        val path = (entry.diskPath.ifEmpty { entry.location } + "/" + entry.name).lowercase()
            .replace("%20", " ").replace("%2f", "/")
        return !path.contains("whatsapp voice notes") && !path.contains("whatsapp business voice notes")
    }
    val audio = setOf("mp3", "wav", "aac", "flac", "ogg", "m4a", "opus", "amr", "wma", "aiff", "aif", "alac", "ape", "mka", "mp2", "ac3", "eac3", "dts", "mid", "midi", "oga", "aifc", "caf", "wv", "au")
    val video = setOf("mp4", "mkv", "3gp", "avi", "webm", "mov", "m4v", "wmv", "flv", "mpg", "mpeg", "ts", "m2ts", "mts", "vob", "ogv", "3g2", "asf", "m2v", "divx", "f4v")
    val images = setOf("jpg", "jpeg", "png")
    fun matches(name: String, type: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (type) {
            "audio" -> ext in audio
            "video" -> ext in video
            "statuses" -> (prefs.bool("statusImages") && ext in images) || (prefs.bool("statusVideos") && ext in video)
            else -> false
        }
    }
    fun mime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "txt" -> "text/plain"
            "apk" -> "application/vnd.android.package-archive"
            "avi", "divx" -> "video/x-msvideo"; "webm" -> "video/webm"; "flac" -> "audio/flac"
            "mov" -> "video/quicktime"; "m4v" -> "video/x-m4v"; "wmv", "asf" -> "video/x-ms-wmv"
            "mpg", "mpeg", "m2v" -> "video/mpeg"; "ts", "mts", "m2ts" -> "video/mp2t"
            "flv", "f4v" -> "video/x-flv"; "vob" -> "video/dvd"; "ogv" -> "video/ogg"; "3g2" -> "video/3gpp2"
            "wma" -> "audio/x-ms-wma"; "ape" -> "audio/x-ape"; "aif", "aiff", "aifc" -> "audio/aiff"
            "alac" -> "audio/alac"; "mka" -> "audio/x-matroska"; "mp2" -> "audio/mpeg"
            "ac3" -> "audio/ac3"; "eac3" -> "audio/eac3"; "dts" -> "audio/vnd.dts"
            "mid", "midi" -> "audio/midi"; "oga" -> "audio/ogg"; "caf" -> "audio/x-caf"; "wv" -> "audio/x-wavpack"; "au" -> "audio/basic"
            "mp3" -> "audio/mpeg"; "mp4" -> "video/mp4"; "wav" -> "audio/wav"; "ogg" -> "audio/ogg"
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"
            "mkv" -> "video/x-matroska"; "opus" -> "audio/opus"; "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"; "amr" -> "audio/amr"; "3gp" -> "video/3gpp"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }
    fun isImage(e: MediaEntry) = mime(e.name).startsWith("image/")
    fun isVideo(e: MediaEntry) = e.name.substringAfterLast('.', "").lowercase() in video || mime(e.name).startsWith("video/")
    fun asUri(location: String): Uri = if (location.startsWith("/")) Uri.fromFile(File(location)) else Uri.parse(location)
    fun fromFile(file: File) = MediaEntry(file.absolutePath, file.name, file.isDirectory, if (file.isFile) file.length() else 0, file.lastModified(), file.absolutePath)
    fun entry(uri: Uri): MediaEntry {
        if (uri.scheme == "file") return fromFile(File(uri.path ?: error("No file path")))
        var name = uri.lastPathSegment ?: "Media"
        var size = 0L
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        }
        if (!name.contains('.')) {
            val mime = runCatching { resolver.getType(uri) }.getOrNull()
            val ext = mime?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
            if (ext != null) name += ".$ext"
        }
        var diskPath=runCatching {
            if(uri.authority != "media") null else resolver.query(uri,arrayOf(MediaStore.MediaColumns.DATA),null,null,null)?.use { c ->
                val column=c.getColumnIndex(MediaStore.MediaColumns.DATA)
                if(column>=0 && c.moveToFirst())c.getString(column).orEmpty() else ""
            }
        }.getOrNull().orEmpty()
        if(diskPath.isBlank() && uri.authority=="com.android.externalstorage.documents" && DocumentsContract.isDocumentUri(context,uri)) {
            val id=runCatching { DocumentsContract.getDocumentId(uri) }.getOrDefault("")
            val volume=id.substringBefore(':');val relative=id.substringAfter(':',"")
            if(relative.isNotBlank() && !relative.split('/').contains(".."))
                diskPath=(if(volume.equals("primary",true))Environment.getExternalStorageDirectory().absolutePath else "/storage/$volume")+"/"+relative
        }
        // Never trust a provider's _data value to point into this app's private storage.
        if(!listOf("/storage/","/sdcard/","/mnt/media_rw/").any { diskPath.startsWith(it) })diskPath=""
        return MediaEntry(uri.toString(), name, size = size,diskPath=diskPath)
    }
    fun treeRoot(uri: Uri): String = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri)).toString()
    private fun documentChildren(root: String): List<MediaEntry> {
        val u = Uri.parse(root)
        val child = DocumentsContract.buildChildDocumentsUriUsingTree(u, DocumentsContract.getDocumentId(u))
        return buildList {
            resolver.query(child, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    add(MediaEntry(DocumentsContract.buildDocumentUriUsingTree(u, c.getString(0)).toString(), c.getString(1) ?: "Untitled",
                        c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR, c.getLong(3), c.getLong(4)))
                }
            }
        }
    }
    fun exists(item: MediaEntry): Boolean = runCatching {
        if (item.location.startsWith("/")) File(item.location).exists()
        else resolver.openAssetFileDescriptor(Uri.parse(item.location), "r")?.use { true } ?: false
    }.getOrDefault(false)
    private fun children(root: String): List<MediaEntry> = if (root.startsWith("content:")) documentChildren(root)
        else File(root).listFiles()?.map(::fromFile) ?: emptyList()

    /** File system when granted; MediaStore fallback for ordinary media permission. */
    fun list(root: String, type: String, recursive: Boolean): List<MediaEntry> {
        val broad = Build.VERSION.SDK_INT < 30 || runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
        val key = "$root|$type|$recursive|$broad|${prefs.bool("statusImages")}|${prefs.bool("statusVideos")}"
        cache[key]?.let { if (android.os.SystemClock.elapsedRealtime() - it.at < 10000) return it.entries }
        val result = when {
            root.startsWith("content:") -> scanDocuments(root, type, recursive)
            File(root).canonicalPath.startsWith(context.filesDir.parentFile!!.canonicalPath + "/") -> scanFiles(root, type, recursive)
            type == "statuses" && broad -> scanFiles(root, type, recursive)
            else -> {
                // One indexed query replaces thousands of directory probes; no recursive hasMedia for every folder.
                val indexed = runCatching { mediaStore(root, type, recursive) }.getOrDefault(emptyList())
                if (indexed.isNotEmpty()) indexed else if (broad) scanFiles(root, type, recursive) else indexed
            }
        }
        cache[key] = Cached(android.os.SystemClock.elapsedRealtime(), result)
        return result
    }
    private fun scanFiles(root: String, type: String, recursive: Boolean): List<MediaEntry> {
        val out = mutableListOf<MediaEntry>(); val visited = hashSetOf<String>()
        fun walk(folder: File, depth: Int) {
            if (Thread.currentThread().isInterrupted || depth > 64 || !visited.add(folder.canonicalPath)) return
            folder.listFiles()?.forEach { f ->
                if (type != "statuses" && f.name.startsWith('.')) return@forEach
                if (f.isDirectory) {
                    if (recursive) walk(f, depth + 1)
                    else if (hasMatching(f,type,0,hashSetOf())) out.add(fromFile(f))
                } else if (matches(f.name, type)) out.add(fromFile(f))
            }
        }
        walk(File(root), 0)
        return out
    }
    private fun hasMatching(f: File, type: String, depth: Int, seen: MutableSet<String>): Boolean {
        if (depth > 64 || Thread.currentThread().isInterrupted || !seen.add(f.canonicalPath)) return false
        return f.listFiles()?.any { child ->
            (type == "statuses" || !child.name.startsWith('.')) &&
                (if (child.isDirectory) hasMatching(child, type, depth + 1, seen) else matches(child.name, type))
        } ?: false
    }
    private fun scanDocuments(root: String, type: String, recursive: Boolean): List<MediaEntry> {
        val out = mutableListOf<MediaEntry>(); val seen = hashSetOf<String>()
        fun walk(path: String, depth: Int) {
            if (depth > 64 || Thread.currentThread().isInterrupted || !seen.add(path)) return
            children(path).forEach { e ->
                if (type != "statuses" && e.name.startsWith('.')) return@forEach
                if (e.directory) { if (recursive) walk(e.location, depth + 1) else if (documentHasMedia(e.location,type,0,hashSetOf())) out.add(e) }
                else if (matches(e.name, type)) out.add(e)
            }
        }
        walk(root, 0); return out
    }
    @Suppress("DEPRECATION")
    private fun mediaStore(root: String, type: String, recursive: Boolean): List<MediaEntry> {
        val out = mutableListOf<MediaEntry>(); val dirs = linkedMapOf<String, MediaEntry>()
        val volumes = if (Build.VERSION.SDK_INT >= 29) MediaStore.getExternalVolumeNames(context) else setOf("external")
        for (volume in volumes) {
            val collection = MediaStore.Files.getContentUri(volume)
            val projection = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED)
            resolver.query(collection, projection, MediaStore.Files.FileColumns.DATA + " LIKE ?", arrayOf(root.trimEnd('/') + "/%"), null)?.use { c ->
                while (c.moveToNext()) {
                    val path = c.getString(2) ?: continue
                    val name = c.getString(1) ?: File(path).name
                    if (!matches(name, type)) continue
                    val rel = path.removePrefix(root.trimEnd('/') + "/")
                    if (type != "statuses" && rel.split('/').any { it.startsWith('.') }) continue
                    if (recursive || !rel.contains('/')) {
                        out.add(MediaEntry(ContentUris.withAppendedId(collection, c.getLong(0)).toString(), name, false, c.getLong(3), c.getLong(4) * 1000, path))
                    } else {
                        val folder = File(root, rel.substringBefore('/'))
                        dirs[folder.absolutePath] = MediaEntry(folder.absolutePath, folder.name, true, modified = File(path).parentFile?.lastModified() ?: 0, diskPath = folder.absolutePath)
                    }
                }
            }
        }
        return dirs.values.toList() + out
    }
    fun sorted(list: List<MediaEntry>, method: String): List<MediaEntry> {
        val comparator = when (method) {
            "Z-A" -> compareByDescending<MediaEntry> { it.name.lowercase() }
            "Newest" -> compareByDescending<MediaEntry> { it.modified }
            "Oldest" -> compareBy<MediaEntry> { it.modified }
            else -> compareBy<MediaEntry> { it.name.lowercase() }
        }
        return list.sortedWith(compareByDescending<MediaEntry> { it.directory }.then(comparator))
    }
    fun size(entry: MediaEntry): Long {
        if (!entry.directory) return entry.size
        if (entry.location.startsWith("/")) {
            var total = 0L; val seen = hashSetOf<String>()
            fun walk(f: File, depth: Int) {
                if (depth > 64 || Thread.currentThread().isInterrupted || !seen.add(f.canonicalPath)) return
                if (f.isDirectory) f.listFiles()?.forEach { walk(it, depth + 1) } else total += f.length()
            }
            walk(File(entry.location), 0); return total
        }
        return children(entry.location).sumOf { size(it) }
    }
    private fun deleteFileSafely(target: File): Boolean {
        val canonicalRoot = target.canonicalPath
        fun remove(f: File, depth: Int): Boolean {
            if (depth > 64) return false
            val canonical = f.canonicalPath
            if (f.isDirectory && (canonical == canonicalRoot || canonical.startsWith(canonicalRoot + "/"))) {
                val children = f.listFiles() ?: return false
                var ok = true
                for (child in children) if (!remove(child, depth + 1)) ok = false
                if (!ok) return false
            }
            return f.delete()
        }
        return remove(target, 0)
    }
    fun delete(entry: MediaEntry): Boolean {
        val ok = if (entry.location.startsWith("/")) deleteFileSafely(File(entry.location))
            else if (DocumentsContract.isDocumentUri(context, Uri.parse(entry.location))) DocumentsContract.deleteDocument(resolver, Uri.parse(entry.location))
            else resolver.delete(Uri.parse(entry.location), null, null) > 0
        if (ok) {
            invalidate()
            prefs.removeFavorite(entry.location)
            if (entry.diskPath.isNotEmpty()) MediaScannerConnection.scanFile(context, arrayOf(entry.diskPath), null, null)
        }
        return ok
    }
    fun rename(entry: MediaEntry, name: String): MediaEntry {
        require(name.isNotBlank() && name != "." && name != ".." && !name.contains('/') && !name.contains('\\') && !name.contains('\u0000')) { "Invalid file name" }
        if (duplicateExists(entry,name)) throw DuplicateNameException()
        val updated: MediaEntry = if (entry.location.startsWith("/")) {
            val src = File(entry.location); val dest = File(src.parentFile, name)
            if(dest.exists()) throw DuplicateNameException()
            check(src.renameTo(dest)) { "Rename failed; check storage permission" }
            MediaScannerConnection.scanFile(context, arrayOf(src.absolutePath, dest.absolutePath), null, null)
            fromFile(dest)
        } else if (DocumentsContract.isDocumentUri(context, Uri.parse(entry.location))) {
            val newUri = DocumentsContract.renameDocument(resolver, Uri.parse(entry.location), name) ?: error("Rename failed")
            val actual=this.entry(newUri)
            if(actual.name!=name) {
                runCatching { DocumentsContract.renameDocument(resolver,newUri,entry.name) }
                throw DuplicateNameException()
            }
            actual
        } else {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name) }
            check(resolver.update(Uri.parse(entry.location), values, null, null) > 0) { "Rename failed" }
            val actual=this.entry(Uri.parse(entry.location))
            if(actual.name!=name) {
                resolver.update(Uri.parse(entry.location),ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME,entry.name) },null,null)
                throw DuplicateNameException()
            }
            entry.copy(name=name)
        }
        invalidate()
        prefs.renameFavorite(entry.location, updated)
        return updated
    }
    fun input(entry: MediaEntry): InputStream = if (entry.location.startsWith("/")) File(entry.location).inputStream()
        else resolver.openInputStream(Uri.parse(entry.location)) ?: throw FileNotFoundException(entry.name)
    fun shareUri(entry: MediaEntry): Uri = if (entry.location.startsWith("/")) ShareProvider.uri(context, File(entry.location)) else Uri.parse(entry.location)
    fun saveGallery(entry: MediaEntry) {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, entry.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime(entry.name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Saved Statuses")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Cannot create saved status")
            try {
                input(entry).use { src -> resolver.openOutputStream(uri)?.use { src.copyTo(it) } ?: error("Cannot write saved status") }
                resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
        } else {
            @Suppress("DEPRECATION") val destDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Saved Statuses").apply { mkdirs() }
            var dest = File(destDir, entry.name); var suffix = 1
            while (dest.exists()) { dest = File(destDir, "${File(entry.name).nameWithoutExtension}_${suffix++}.${File(entry.name).extension}") }
            input(entry).use { src -> dest.outputStream().use { src.copyTo(it) } }
            MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mime(entry.name)), null)
        }
    }
    fun sdPaths(): List<String> {
        val manager = context.getSystemService(android.os.storage.StorageManager::class.java)
        return manager.storageVolumes.filter { it.isRemovable && it.state in setOf(Environment.MEDIA_MOUNTED, Environment.MEDIA_MOUNTED_READ_ONLY) }
            .mapNotNull { volume ->
                if (Build.VERSION.SDK_INT >= 30) volume.directory?.absolutePath
                else context.getExternalFilesDirs(null).filterNotNull().firstOrNull { file ->
                    manager.getStorageVolume(file)?.uuid == volume.uuid
                }?.absolutePath?.substringBefore("/Android/")
            }.distinct()
    }
    /** Every descendant containing matching media is exposed at the root with a relative-path name. */
    fun flattenedFolders(root: String, type: String): List<MediaEntry> {
        if (root.startsWith("content:")) {
            val out = mutableListOf<MediaEntry>(); val visited = hashSetOf<String>()
            fun walk(folder: String, prefix: String, depth: Int): Boolean {
                if (depth > 64 || Thread.currentThread().isInterrupted || !visited.add(folder)) return false
                var hasMedia = false
                children(folder).forEach { child ->
                    if (type != "statuses" && child.name.startsWith('.')) return@forEach
                    if (child.directory) {
                        val relative = prefix + child.name
                        if (walk(child.location, "$relative/", depth+1)) {
                            out.add(child.copy(name = relative)); hasMedia = true
                        }
                    } else if (matches(child.name, type)) {
                        hasMedia = true
                        if (prefix.isEmpty()) out.add(child)
                    }
                }
                return hasMedia
            }
            walk(root, "", 0); return out.distinctBy { it.location }
        }
        val all = list(root, type, true)
        val directories = linkedMapOf<String, MediaEntry>(); val topFiles = mutableListOf<MediaEntry>()
        val prefix = File(root).absolutePath.trimEnd('/') + "/"
        for (entry in all) {
            val disk = entry.diskPath.ifEmpty { entry.location }
            if (!disk.startsWith(prefix)) continue
            val relative = disk.removePrefix(prefix)
            if (!relative.contains('/')) { topFiles.add(entry); continue }
            val parts = relative.substringBeforeLast('/').split('/')
            var rel = ""
            for (part in parts) {
                rel = if (rel.isEmpty()) part else "$rel/$part"
                val path = prefix + rel
                directories.putIfAbsent(path, MediaEntry(path, rel, true, diskPath = path))
            }
        }
        return directories.values.toList() + topFiles
    }
    /** Refresh the index for new files in this root, then invalidate even when only indexed access is available. */
    fun rescan(root: String, type: String, finished: () -> Unit) {
        invalidate()
        val broad = Build.VERSION.SDK_INT < 30 || runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
        if (!root.startsWith("/") || !broad) { finished(); return }
        val files = scanFiles(root, type, true).filterNot { it.directory }
        if (files.isEmpty()) { finished(); return }
        val lock = java.util.concurrent.atomic.AtomicInteger(files.size)
        val once = java.util.concurrent.atomic.AtomicBoolean(false)
        val handler = Handler(Looper.getMainLooper())
        val done = { if (once.compareAndSet(false,true)) { invalidate(); finished() }; Unit }
        handler.postDelayed({ done() }, 8000)
        MediaScannerConnection.scanFile(context, files.map { it.location }.toTypedArray(), null) { _, _ ->
            if (lock.decrementAndGet() == 0) done()
        }
    }
    private fun documentHasMedia(folder:String,type:String,depth:Int,seen:MutableSet<String>):Boolean {
        if(depth>64 || !seen.add(folder) || Thread.currentThread().isInterrupted) return false
        return children(folder).any { e ->
            (type=="statuses" || !e.name.startsWith('.')) && (if(e.directory) documentHasMedia(e.location,type,depth+1,seen) else matches(e.name,type))
        }
    }
    fun duplicateExists(entry:MediaEntry,name:String):Boolean {
        if(entry.location.startsWith("/")) return File(File(entry.location).parentFile,name).let { it.exists() && it.canonicalPath!=File(entry.location).canonicalPath }
        val uri=Uri.parse(entry.location)
        if(DocumentsContract.isTreeUri(uri) && DocumentsContract.isDocumentUri(context,uri)) {
            val id=DocumentsContract.getDocumentId(uri)
            val parentId=id.substringBeforeLast('/',"")
            if(parentId.isNotEmpty()) {
                val parent=DocumentsContract.buildDocumentUriUsingTree(uri,parentId).toString()
                return children(parent).any { !it.directory && it.name==name && it.location!=entry.location }
            }
        }
        val path=entry.diskPath.ifEmpty { runCatching { resolver.query(uri,arrayOf(MediaStore.MediaColumns.DATA),null,null,null)?.use { c -> if(c.moveToFirst()) c.getString(0) else "" } }.getOrNull().orEmpty() }
        if(path.startsWith("/")) return File(File(path).parentFile,name).exists() && name!=entry.name
        if(uri.authority=="media") {
            val projection=arrayOf(MediaStore.MediaColumns.RELATIVE_PATH)
            if(Build.VERSION.SDK_INT>=29) {
                val relative=runCatching { resolver.query(uri,projection,null,null,null)?.use { c -> if(c.moveToFirst()) c.getString(0) else null } }.getOrNull()
                if(relative!=null) resolver.query(MediaStore.Files.getContentUri("external"),arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",arrayOf(name,relative),null)?.use { if(it.moveToFirst() && name!=entry.name)return true }
            }
        }
        return false
    }
    fun editableEntry(entry:MediaEntry):MediaEntry {
        if(!entry.location.startsWith("content:"))return entry
        val path=entry.diskPath
        if(!path.startsWith("/") || path.contains("/../"))return entry
        val file=File(path)
        return if(file.isFile && file.name==entry.name && file.canWrite() && file.parentFile?.canWrite()==true)
            entry.copy(location=file.absolutePath) else entry
    }
    fun mediaStoreUri(entry:MediaEntry):Uri? {
        val uri=asUri(entry.location)
        if(uri.scheme=="content" && uri.authority=="media") return uri
        if(Build.VERSION.SDK_INT>=29 && uri.scheme=="content") runCatching { MediaStore.getMediaUri(context,uri) }.getOrNull()?.let { return it }
        val path=entry.diskPath.ifEmpty { if(entry.location.startsWith("/")) entry.location else "" }
        if(path.isNotBlank()) return runCatching {
            resolver.query(MediaStore.Files.getContentUri("external"),arrayOf(MediaStore.MediaColumns._ID),"${MediaStore.MediaColumns.DATA}=?",arrayOf(path),null)?.use { c -> if(c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"),c.getLong(0)) else null }
        }.getOrNull()
        return null
    }
    /** Use kernel file identity, not display name or duplicate file bytes, to match opaque grants. */
    private fun fileIdentity(uri:Uri):Pair<Long,Long>? = runCatching {
        resolver.openFileDescriptor(uri,"r")?.use { descriptor ->
            val stat=android.system.Os.fstat(descriptor.fileDescriptor)
            if(android.system.OsConstants.S_ISREG(stat.st_mode) && stat.st_ino!=0L && stat.st_nlink>0L)stat.st_dev to stat.st_ino else null
        }
    }.getOrNull()
    fun resolveMutationEntry(entry:MediaEntry):MediaEntry {
        if(!entry.location.startsWith("content:") || entry.directory)return entry
        val source=asUri(entry.location)
        val direct=mediaStoreUri(entry)
        if(direct!=null)return entry.copy(location=direct.toString())
        val id=fileIdentity(source) ?: return entry
        val volumes=if(Build.VERSION.SDK_INT>=29) android.provider.MediaStore.getExternalVolumeNames(context) else setOf("external")
        for(volume in volumes) {
            val collection=if(isVideo(entry))MediaStore.Video.Media.getContentUri(volume) else MediaStore.Audio.Media.getContentUri(volume)
            val found=runCatching {
                resolver.query(collection,arrayOf(MediaStore.MediaColumns._ID),"${MediaStore.MediaColumns.DISPLAY_NAME}=?",arrayOf(entry.name),null)?.use { c ->
                    var checked=0
                    while(c.moveToNext() && checked++<64) {
                        val candidate=ContentUris.withAppendedId(collection,c.getLong(0))
                        if(fileIdentity(candidate)==id)return@use candidate
                    }
                    null
                }
            }.getOrNull()
            if(found!=null)return entry.copy(location=found.toString())
        }
        return entry
    }
    // Never identify a mutation target by filename or even identical bytes: two copies can coexist.
    fun sameMutationTarget(original:MediaEntry,chosen:MediaEntry):Boolean {
        val a=asUri(original.location);val b=asUri(chosen.location)
        if(a==b)return true
        val identity=fileIdentity(a)
        if(identity!=null && identity==fileIdentity(b))return true
        if(a.scheme=="content" && b.scheme=="content" && a.authority==b.authority &&
            DocumentsContract.isDocumentUri(context,a) && DocumentsContract.isDocumentUri(context,b) &&
            DocumentsContract.getDocumentId(a)==DocumentsContract.getDocumentId(b))return true
        val aa=mediaStoreUri(original);val bb=mediaStoreUri(chosen)
        if(aa!=null && aa==bb)return true
        if(original.diskPath.isNotBlank() && chosen.diskPath.isNotBlank())return runCatching {
            File(original.diskPath).canonicalFile==File(chosen.diskPath).canonicalFile
        }.getOrDefault(false)
        return false
    }
    fun saveResumeCopy(entry:MediaEntry):MediaEntry {
        if(!entry.location.startsWith("content:") || entry.location.contains(context.packageName+".files")) return entry
        if(entry.resumeLocation.isNotEmpty() && File(entry.resumeLocation).isFile) return entry
        val uri=Uri.parse(entry.location)
        if(resolver.persistedUriPermissions.any { it.isReadPermission && (it.uri==uri || (DocumentsContract.isTreeUri(it.uri) && uri.toString().startsWith(it.uri.toString()))) }) return entry
        val folder=File(context.filesDir,"resume-media").apply { mkdirs() }
        val id=java.security.MessageDigest.getInstance("SHA-256").digest(entry.location.toByteArray()).joinToString("") { "%02x".format(it) }
        val target=File(folder,id+"."+entry.name.substringAfterLast('.',"bin").take(8))
        if(!target.exists()) {
            val part=File(folder,target.name+".part")
            try { input(entry).use { src -> part.outputStream().use { src.copyTo(it) } };check(part.renameTo(target)) { "Resume copy could not be saved" } }
            catch(e:Exception) { part.delete();throw e }
        }
        return entry.copy(resumeLocation=target.absolutePath)
    }
    companion object {
        fun formatSize(bytes: Long): String = when {
            bytes >= 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
            else -> String.format(java.util.Locale.US, "%.2f MB", bytes / (1024.0 * 1024))
        }
    }
}

/** Read-only, grant-based file sharing provider with opaque, app-created tokens. */
class ShareProvider : ContentProvider() {
    override fun onCreate() = true
    private fun file(uri: Uri): File {
        val ctx = context ?: throw FileNotFoundException()
        val path = ctx.getSharedPreferences("shared_files", Context.MODE_PRIVATE).getString(uri.pathSegments.firstOrNull(), null)
            ?: throw FileNotFoundException("Unknown share")
        return File(path).also { if (!it.isFile) throw FileNotFoundException() }
    }
    override fun getType(uri: Uri): String = MediaRepository(context!!).mime(file(uri).name)
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val f = file(uri); val columns = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        return MatrixCursor(columns).apply { addRow(columns.map { when (it) { OpenableColumns.DISPLAY_NAME -> f.name; OpenableColumns.SIZE -> f.length(); else -> null } }) }
    }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw SecurityException("Read-only sharing")
        return ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    companion object {
        fun uri(context: Context, file: File): Uri {
            val token = UUID.randomUUID().toString()
            context.getSharedPreferences("shared_files", Context.MODE_PRIVATE).edit().putString(token, file.canonicalPath).apply()
            return Uri.Builder().scheme("content").authority(context.packageName + ".files").appendPath(token).appendPath(file.name).build()
        }
    }
}

class DuplicateNameException: IllegalArgumentException("Cannot rename this file. Already one file is present.")
