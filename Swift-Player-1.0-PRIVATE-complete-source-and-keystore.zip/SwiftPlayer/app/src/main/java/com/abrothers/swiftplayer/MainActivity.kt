package com.abrothers.swiftplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckedTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.Switch
import android.view.accessibility.AccessibilityNodeInfo
import android.content.pm.ActivityInfo
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future

class MainActivity : Activity() {
    private lateinit var prefs: PlayerPrefs
    private lateinit var repo: MediaRepository
    private lateinit var shell: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var heading: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val workers = Executors.newFixedThreadPool(2)
    private var scanJob: Future<*>? = null
    private var statsJob: Future<*>? = null
    private var scanGeneration = 0
    private var statsGeneration = 0
    private var service: PlaybackService? = null
    private var bound = false
    private var pendingAction: (() -> Unit)? = null
    private var screen = "home"
    private var backAction: () -> Unit = { home() }
    private var root = "/storage/emulated/0"
    private var browsePath = root
    private var mediaType = "audio"
    private var mode = "folders"
    private var query = ""
    private var entries = emptyList<MediaEntry>()
    private var selected = linkedSetOf<String>()
    private var multi = false
    private var browseParents = mutableListOf<String>()
    private var list: ListView? = null
    private var rowAdapter: ArrayAdapter<MediaEntry>? = null
    private val rowData = mutableListOf<MediaEntry>()
    private var selectionBar: LinearLayout? = null
    private var selectionText: TextView? = null
    private var titleRef: TextView? = null
    private var timeRef: TextView? = null
    private var messageRef: TextView? = null
    private var playRef: Button? = null
    private var boostRef: Button? = null
    private var sleepRef: Button? = null
    private var speedRef: Button? = null
    private var seekRef: SeekBar? = null
    private var seeking = false
    private var desiredSeek=-1
    private var seekHoldUntil=0L
    private var cueFinishing=false
    private var permissionAction:(()->Unit)?=null
    private var permissionEntry:MediaEntry?=null
    private var permissionReplacement:((MediaEntry)->Unit)?=null
    private var permissionDialog:AlertDialog?=null
    private var pendingMutationDelete=false
    private val editableOverrides=mutableMapOf<String,MediaEntry>()
    private var playerHasVideo = false
    private var folderRequestKey = ""
    private var externalMode = false
    private var incomingHandled = false
    private var tutorialDialog: AlertDialog? = null
    private var tutorialPlayer: MediaPlayer? = null
    private var downloadCancelled = false
    private var tutorialTransfer: Future<*>?=null
    private var tutorialPlaybackTick: Runnable? = null
    private var liveSearch: Runnable? = null
    private var splashSound: MediaPlayer? = null
    private var speech: TextToSpeech? = null
    private var speechReady = false
    private var shareSelectedButton: Button? = null
    private var deleteSelectedButton: Button? = null
    private var fullScreenVideo = false
    private var videoSurface: android.view.SurfaceView? = null
    private var pendingTitle = ""
    private var playerOriginKnown = false
    private var waOrigin: Boolean? = null
    private var exiting = false
    private var scanReturn: (() -> Unit)? = null
    private lateinit var updates: UpdateManager
    private val connected = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? PlaybackService.LocalBinder)?.service ?: return
            if (isDestroyed) return
            bound = true
            service?.onChange = {
                if (screen == "player") {
                    val newVideo = service?.current?.let(repo::isVideo) == true
                    if (newVideo != playerHasVideo) playerScreen() else updatePlayer()
                }
            }
            val action = pendingAction; pendingAction = null
            if (action != null) action() else if (intent.getBooleanExtra("showPlayer", false) && service?.current != null) playerScreen()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null; bound = false }
    }
    private val ticker = object : Runnable {
        override fun run() { if (screen == "player") updatePlayer(); handler.postDelayed(this, 500) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PlayerPrefs(this); repo = MediaRepository(this)
        speech = TextToSpeech(this) { status ->
            speechReady = status == TextToSpeech.SUCCESS
            if (speechReady) speech?.language = Locale.US
        }
        volumeControlStream = AudioManager.STREAM_MUSIC
        val serviceIntent = Intent(this, PlaybackService::class.java)
        startService(serviceIntent)
        bound = bindService(serviceIntent, connected, BIND_AUTO_CREATE)
        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 249, 250))
            setOnApplyWindowInsetsListener { v, insets ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                } else {
                    @Suppress("DEPRECATION") v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
                }
                insets
            }
        }
        setContentView(shell)
        if (Build.VERSION.SDK_INT >= 33) onBackInvokedDispatcher.registerOnBackInvokedCallback(
            android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT) { navigateBack() }
        updates = UpdateManager(this)
        showSplash()
        handler.post(ticker)
    }
    private var startupGeneration = 0
    private var startupStartedAt = 0L
    private var startupDone: (() -> Unit)? = null
    private fun showSplash() {
        val token=++startupGeneration
        screen="splash"; service?.pause()
        runCatching { splashSound?.release() };splashSound=null
        val launchIntent=Intent(intent)
        val external=launchIntent.action in listOf(Intent.ACTION_VIEW,Intent.ACTION_SEND,Intent.ACTION_SEND_MULTIPLE)
        val picture=ImageView(this).apply {
            tag="startup-markhor"
            runCatching { ProtectedAssets.image(this@MainActivity,this) }.onFailure { AppLog.record(this@MainActivity,"Startup image",it) }
            scaleType=ImageView.ScaleType.FIT_CENTER
            importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO
            setBackgroundColor(Color.BLACK)
        }
        shell.removeAllViews();shell.addView(picture,LinearLayout.LayoutParams(-1,-1))
        startupStartedAt=android.os.SystemClock.elapsedRealtime()
        var finished=false
        startupDone={
            val wait=(700L-(android.os.SystemClock.elapsedRealtime()-startupStartedAt)).coerceAtLeast(0)
            handler.postDelayed({
                if(!finished && token==startupGeneration && !isFinishing && !isDestroyed) {
                    finished=true;startupDone=null
                    if(external) { incomingHandled=true;externalMode=true;pendingTitle="";handleIncoming(launchIntent) }
                    else {
                        home()
                        if(launchIntent.getBooleanExtra("showPlayer",false) && service?.current!=null)playerScreen()
                        if(launchIntent.getBooleanExtra("installUpdate",false))updates.installPending()
                    }
                    if(prefs.bool("autoUpdate"))updates.check(false)
                }
            },wait)
        }
        // Do not replace the image in the same frame. Both launch paths play the complete cue.
        picture.postOnAnimation {
            if(token==startupGeneration && !isDestroyed) {
                if(!prefs.bool("playAppSounds",true)) { startupDone?.invoke();return@postOnAnimation }
                splashSound=ProtectedAssets.sound(this,"s") { if(token==startupGeneration) { splashSound=null;startupDone?.invoke() } }
                handler.postDelayed({
                    if(token==startupGeneration && !finished) {
                        runCatching { splashSound?.release() };splashSound=null;startupDone?.invoke()
                    }
                },3200)
            }
        }
    }
    private fun playStartupSound() {
        if(!prefs.bool("playAppSounds",true))return
        runCatching { splashSound?.release() }
        splashSound=ProtectedAssets.sound(this,"s") { splashSound=null }
    }
    private fun exitWithCue(finishAction:()->Unit) {
        if(!prefs.bool("playAppSounds",true)) { finishAction();return }
        if(cueFinishing)return
        cueFinishing=true
        runCatching { splashSound?.release() };splashSound=null
        var completed=false
        val done={ if(!completed) { completed=true;cueFinishing=false;finishAction() };Unit }
        splashSound=ProtectedAssets.sound(this,"e",done)
        handler.postDelayed({ if(!completed) { runCatching { splashSound?.release() };done() } },3500)
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); if(exiting)return;setIntent(intent)
        if (intent.getBooleanExtra("showPlayer", false)) {
            externalMode = false
            if (service?.current != null) playerScreen() else restore()
        } else if (intent.getBooleanExtra("installUpdate", false)) updates.installPending() else if(intent.action in listOf(Intent.ACTION_VIEW,Intent.ACTION_SEND,Intent.ACTION_SEND_MULTIPLE))showSplash()
        else handleIncoming(intent)
    }
    private fun handleIncoming(intent: Intent) {
        val launchToken=startupGeneration
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> @Suppress("DEPRECATION") (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        if (uris.isEmpty()) return
        externalMode = true
        playerScreen()
        workers.submit {
            runCatching { uris.map { u -> retainUriGrant(u, intent.flags); repo.entry(u) } }
                .onSuccess { items -> runOnUiThread {
                    if(exiting || isDestroyed || isFinishing || launchToken!=startupGeneration)return@runOnUiThread
                    mediaType = if ((intent.type ?: "").startsWith("video/") || items.any(repo::isVideo)) "video" else "audio"
                    prefs.put("mediaType", mediaType); play(items, 0)
                } }
                .onFailure { e -> runOnUiThread { error(e) } }
        }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 16f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(26, 46, 58)); setPadding(dp(8), dp(10), dp(8), dp(10))
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; minHeight = dp(48); tag = label; contentDescription = label
        setOnClickListener { focusMemory = it.tag?.toString(); action() }
    }
    private fun rememberFocus() { focusMemory = (currentFocus as? View)?.tag?.toString() }
    private var focusMemory: String? = null
    /** Keeps screen-reader focus on the control the user just used instead of jumping to a header. */
    private fun restoreFocusSoon() {
        val wanted = focusMemory ?: return
        shell.post {
            val found = findTagged(shell, wanted) ?: return@post
            val am = getSystemService(AccessibilityManager::class.java)
            if (am.isEnabled) found.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
            else found.requestFocus()
        }
    }
    private fun findTagged(group: ViewGroup, tag: String): View? {
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child.tag == tag && child.isShown) return child
            if (child is ViewGroup) findTagged(child, tag)?.let { return it }
        }
        return null
    }
    private fun firstControl(): View? {
        val lv = list
        if (lv != null && lv.adapter?.count ?: 0 > 0) return lv
        for (i in 0 until body.childCount) if (body.getChildAt(i) is Button) return body.getChildAt(i)
        return null
    }
    private fun makeScreen(title: String, kind: String, back: () -> Unit = { home() }): LinearLayout {
        scanGeneration++; scanJob?.cancel(true); liveSearch?.let(handler::removeCallbacks)
        screen = kind; backAction = back
        list = null; rowAdapter = null; rowData.clear()
        titleRef = null; timeRef = null; messageRef = null
        playRef = null; sleepRef = null; speedRef = null; boostRef = null; seekRef = null
        if (kind != "player") { service?.setSurface(null); window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        shell.removeAllViews()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(23, 61, 82)) }
        heading = text(title, 19f).apply {
            setTextColor(Color.WHITE); setPadding(dp(16), dp(14), dp(16), dp(14))
            isFocusable = false
            if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
        }
        top.addView(heading, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)); shell.addView(top)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        if (Build.VERSION.SDK_INT >= 28) body.accessibilityPaneTitle = title
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        restoreFocusSoon()
        return body
    }
    private fun scroll(container: LinearLayout = body): LinearLayout {
        val inside = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        container.addView(ScrollView(this).apply { addView(inside); isFillViewport = true }, LinearLayout.LayoutParams(-1, -1)); return inside
    }
    private fun home() {
        multi = false; selected.clear(); externalMode = false
        makeScreen(getString(R.string.app_name), "home") { exitApp() }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        body.addView(col, LinearLayout.LayoutParams(-1, -1))
        col.addView(button("Scan") { scanReturn = { home() }; storageMenu() })
        if (prefs.bool("showWhatsApp")) col.addView(button("WhatsApp Media") { whatsAppMenu() })
        if (service?.current != null || MediaEntry.decode(prefs.str("queue", "[]")).isNotEmpty()) {
            col.addView(button("Open Last Resume") { if (service?.isPrepared == true) { playerScreen();service?.resume() } else restore() })
        }
        col.addView(button("Settings") { settingsMenu() })
        col.addView(button("Exit App") { exitApp() })
    }
    private fun exitApp() {
        exiting = true; service?.onChange = null; service?.saveAndStop(); prefs.put("exitPending", true)
        exitWithCue { finishAndRemoveTask() }
    }
    private fun storageMenu() {
        choose("Choose Your Storage", listOf("Internal Storage", "SD Card"), { scanReturn?.invoke() ?: home() }) { which ->
            if (which == 0) typeMenu("/storage/emulated/0") else {
                val paths = repo.sdPaths()
                if (paths.isEmpty()) Toast.makeText(this, "SD Card is currently not inserted or mounted", Toast.LENGTH_LONG).show()
                else if (paths.size == 1) typeMenu(paths[0])
                else choose("SD Cards", paths, { storageMenu() }) { typeMenu(paths[it]) }
            }
        }
    }
    private fun typeMenu(path: String) {
        root = path
        choose("Choose Your Selection", listOf("Audio", "Video"), { storageMenu() }) { index ->
            mediaType = if (index == 0) "audio" else "video"; root = path; modeMenu()
        }
    }
    private fun modeMenu() {
        choose("Select Mode", listOf("All Files", "Browse Folders", "Favorites"), { typeMenu(root) }) { i ->
            mode = arrayOf("all_files", "folders", "favorites")[i]
            query = ""; browseParents.clear(); multi = false; selected.clear(); waOrigin = null
            browsePath = root; browseScreen()
        }
    }
    private fun choose(title: String, options: List<String>, onBack: (() -> Unit)? = null, selected: (Int) -> Unit) {
        val d = AlertDialog.Builder(this).setTitle(title).setItems(options.toTypedArray()) { dialog, i -> dialog.dismiss(); selected(i) }.create()
        d.setOnCancelListener { onBack?.invoke() }
        d.setOnDismissListener { restoreFocusSoon() }
        d.show()
    }
    /** A toggle updates the existing native switch. Its view, ID and a11y focus never change. */
    private fun toggle(col: LinearLayout, label: String, key: String, default: Boolean = true, changed: ((Boolean) -> Unit)? = null): Switch {
        val control = Switch(this).apply {
            id = View.generateViewId(); tag = "toggle:$key"
            text = label; textSize = 16f; minHeight = dp(58)
            isChecked = prefs.bool(key, default)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        col.addView(control, LinearLayout.LayoutParams(-1, -2))
        control.setOnCheckedChangeListener { _, checked ->
            prefs.put(key, checked)
            if (Build.VERSION.SDK_INT >= 30) control.stateDescription = if (checked) "On" else "Off"
            changed?.invoke(checked)
            control.announceForAccessibility("$label, ${if (checked) "On" else "Off"}")
        }
        return control
    }
    private fun retainUriGrant(uri: Uri, flags: Int) {
        runCatching {
            if (flags and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0) {
                if (flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0)
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                else contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
    private fun chooseFolder(key: String = "") {
        folderRequestKey = key
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }, OPEN_TREE)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode==EDIT_CONSENT) {
            val run=permissionAction;permissionAction=null
            if(resultCode==RESULT_OK) run?.invoke() else service?.resume()
            return
        }
        if(requestCode==EDIT_DOCUMENT) {
            val old=permissionEntry;val run=permissionAction
            if(resultCode==RESULT_OK && data?.data!=null && old!=null) {
                val chosen=data.data!!;retainUriGrant(chosen,data.flags)
                val fresh=repo.entry(chosen)
                if(!repo.sameMutationTarget(old,fresh)) {
                    permissionAction=null;permissionEntry=null;service?.resume()
                    error(SecurityException("Cannot verify that this is the original file. No file was changed. Open the original from Swift Player's Scan or edit it in its source app."));return
                }
                if(data.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION==0) { error(SecurityException("This provider supplied read-only access. Rename or delete must be done in its owner app."));return }
                editableOverrides[old.location]=fresh;permissionAction=null;permissionEntry=null;run?.invoke()
            } else { permissionAction=null;permissionEntry=null;service?.resume() }
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        retainUriGrant(uri, data.flags)
        if (requestCode == OPEN_TREE) {
            root = repo.treeRoot(uri); browsePath = root; mode = "folders"; query = ""; browseParents.clear()
            if (folderRequestKey.isNotEmpty()) prefs.put(folderRequestKey, root)
            browseScreen()
        }
    }
    private fun browseScreen() {
        prefs.put("folder", browsePath); prefs.put("root", root); prefs.put("mediaType", mediaType); prefs.put("mode", mode)
        makeScreen(when (mode) { "all_files" -> "All Files"; "favorites" -> "Favorites"; else -> "Browse Folders" }, "browse") { browseBack() }
        val pathLabel = if (browsePath.startsWith("content:")) Uri.decode(Uri.parse(browsePath).lastPathSegment ?: "Selected folder") else browsePath
        body.addView(text(pathLabel, 12f))
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val search = EditText(this).apply {
            hint = "Search"; setSingleLine(true); setText(query); tag = "search-box"
            contentDescription = "Search media, including subfolders"
        }
        tools.addView(search, LinearLayout.LayoutParams(0, dp(52), 1f))
        tools.addView(button("Clear") { search.setText("") }, LinearLayout.LayoutParams(dp(76), dp(52))); body.addView(tools)
        val sortRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sortRow.addView(button("Sort By: ${prefs.str("sort", "A-Z")}") { sortMenu() }, LinearLayout.LayoutParams(0,-2,1f))
        sortRow.addView(button("Rescan") { rescanNow() }, LinearLayout.LayoutParams(0,-2,1f))
        body.addView(sortRow)
        selectionText = text("Scanning…", 13f).apply {
            if (Build.VERSION.SDK_INT >= 19) accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        body.addView(selectionText)
        list = ListView(this).apply { isFastScrollEnabled = true; tag = "media-list" }
        body.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        selectionBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (multi) View.VISIBLE else View.GONE }
        val row = LinearLayout(this)
        row.addView(button("Select All") {
            selected.addAll(entries.map { it.location }); updateRows(); speak("${selected.size} items selected")
        }, LinearLayout.LayoutParams(0, -2, 1f))
        selectionBar!!.addView(row)
        val actions = LinearLayout(this)
        shareSelectedButton = button("Share 0 items") { shareSelected() }
        deleteSelectedButton = button("Delete 0 items") { confirmDelete(entries.filter { it.location in selected }) }
        actions.addView(shareSelectedButton, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(deleteSelectedButton, LinearLayout.LayoutParams(0, -2, 1f))
        selectionBar!!.addView(actions); body.addView(selectionBar)
        list!!.setOnItemClickListener { _, _, position, _ ->
            val e = entries.getOrNull(position) ?: return@setOnItemClickListener
            focusMemory = "row:${e.location}"
            if (multi) {
                val nowSelected = if (!selected.remove(e.location)) { selected.add(e.location); true } else false
                val targets = entries.filter { it.location in selected }
                updateRows()
                speak((if (nowSelected) "Selected, " else "Not selected, ") + e.name + ", ${targets.size} selected")
            } else if (e.directory) { browseParents.add(browsePath); browsePath = e.location; query = ""; browseScreen() }
            else if (repo.isImage(e)) openImage(e)
            else {
                val queue = entries.filterNot { it.directory || repo.isImage(it) }
                play(queue, queue.indexOfFirst { it.location == e.location })
            }
        }
        list!!.setOnItemLongClickListener { _, view, position, _ ->
            val e = entries.getOrNull(position)
            if (e != null) {
                if (prefs.bool("multiSelect")) {
                    multi = true; selected.add(e.location); updateRows()
                    speak("Selection mode. ${e.name} selected")
                    (view as? CheckedTextView)?.isChecked = true
                } else {
                    choose(e.name, listOf("Delete")) { confirmDelete(listOf(e)) }
                }
            }
            true
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""; liveSearch?.let(handler::removeCallbacks)
                liveSearch = Runnable { loadEntries() }; handler.postDelayed(liveSearch!!, 500)
            }
        })
        loadEntries()
    }
    private fun loadEntries() {
        val mine = ++scanGeneration; scanJob?.cancel(true)
        val path = browsePath; val type = mediaType; val search = query; val currentMode = mode
        selectionText?.text = "Scanning…"
        scanJob = workers.submit {
            runCatching {
                val raw = if (currentMode == "favorites") prefs.favorites().filter { e ->
                    val p = e.diskPath.ifEmpty { e.location }
                    val underRoot = if (root.startsWith("content:")) e.location.startsWith(root.substringBefore("/document/"))
                        else p.startsWith(root.trimEnd('/') + "/") || (e.diskPath.isEmpty() && e.location.startsWith("content:") && root == "/storage/emulated/0")
                    underRoot && repo.matches(e.name, type) && repo.exists(e)
                } else if (currentMode == "folders" && search.isBlank() && path == root) repo.list(path,type,false) else repo.list(path, type, currentMode == "all_files" || search.isNotBlank())
                repo.sorted(raw.filter { (search.isBlank() || it.name.contains(search, true)) && (currentMode != "all_files" || mediaType != "audio" || repo.allowedInAllFiles(it)) }, prefs.str("sort", "A-Z"))
            }.onSuccess { found -> runOnUiThread {
                if (screen == "browse" && mine == scanGeneration) { entries = found; selected.retainAll(found.map { it.location }.toSet()); updateRows() }
            } }.onFailure { e -> runOnUiThread {
                if (screen == "browse" && mine == scanGeneration) { entries = emptyList(); updateRows(); error(e) }
            } }
        }
    }
    private fun updateRows() {
        val lv = list ?: return
        val first = lv.firstVisiblePosition; val offset = lv.getChildAt(0)?.top ?: 0
        val adapter = rowAdapter ?: object : ArrayAdapter<MediaEntry>(this,
            android.R.layout.simple_list_item_multiple_choice, rowData) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val item = getItem(position) ?: return view
                val label = (if (item.directory) "Folder, " else "") + item.name +
                    (if (prefs.favorite(item)) ", favorite" else "")
                if (view is TextView) {
                    view.text = item.name
                    view.textSize = 16f; view.setTextColor(Color.rgb(26, 46, 58)); view.minHeight = dp(56)
                }
                if (view is CheckedTextView) {
                    view.isChecked = item.location in selected
                    view.setCheckMarkDrawable(if (multi) R.drawable.selection_check else 0)
                }
                view.accessibilityDelegate=object:View.AccessibilityDelegate() {
                    override fun onInitializeAccessibilityNodeInfo(host:View,info:AccessibilityNodeInfo) {
                        super.onInitializeAccessibilityNodeInfo(host,info)
                        info.className=if(multi) "android.widget.CheckBox" else "android.widget.Button"
                        info.isClickable=true;info.isLongClickable=true
                        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)
                        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_LONG_CLICK)
                        if(Build.VERSION.SDK_INT>=28)info.isHeading=false
                        info.isCheckable=multi;info.isChecked=multi && item.location in selected
                    }
                }
                view.isClickable=true
                view.setOnClickListener { list?.performItemClick(view,position,getItemId(position)) }
                view.isLongClickable=true
                view.setOnLongClickListener { list?.onItemLongClickListener?.onItemLongClick(list,view,position,getItemId(position)) ?: false }
                view.tag = "row:" + item.location
                view.contentDescription = if (multi) (if (item.location in selected) "Selected, " else "Not selected, ") + label else label
                if (Build.VERSION.SDK_INT >= 30) view.stateDescription = when {
                    multi && item.location in selected -> "Selected"
                    multi -> "Not selected"
                    else -> null
                }
                return view
            }
        }.also { rowAdapter = it }
        if (rowData != entries) {
            rowData.clear(); rowData.addAll(entries); adapter.notifyDataSetChanged()
        } else {
            for (i in 0 until lv.childCount) {
                val item = entries.getOrNull(lv.firstVisiblePosition + i) ?: continue
                val child = lv.getChildAt(i)
                if (child is CheckedTextView) {
                    child.isChecked = item.location in selected
                    child.setCheckMarkDrawable(if (multi) R.drawable.selection_check else 0)
                    child.contentDescription = (if (multi) { if (child.isChecked) "Selected, " else "Not selected, " } else "") + item.name
                    if (Build.VERSION.SDK_INT >= 30) child.stateDescription = if (multi) { if (child.isChecked) "Selected" else "Not selected" } else null
                }
            }
        }
        if (lv.adapter !== adapter) lv.adapter = adapter
        if (!multi) lv.setSelectionFromTop(first, offset)
        val count = selected.size
        shareSelectedButton?.apply { text = "Share $count items"; contentDescription = text }
        deleteSelectedButton?.apply { text = "Delete $count items"; contentDescription = text }
        selectionBar?.visibility = if (multi) View.VISIBLE else View.GONE
        if (!multi) selectionText?.text = if (entries.isEmpty()) "No files found" else "${entries.size} items"
        else {
            val targets = entries.filter { it.location in selected }
            selectionText?.text = "${targets.size} selected • Calculating size…"
            val mine = ++statsGeneration; statsJob?.cancel(true)
            statsJob = workers.submit {
                val size = targets.sumOf { runCatching { repo.size(it) }.getOrDefault(0) }
                runOnUiThread {
                    if (mine == statsGeneration && multi && screen == "browse")
                        selectionText?.text = "${targets.size} selected • ${MediaRepository.formatSize(size)}"
                }
            }
        }
    }
    private fun rescanNow() {
        val path = browsePath; val type = mediaType
        workers.submit {
            runCatching { repo.rescan(path,type) { runOnUiThread {
                if (!isFinishing && !isDestroyed && screen == "browse" && browsePath == path) loadEntries()
            } } }.onFailure { e -> runOnUiThread { error(e) } }
        }
    }
    private fun sortMenu() {
        choose("Sort By", listOf("A-Z", "Z-A", "Newest First", "Oldest First")) { i ->
            prefs.put("sort", arrayOf("A-Z", "Z-A", "Newest", "Oldest")[i]); browseScreen()
        }
    }
    private fun browseBack() {
        if (multi) { multi = false; selected.clear(); updateRows(); speak("Selection cancelled"); return }
        if (query.isNotEmpty()) { query = ""; browseScreen(); return }
        if (browseParents.isNotEmpty()) {
            browsePath = browseParents.removeAt(browseParents.lastIndex)
            browseScreen(); return
        }
        if (mode == "folders" && browsePath != root && !browsePath.startsWith("content:")) {
            val parent = File(browsePath).parent
            if (parent != null && parent.startsWith(root)) { browsePath = parent; browseScreen(); return }
        }
        waOrigin?.let { business ->
            home(); whatsAppCategories(business); return
        }
        modeMenu()
    }
    private fun withService(action: (PlaybackService) -> Unit) {
        service?.let(action) ?: run { pendingAction = { service?.let(action) } }
    }
    private fun play(items: List<MediaEntry>, index: Int, position: Int = 0) {
        if(exiting || isFinishing || isDestroyed)return
        if (items.isEmpty()) { speak("No media files"); return }
        tutorialPlayer?.pause(); runCatching { splashSound?.release() }; splashSound = null
        pendingTitle = items.getOrNull(index.coerceAtLeast(0))?.name.orEmpty()
        if (screen == "browse") playerOriginKnown = true
        if (screen != "player") playerScreen()
        withService {
            it.pendingQueue = items
            val i = Intent(this, PlaybackService::class.java).setAction(PlaybackService.LOAD)
                .putExtra("index", index.coerceAtLeast(0)).putExtra("position", position)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            playerScreen()
        }
    }
    private fun restore() {
        val items = MediaEntry.decode(prefs.str("queue", "[]"))
        if (items.isEmpty()) { speak("Nothing to resume"); return }
        externalMode = false
        root = prefs.str("root", "/storage/emulated/0"); browsePath = prefs.str("folder", root)
        mediaType = prefs.str("mediaType", "audio"); mode = prefs.str("mode", "folders")
        play(items, prefs.long("queueIndex").toInt(), prefs.long("lastPosition").coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
    }
    private fun playerScreen() {
        makeScreen(getString(R.string.app_name), "player") { playerBack() }
        videoSurface = null
        playerHasVideo = service?.current?.let(repo::isVideo) == true
        val col = scroll()
        titleRef = text(service?.current?.name ?: pendingTitle, 20f).apply { gravity = Gravity.CENTER }
        col.addView(titleRef)
        timeRef = text("00:00 / 00:00").apply { gravity = Gravity.CENTER }; col.addView(timeRef)
        if (playerHasVideo) {
            val surface = android.view.SurfaceView(this).apply { keepScreenOn = true; setBackgroundColor(Color.BLACK) }
            videoSurface = surface
            col.addView(surface, LinearLayout.LayoutParams(-1, dp(230)))
            surface.holder.addCallback(object : android.view.SurfaceHolder.Callback {
                override fun surfaceCreated(holder: android.view.SurfaceHolder) { service?.setSurface(holder) }
                override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {}
                override fun surfaceDestroyed(holder: android.view.SurfaceHolder) { service?.setSurface(null) }
            })
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        seekRef = SeekBar(this).apply {
            tag = "seek";contentDescription="Playback position";minimumHeight=dp(48)
            isFocusable=true
            setOnTouchListener { view,event ->
                when(event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> { seeking=true;view.parent.requestDisallowInterceptTouchEvent(true) }
                    android.view.MotionEvent.ACTION_UP,android.view.MotionEvent.ACTION_CANCEL -> { seeking=false;view.parent.requestDisallowInterceptTouchEvent(false) }
                }
                false
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if(fromUser) {
                        desiredSeek=progress;seekHoldUntil=android.os.SystemClock.elapsedRealtime()+1200
                        timeRef?.text="${time(progress)} / ${time(service?.duration ?: 0)}"
                        service?.seek(progress.toLong())
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { seeking=true;sb?.parent?.requestDisallowInterceptTouchEvent(true) }
                override fun onStopTrackingTouch(sb: SeekBar?) { service?.seek(sb?.progress?.toLong() ?: 0);seeking=false;sb?.parent?.requestDisallowInterceptTouchEvent(false) }
            })
        }
        col.addView(seekRef)
        if (prefs.bool("showSleep")) {
            sleepRef = button("Sleep Mode: OFF") {
                if (service?.sleepActive == true) { service?.setSleep(false); speak("Sleep mode off") }
                else if (prefs.long("sleepDuration") > 0) { service?.setSleep(true); speak("Sleep mode on") }
                else sleepDialog()
            }; col.addView(sleepRef)
        }
        if (prefs.bool("showSpeed")) {
            speedRef = button("Playback Speed: ${speedLabel(prefs.speed)}") { speedMenu() }
            col.addView(speedRef)
        }
        if (prefs.bool("showBoost")) {
            boostRef = button("Volume Boost: Normal") {
                if (!prefs.bool("boostWarningSeen", false)) {
                    AlertDialog.Builder(this).setTitle("Volume boost warning")
                        .setMessage("Boost stages add 12, 25 or 40 decibels of gain and can distort audio or become painfully loud. The 1.5x/2x/3x names are labels, not measured loudness multipliers. Lower the volume first, especially with headphones.")
                        .setPositiveButton("Enable") { _, _ -> prefs.put("boostWarningSeen", true); service?.cycleBoost();updatePlayer() }
                        .show()
                } else service?.cycleBoost();updatePlayer()
            }; col.addView(boostRef)
        }
        if (!externalMode) {
            col.addView(button("Previous") { service?.previous() })
        }
        col.addView(button("Rewind ${prefs.ff / 1000} seconds") { service?.let { it.seek(it.position.toLong() - prefs.ff) } })
        playRef = button("Play") { service?.toggle() }; col.addView(playRef)
        col.addView(button("Fast Forward ${prefs.ff / 1000} seconds") { service?.let { it.seek(it.position.toLong() + prefs.ff) } })
        if (playerHasVideo) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; tag = "video-actions" }
            if (!externalMode) row.addView(button("Next") { service?.next() }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("Enter Full Screen") { setVideoFullScreen(!fullScreenVideo) }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("More Options") { moreOptions() }, LinearLayout.LayoutParams(0,-2,1f))
            col.addView(row)
        } else {
            if (!externalMode) col.addView(button("Next") { service?.next() })
            col.addView(button("More Options") { moreOptions() })
        }
        if (externalMode) {
            // External playback returns through the system Back gesture only.
        } else {
            col.addView(button("Exit") { exitApp() })
        }
        messageRef = text("", 13f).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        col.addView(messageRef)
        updatePlayer()
    }
    private fun setVideoFullScreen(enabled: Boolean) {
        val surface = videoSurface ?: return
        fullScreenVideo = enabled
        val column = surface.parent as? LinearLayout ?: return
        if (enabled) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            heading.parent.let { (it as? View)?.visibility = View.GONE }
            for (i in 0 until column.childCount) column.getChildAt(i).visibility = if (column.getChildAt(i) === surface) View.VISIBLE else View.GONE
            surface.layoutParams = LinearLayout.LayoutParams(-1, (body.height - body.paddingTop - body.paddingBottom).coerceAtLeast(dp(180)))
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            (heading.parent as? View)?.visibility = View.VISIBLE
            for (i in 0 until column.childCount) column.getChildAt(i).visibility = View.VISIBLE
            surface.layoutParams = LinearLayout.LayoutParams(-1, dp(230))
        }
    }
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (fullScreenVideo) body.post {
            videoSurface?.layoutParams = LinearLayout.LayoutParams(-1, (body.height - body.paddingTop - body.paddingBottom).coerceAtLeast(dp(180)))
        }
    }
    private fun backToCaller() {
        if(exiting)return
        exiting=true;startupGeneration++;startupDone=null;pendingAction=null
        updates.detach()
        service?.let { it.onChange=null;it.pendingQueue=null;it.closePlayback() }
        stopService(Intent(this,PlaybackService::class.java))
        getSystemService(android.app.NotificationManager::class.java).cancel(PlaybackService.ID)
        exitWithCue { finish() }
    }
    private fun speedLabel(speed:Float):String=if(kotlin.math.abs(speed-1f)<0.001f)"Normal" else "${speed}x"
    private fun bindControl(control:Button?,label:String) {
        control ?: return
        if(control.text.toString()!=label)control.text=label
        if(control.contentDescription?.toString()!=label)control.contentDescription=label
    }
    private fun updatePlayer() {
        val s = service ?: return
        titleRef?.text = s.current?.name ?: pendingTitle
        playRef?.text = if (s.isPlaying) "Pause" else "Play"
        playRef?.contentDescription = playRef?.text
        if (!seeking && android.os.SystemClock.elapsedRealtime()>seekHoldUntil) {
            seekRef?.max=s.duration
            seekRef?.progress=s.position
            timeRef?.text = "${time(s.position)} / ${time(s.duration)}"
        }
        seekRef?.isEnabled=s.canSeek
        sleepRef?.text = "Sleep Mode: ${if (s.sleepActive) "ON" else "OFF"}"
        bindControl(speedRef,"Playback Speed: ${speedLabel(s.speed)}")
        bindControl(boostRef,"Volume Boost: ${arrayOf("Normal", "1.5x", "2.0x", "3.0x")[s.boost]}")
        if (messageRef?.text?.toString() != s.message) messageRef?.text = s.message
    }
    private fun time(ms: Int): String {
        val seconds = (ms.coerceAtLeast(0) / 1000)
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }
    private fun playerBack() {
        service?.save()
        val folder = prefs.str("folder")
        if (folder.isNotEmpty()) {
            browsePath = folder; root = prefs.str("root", "/storage/emulated/0"); mediaType = prefs.str("mediaType", "audio"); mode = prefs.str("mode", "folders")
            query = ""; multi = false; selected.clear(); browseScreen()
        } else home()
    }
    private fun moreOptions() {
        val item = service?.current ?: return
        val status = mediaType == "statuses"
        val favorite = if (prefs.favorite(item)) "Remove from Favorite" else "Add to Favorite"
        val options = if (status) listOf("Share Status", "Save to Gallery")
        else listOf("Share", "Delete", favorite, "Rename")
        choose(item.name, options) { i ->
            when (options[i]) {
                "Share", "Share Status" -> if (status) statusShare(listOf(item)) else share(listOf(item))
                "Delete" -> confirmDelete(listOf(item))
                "Save to Gallery" -> saveGallery(listOf(item))
                favorite -> speak(if (prefs.toggleFavorite(item)) "Added to Favorites" else "Removed from Favorites")
                "Rename" -> rename(item)
            }
        }
    }
    private fun openImage(item: MediaEntry) {
        choose(item.name, listOf("Open Image", "Share Status", "Save to Gallery", "Delete")) { i ->
            when (i) {
                0 -> runCatching {
                    val uri = repo.shareUri(item)
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, repo.mime(item.name)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }.onFailure(::error)
                1 -> statusShare(listOf(item))
                2 -> saveGallery(listOf(item))
                3 -> confirmDelete(listOf(item))
            }
        }
    }
    private fun shareSelected() {
        val chosen = entries.filter { it.location in selected && !it.directory }
        if (chosen.isEmpty()) { speak("Select files to share. Folders cannot be shared directly."); return }
        if (mediaType == "statuses") statusShare(chosen) else share(chosen)
    }
    private fun statusShare(items: List<MediaEntry>) {
        AlertDialog.Builder(this).setTitle("Share Status")
            .setMessage("Pick WhatsApp or WhatsApp Business, then choose My status inside that app. The app shares your media securely; publishing the status stays in your hands.")
            .setPositiveButton("WhatsApp") { _, _ -> share(items, "com.whatsapp") }
            .setNegativeButton("WhatsApp Business") { _, _ -> share(items, "com.whatsapp.w4b") }
            .show()
    }
    private fun share(items: List<MediaEntry>, pkg: String? = null) {
        if (items.isEmpty()) return
        runCatching {
            if (pkg != null) {
                @Suppress("DEPRECATION") try { packageManager.getPackageInfo(pkg, 0) } catch (e: PackageManager.NameNotFoundException) {
                    speak(if (pkg.endsWith("w4b")) "No WhatsApp Business Found" else "WhatsApp is not installed"); return
                }
            }
            val uris = ArrayList(items.map(repo::shareUri))
            val types = items.map { repo.mime(it.name) }.distinct()
            val major = types.map { it.substringBefore('/') }.distinct()
            val mime = if (types.size == 1) types[0] else if (major.size == 1) "${major[0]}/*" else "*/*"
            val i = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = mime
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris[0]) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                clipData = ClipData.newUri(contentResolver, items[0].name, uris[0]).apply { uris.drop(1).forEach { addItem(ClipData.Item(it)) } }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (pkg != null) setPackage(pkg)
            }
            if (pkg == null) startActivity(Intent.createChooser(i, "Share Files")) else {
                try { startActivity(i) } catch (e: ActivityNotFoundException) {
                    i.setPackage(null); startActivity(Intent.createChooser(i, "Share Files"))
                }
            }
        }.onFailure(::error)
    }
    private fun saveGallery(items: List<MediaEntry>) {
        workers.submit {
            var saved = 0; val errors = mutableListOf<String>()
            items.forEach { item -> runCatching { repo.saveGallery(item) }.onSuccess { saved++ }.onFailure { errors.add("${item.name}: ${it.message}") } }
            runOnUiThread {
                speak("$saved status(es) saved to Download/Saved Statuses")
                if (errors.isNotEmpty()) error(IllegalStateException(errors.joinToString("\n")))
            }
        }
    }
    private fun confirmDelete(items: List<MediaEntry>) {
        if (items.isEmpty()) { speak("No items selected"); return }
        val dialog = AlertDialog.Builder(this).setTitle("Confirm Deletion")
            .setMessage("Calculating size…").setPositiveButton("Yes", null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
        workers.submit {
            val size = items.sumOf { runCatching { repo.size(it) }.getOrDefault(0) }
            runOnUiThread {
                if (!dialog.isShowing || isFinishing || isDestroyed) return@runOnUiThread
                dialog.setMessage("Permanently delete ${items.size} selected item(s) (${MediaRepository.formatSize(size)})? Folder deletion includes every file and subfolder. This cannot be undone.")
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).apply {
                    isEnabled = true
                    setOnClickListener { dialog.dismiss(); deleteItems(items) }
                }
            }
        }
    }
    private fun deletionCompleted(removed:List<MediaEntry>,fromPlayer:Boolean) {
        multi=false;selected.clear()
        if(removed.isNotEmpty()) {
            removed.forEach { prefs.removeFavorite(it.location) }
            service?.removeDeleted(removed)
        }
        if(fromPlayer) { if(service?.current==null)pendingTitle="";updatePlayer() }
        else if(screen=="browse")loadEntries()
    }
    private fun requestMutationAccess(item:MediaEntry,deleting:Boolean,problem:Throwable,resolved:MediaEntry=item,retry:()->Unit) {
        AppLog.record(this,if(deleting) "Delete permission" else "Rename permission",problem)
        if(problem !is SecurityException && problem !is IllegalStateException) {
            error(problem);return
        }
        if(editableOverrides.remove(item.location)!=null) {
            service?.resume();error(SecurityException("This provider did not allow editing the original file. Use its source app."));return
        }
        permissionEntry=item;permissionAction=retry
        try {
            if(Build.VERSION.SDK_INT==29 && problem is android.app.RecoverableSecurityException) {
                startIntentSenderForResult(problem.userAction.actionIntent.intentSender,EDIT_CONSENT,null,0,0,0);return
            }
            val uri=repo.mediaStoreUri(resolved)
            if(Build.VERSION.SDK_INT>=30 && uri!=null) {
                val consent=if(deleting)android.provider.MediaStore.createDeleteRequest(contentResolver,listOf(uri)) else android.provider.MediaStore.createWriteRequest(contentResolver,listOf(uri))
                if(deleting) {
                    val wasPlayer=screen=="player"
                    permissionAction={ repo.invalidate();deletionCompleted(listOf(item),wasPlayer) }
                } else editableOverrides[item.location]=item.copy(location=uri.toString())
                startIntentSenderForResult(consent.intentSender,EDIT_CONSENT,null,0,0,0);return
            }
        } catch(_:Exception) { /* The source may not expose an editable MediaStore item. Ask its document provider. */ }
        // The in-app Yes has already been given. Go straight to Android's required grant flow.
        runCatching {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type=repo.mime(item.name);addCategory(Intent.CATEGORY_OPENABLE)
                if(android.provider.DocumentsContract.isDocumentUri(this@MainActivity,Uri.parse(item.location)))putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI,Uri.parse(item.location))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },EDIT_DOCUMENT)
        }.onFailure(::error)
    }
    private fun deleteItems(items:List<MediaEntry>) {
        val fromPlayer=screen=="player"
        val currentRemoved=items.any { service?.contains(it)==true }
        if(currentRemoved)service?.suspendForDeletion()
        workers.submit {
            val removed=mutableListOf<MediaEntry>();var denied:Triple<MediaEntry,Throwable,MediaEntry>?=null
            items.forEach { item ->
                val editable=editableOverrides[item.location] ?: runCatching { repo.resolveMutationEntry(repo.editableEntry(item)) }.getOrDefault(item)
                try { if(repo.delete(editable))removed.add(item) else if(denied==null)denied=Triple(item,SecurityException("Delete access required"),editable) }
                catch(e:Exception) { AppLog.record(this,"Delete",e);if(denied==null)denied=Triple(item,e,editable) }
            }
            repo.invalidate()
            runOnUiThread {
                if(removed.isNotEmpty())deletionCompleted(removed,fromPlayer)
                val failure=denied
                if(failure!=null)requestMutationAccess(failure.first,true,failure.second,failure.third) { deleteItems(listOf(failure.first)) }
                else if(removed.isEmpty() && currentRemoved)service?.resume()
            }
        }
    }
    private fun performRename(item:MediaEntry,full:String,dialog:AlertDialog?=null) {
        workers.submit {
            val editable=editableOverrides[item.location] ?: runCatching { repo.resolveMutationEntry(repo.editableEntry(item)) }.getOrDefault(item)
            try {
                if(repo.duplicateExists(editable,full))throw DuplicateNameException()
                val replacement=repo.rename(editable,full)
                runOnUiThread {
                    dialog?.dismiss();prefs.renameFavorite(item.location,replacement)
                    service?.replaceEntry(item,replacement)
                    if(screen=="browse")loadEntries() else updatePlayer()
                }
            } catch(e:DuplicateNameException) {
                runOnUiThread { Toast.makeText(this,"Cannot rename this file. Already one file is present.",Toast.LENGTH_LONG).show() }
            } catch(e:Exception) {
                runOnUiThread { requestMutationAccess(item,false,e,editable) { performRename(item,full,dialog) } }
            }
        }
    }
    private fun rename(item:MediaEntry) {
        val f=File(item.name)
        val input=EditText(this).apply { setSingleLine(true);setText(f.nameWithoutExtension);selectAll();contentDescription="New file name without extension" }
        val d=AlertDialog.Builder(this).setTitle("Rename File").setView(input).setPositiveButton("Yes",null).create()
        d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val name=input.text.toString().trim()
            if(name.isBlank() || name.contains('/') || name.contains('\\'))input.error="Enter a valid file name"
            else performRename(item,name+(if(f.extension.isEmpty()) "" else ".${f.extension}"),d)
        } }
        d.show()
    }
    private fun settingsMenu() {
        makeScreen("Settings", "settings")
        val col = scroll()
        col.addView(button("Audio Settings") { audioSettings() })
        col.addView(button("WhatsApp Manager") { whatsAppManager() })
        toggle(col, "Multi-Select Mode", "multiSelect")
        toggle(col, "Check Automatic Update", "autoUpdate")
        col.addView(button("Permission Manager") { accessMenu() })
        val sounds=android.widget.CheckBox(this).apply {
            text="Play sound while opening or exiting this app";tag="app-sounds"
            isChecked=prefs.bool("playAppSounds",true)
            setOnCheckedChangeListener { _,checked -> prefs.put("playAppSounds",checked) }
        }
        col.addView(sounds,LinearLayout.LayoutParams(-1,-2))
        col.addView(button("About") { about() })
    }
    private fun onOff(value: Boolean) = if (value) "ON" else "OFF"
    private fun openAppInfo() {
        runCatching { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }.onFailure(::error)
    }
    private fun audioSettings() {
        makeScreen("Audio Settings", "audioSettings") { settingsMenu() }
        val col = scroll()
        col.addView(button("Fast Forward and Rewind: ${prefs.ff / 1000} Seconds") { durationMenu() }.apply { tag="duration-setting" })
        toggle(col, "Background Playback", "background")
        toggle(col, "Auto Play Next File", "autoPlay")
        col.addView(button("Playback Speed: ${speedLabel(prefs.speed)}") { speedMenu() }.apply { tag = "speed-setting" })
        toggle(col, "Show Playback Speed on Player", "showSpeed")
        col.addView(button("Set Sleep Timer Duration") { sleepDialog() })
        toggle(col, "Show Volume Boost on Player", "showBoost")
        toggle(col, "Show Sleep Timer on Player", "showSleep")
        val bypassRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "bypass-row" }
        val desc = text("Bypass Bluetooth",16f).apply { tag = "bypass-description" }
        val channel = button(PlayerAudioChannels.label(prefs.str("bypassChannel","media"))) { }.apply { tag = "bypass-channel" }
        channel.setOnClickListener {
            choose("Audio Channel", PlayerAudioChannels.choices.map { it.second }) { i ->
                val key = PlayerAudioChannels.choices[i].first
                prefs.put("bypassChannel",key); channel.text = PlayerAudioChannels.label(key); channel.contentDescription = channel.text
                service?.reloadAudioChannel()
            }
        }
        val toggle = Switch(this).apply { tag = "toggle:bypass"; contentDescription = "Bypass Bluetooth"; isChecked = prefs.bool("bypass",false); minHeight = dp(58) }
        toggle.setOnCheckedChangeListener { _, enabled ->
            prefs.put("bypass",enabled)
            if (enabled && Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_PERMISSIONS)
            service?.reloadAudioChannel()
        }
        bypassRow.addView(desc, LinearLayout.LayoutParams(0,-2,1f))
        bypassRow.addView(channel, LinearLayout.LayoutParams(0,-2,1f))
        bypassRow.addView(toggle, LinearLayout.LayoutParams(-2,-2))
        col.addView(bypassRow)
        col.addView(text("Bluetooth Bypass keeps this player's media on the connected Bluetooth device when Android allows it. A screen reader controls its own speech output; select Phone speaker in its audio settings if available. This app cannot force another app's output.", 13f))
    }
    private fun whatsAppManager() {
        makeScreen("WhatsApp Manager", "whatsAppManager") { settingsMenu() }
        val col = scroll()
        toggle(col,"Show WhatsApp Media in Main Menu","showWhatsApp")
        toggle(col, "Show WhatsApp Official", "waOfficial")
        for ((name, key) in listOf("Audio" to "audio", "Video" to "video", "Voice Notes" to "voice", "Statuses" to "statuses"))
            toggle(col, "WhatsApp $name", "wa_official_$key")
        toggle(col, "Show WhatsApp Business", "waBusiness")
        for ((name, key) in listOf("Audio" to "audio", "Video" to "video", "Voice Notes" to "voice", "Statuses" to "statuses"))
            toggle(col, "WhatsApp Business $name", "wa_business_$key")
        toggle(col, "Show WhatsApp Voice Notes in All Files", "voiceNotesInAll")
        toggle(col, "Show Images in Status Folder", "statusImages")
        toggle(col, "Show Videos in Status Folder", "statusVideos")
    }
    private fun durationMenu() {
        val values=prefs.durations.toMutableList()
        val rows=mutableListOf<String>()
        fun refill() { rows.clear();rows.addAll(values.map { "${it/1000} Seconds" });rows.add("Add Custom Duration…") }
        refill()
        val adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,rows)
        val lv=ListView(this).apply { this.adapter=adapter }
        val d=AlertDialog.Builder(this).setTitle("FF/RW Duration • Long-press to delete").setView(lv).create()
        fun selected(duration:Long) {
            prefs.ff=duration
            (findTagged(shell,"duration-setting") as? Button)?.apply { text="Fast Forward and Rewind: ${duration/1000} Seconds";contentDescription=text }
        }
        lv.setOnItemClickListener { _,_,index,_->
            if(index==values.size) {
                val field=EditText(this).apply { hint="Seconds, e.g. 25";inputType=InputType.TYPE_CLASS_NUMBER }
                val add=AlertDialog.Builder(this).setTitle("Enter Custom Duration").setView(field).setPositiveButton("Set",null).create()
                add.setOnShowListener { add.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val seconds=field.text.toString().toLongOrNull()
                    if(seconds==null || seconds<=0 || seconds>Int.MAX_VALUE/1000)field.error="Enter a positive duration"
                    else {
                        if(!values.contains(seconds*1000))values.add(seconds*1000)
                        prefs.durations=values.toList();selected(seconds*1000);refill();adapter.notifyDataSetChanged()
                        add.getButton(AlertDialog.BUTTON_POSITIVE).announceForAccessibility("Set to $seconds seconds")
                    }
                } }
                add.show()
            } else { selected(values[index]);lv.getChildAt(index-lv.firstVisiblePosition)?.announceForAccessibility("${values[index]/1000} seconds selected") }
        }
        lv.setOnItemLongClickListener { _,_,index,_->
            if(index<values.size)AlertDialog.Builder(this).setTitle("Delete Duration?").setPositiveButton("Delete") { _,_->
                values.removeAt(index);prefs.durations=values.toList();selected(10000);refill();adapter.notifyDataSetChanged()
            }.show()
            true
        }
        d.show()
    }
    private fun speedMenu() {
        val values = floatArrayOf(0.5f, 0.8f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 2.75f, 3f, 3.5f, 3.75f, 4f)
        val labels = values.map { speedLabel(it)+(if(kotlin.math.abs(it-prefs.speed)<0.01f)" (Active)" else "") }
        choose("Playback Speed", labels) { i ->
            prefs.speed=values[i];service?.setSpeed(values[i])
            bindControl(speedRef,"Playback Speed: ${speedLabel(values[i])}")
            speak("Playback speed ${speedLabel(values[i])}")
            if (screen == "audioSettings") (findTagged(shell, "speed-setting") as? Button)?.apply {
                text = "Playback Speed: ${speedLabel(values[i])}"; contentDescription = text
            } else updatePlayer()
        }
    }
    private fun sleepDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12)) }
        val fields = listOf("Hours", "Minutes", "Seconds").map { hint ->
            EditText(this).apply { this.hint = hint; contentDescription = hint; inputType = InputType.TYPE_CLASS_NUMBER; col.addView(this) }
        }
        val d = AlertDialog.Builder(this).setTitle("Sleep Timer Manager").setView(col).setPositiveButton("Set Timer", null).create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val values = fields.map { if (it.text.isBlank()) 0L else it.text.toString().toLongOrNull() ?: -1L }
                if (values.any { it < 0 || it > 1000000 }) { fields[0].error = "Invalid duration"; return@setOnClickListener }
                val total = (values[0] * 3600 + values[1] * 60 + values[2]) * 1000
                if (total <= 0) { fields[0].error = "Enter a positive duration"; return@setOnClickListener }
                prefs.put("sleepDuration", total); service?.setSleep(true); speak("Sleep timer on for ${total / 1000} seconds"); d.dismiss()
                if (screen == "player") updatePlayer()
            }
        }; d.show()
    }
    private fun whatsAppMenu() {
        if (screen == "browse") home()
        val apps = mutableListOf<Pair<String, Boolean>>()
        if (prefs.bool("waOfficial")) apps.add("WhatsApp" to false)
        if (prefs.bool("waBusiness")) apps.add("WhatsApp Business" to true)
        choose("WhatsApp Media", apps.map { it.first }) { whatsAppCategories(apps[it].second) }
    }
    private fun whatsAppCategories(business: Boolean) {
        if (screen == "browse") home()
        val prefix = if (business) "WhatsApp Business" else "WhatsApp"
        val setting = if (business) "business" else "official"
        val cats = listOf(Triple("Audio", "audio", 0), Triple("Voice Notes", "voice", 1), Triple("Video", "video", 2), Triple("Statuses", "statuses", 3))
            .filter { prefs.bool("wa_${setting}_${it.second}") }
        choose(prefix, cats.map { "$prefix ${it.first}" }, { whatsAppMenu() }) { i ->
            openWhatsAppCategory(business, cats[i].third, if (business) "com.whatsapp.w4b" else "com.whatsapp", prefix)
        }
    }
    /** Resolves the requested WhatsApp folder itself, without asking the user again. */
    private fun openWhatsAppCategory(business: Boolean, cat: Int, pkg: String, prefix: String) {
        waOrigin = business
        mediaType = when (cat) { 2 -> "video"; 3 -> "statuses"; else -> "audio" }
        val sub = when (cat) { 0 -> "$prefix Audio"; 1 -> "$prefix Voice Notes"; 2 -> "$prefix Video"; else -> ".Statuses" }
        val key = "wa_${if (business) 2 else 1}_$cat"
        val saved = prefs.str(key)
        val candidates = linkedSetOf<String>()
        if (saved.isNotBlank()) candidates.add(saved)
        candidates.add("/storage/emulated/0/Android/media/$pkg/$prefix/Media/$sub")
        candidates.add("/storage/emulated/0/$prefix/Media/$sub")
        candidates.add("/storage/emulated/0/Android/media/$pkg/$prefix/Media/$sub".replace(prefix, if (business) "WhatsApp Business" else "WhatsApp"))
        speak("Opening $sub")
        workers.submit {
            var chosen: String? = null
            for (candidate in candidates) {
                val found = runCatching { repo.list(candidate, mediaType, false) }.getOrDefault(emptyList())
                val folderExists = candidate.startsWith("content:") || File(candidate).isDirectory
                if (found.isNotEmpty() || folderExists) { chosen = candidate; break }
            }
            runOnUiThread {
                if (chosen != null) {
                    root = chosen!!; browsePath = chosen!!; mode = "folders"; query = ""; multi = false; selected.clear(); browseParents.clear()
                    prefs.put(key, chosen!!)
                    browseScreen()
                } else {
                    AlertDialog.Builder(this).setTitle("$sub folder")
                        .setMessage("This folder is not readable yet. WhatsApp Statuses are hidden and need All files access, or you can point the app at the folder once and it will be remembered.\n\nFor audio, voice notes and video, granting media access is normally enough.")
                        .setPositiveButton("Point to folder") { _, _ -> chooseFolder(key) }
                        .setNeutralButton("Access options") { _, _ -> accessMenu() }
                        .setNegativeButton("Close", null).show()
                }
            }
        }
    }
    private fun accessMenu() {
        val entries=mutableListOf("Allow Media / Notifications")
        if(Build.VERSION.SDK_INT>=30)entries.add("All Files Access: ${onOff(runCatching { Environment.isExternalStorageManager() }.getOrDefault(false))}")
        entries.add("App Info")
        val lv=ListView(this)
        lv.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,entries)
        val d=AlertDialog.Builder(this).setTitle("Permission Manager").setView(lv).create()
        permissionDialog=d
        lv.setOnItemClickListener { _,view,index,_->
            view.isSelected=true
            when {
                index==0 -> {
                    val p=if(Build.VERSION.SDK_INT>=33)listOf(Manifest.permission.READ_MEDIA_AUDIO,Manifest.permission.READ_MEDIA_VIDEO,Manifest.permission.READ_MEDIA_IMAGES,Manifest.permission.POST_NOTIFICATIONS)
                        else if(Build.VERSION.SDK_INT<=29)listOf(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    val missing=p.filter { checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED }
                    if(missing.isNotEmpty())requestPermissions(missing.toTypedArray(),REQUEST_PERMISSIONS) else view.announceForAccessibility("Permissions already granted")
                }
                index==1 && Build.VERSION.SDK_INT>=30 -> runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:$packageName"))) }.onFailure { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                else -> openAppInfo()
            }
        }
        d.setOnDismissListener { if(permissionDialog===d)permissionDialog=null }
        d.show()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            speak(if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) "Permissions updated" else "Some permissions were not granted. Open with and folder grants still work.")
            if (screen == "browse") loadEntries()
        }
    }
    private fun about() {
        makeScreen("About", "about") { settingsMenu() }
        val col = scroll()
        col.addView(text(getString(R.string.app_name), 20f))
        fun detail(label:String,heading:Boolean=false) = text(label,if(heading)18f else 16f).apply {
            isFocusable=true;importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_YES
            setPadding(0,dp(8),0,dp(8));if(Build.VERSION.SDK_INT>=28)isAccessibilityHeading=heading
        }
        col.addView(detail("Swift Player makes local audio and video easier to browse and play with screen-reader-friendly controls. Scan internal storage or an SD card, organize favorites, or open supported files directly from another app."))
        col.addView(detail("Adjust playback speed and volume boost, use the sleep timer, and return to your last listening position. Use Permission Manager to review access and the tutorial to learn the controls. Updates are downloaded only when you choose Download."))
        col.addView(detail("Credit for App Development",true))
        col.addView(detail("Ahmad Ali: Came up with the idea for this application."))
        col.addView(detail("Ali Gujjar: Developed this application."))
        col.addView(detail("Azlan Tahir: Tested this application."))
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_LTR }
        val tester=button("Swift Player Tester") { testerScreen() }.apply { id=View.generateViewId() }
        val check=button("Check for update") { updates.check(true) }.apply { id=View.generateViewId() }
        tester.accessibilityTraversalBefore=check.id
        row.addView(tester,LinearLayout.LayoutParams(0,-2,1f));row.addView(check,LinearLayout.LayoutParams(0,-2,1f));col.addView(row)
        col.addView(button("Contact us") { contactFeedback() })
        col.addView(button("Tutorial in MP3") { tutorialList() })
    }
    private fun testerScreen() {
        makeScreen("Swift Player Tester","tester") { about() }
        val col=scroll()
        val consent=android.widget.CheckBox(this).apply {
            text="Test all bugs and features in this app";tag="tester-consent"
            // Each test is explicitly started by the user, never automatically.
            isChecked=false
        }
        val scan=button("Scan") {}.apply { tag="tester-scan";visibility=View.GONE }
        col.addView(consent);col.addView(scan)
        col.addView(text("Checks this device, settings and isolated test files. Media tests are silent. Your library and playback are not modified. Features that need your interaction are marked for manual testing.",13f))
        consent.setOnCheckedChangeListener { _,checked -> scan.visibility=if(checked)View.VISIBLE else View.GONE;AppLog.enable(this,checked) }
        scan.setOnClickListener {
            if(!consent.isChecked)return@setOnClickListener
            val modes=SwiftPlayerTester.Mode.entries
            AlertDialog.Builder(this).setTitle("Choose scan type").setItems(modes.map { it.label }.toTypedArray()) { _,which ->
            consent.isEnabled=false;scan.isEnabled=false;scan.text="Testing…"
            workers.submit {
                runCatching { SwiftPlayerTester.scan(this,modes[which]) }.onSuccess { file -> runOnUiThread {
                    if(!isDestroyed && !isFinishing) {
                        consent.isEnabled=true;scan.isEnabled=true;scan.text="Scan";showTesterReport(file)
                    }
                } }.onFailure { e -> runOnUiThread { consent.isEnabled=true;scan.isEnabled=true;scan.text="Scan";error(e) } }
            }
            }.show()
        }
    }
    private fun showTesterReport(file:File) {
        val col=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(8)) }
        col.addView(text("Swift Player Tester",20f))
        val details=text(file.readText(),14f).apply { setTextIsSelectable(true) }
        col.addView(ScrollView(this).apply { addView(details) },LinearLayout.LayoutParams(-1,0,1f))
        col.addView(button("Share") {
            runCatching {
                val uri=ShareProvider.uri(this,file)
                val send=Intent(Intent.ACTION_SEND).apply {
                    type="text/plain";putExtra(Intent.EXTRA_STREAM,uri)
                    clipData=ClipData.newRawUri("Swift Player Tester",uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send,"Share tester report"))
            }.onFailure(::error)
        })
        val dialog=AlertDialog.Builder(this).setView(col).create()
        dialog.show();dialog.window?.setLayout(-1,(resources.displayMetrics.heightPixels*0.85).toInt())
    }
    private fun contactFeedback() {
        val processor = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL
            else listOf(Build.HARDWARE, Build.BOARD).distinct().joinToString(" / ")
        val message = "Name:\nDevice Brand/Company: ${Build.MANUFACTURER}\nDevice Model: ${Build.MODEL}\nAndroid Version: ${Build.VERSION.RELEASE}\nProcessor: $processor\n\nNote This device information is collected only for troubleshooting and resolving app issues and for no other purpose\n\nIssue or feedback:\n"
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=923477583735&text=" + Uri.encode(message)))) }.onFailure { copy(message) }
    }
    private fun tutorialList() {
        choose("Tutorial in MP3", listOf("How to use Swift Player")) { tutorialDownload() }
    }
    private fun tutorialDownload() {
        stopTutorial()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        col.addView(text("How to use Swift Player", 18f))
        val status = text("Ready to download this tutorial.", 14f); col.addView(status)
        val download = button("Download") {}; col.addView(download)
        val cancel = Button(this).apply { visibility = View.GONE }
        val play = button("Play") {}; play.visibility = View.GONE; col.addView(play)
        val times = text("00:00 / 00:00", 13f).apply { visibility = View.GONE }; col.addView(times)
        val seek = SeekBar(this).apply { visibility = View.GONE; contentDescription = "Tutorial playback position" }; col.addView(seek)
        val rewind = button("Rewind 10 seconds") { tutorialPlayer?.let { mp -> runCatching { mp.seekTo((mp.currentPosition - 10000).coerceAtLeast(0)) } } }.apply { visibility = View.GONE }; col.addView(rewind)
        val pause = button("Pause") { tutorialPlayer?.let { mp -> runCatching { if (mp.isPlaying) mp.pause() else mp.start() } } }.apply { visibility = View.GONE }; col.addView(pause)
        val forward = button("Fast Forward 10 seconds") { tutorialPlayer?.let { mp -> runCatching { mp.seekTo((mp.currentPosition + 10000).coerceAtMost(mp.duration)) } } }.apply { visibility = View.GONE }; col.addView(forward)
        // System Back dismisses the tutorial without adding another UI navigation button.
        val sv = ScrollView(this).apply { addView(col) }
        val dialog = AlertDialog.Builder(this).setView(sv).setCancelable(true).create()
        tutorialDialog = dialog; dialog.show()
        val local=PrivateDownloads.target(File(filesDir,"tutorial"),Uri.parse(TUTORIAL_URL).lastPathSegment!!)
        fun ready(label:String) {
            status.text=label;download.visibility=View.GONE;play.visibility=View.VISIBLE
        }
        if(local.isFile && local.length()>0)ready("Already downloaded.")
        download.setOnClickListener {
            download.visibility=View.GONE;status.text="Downloading in progress…"
            tutorialTransfer=workers.submit {
                var last=-1L
                runCatching { PrivateDownloads.fetch(TUTORIAL_URL,local,50L*1024*1024,progress={done,total ->
                    val percent=if(total>0)done*100/total else -1
                    if(percent!=last) { last=percent;handler.post { if(dialog.isShowing)status.text="Downloading in progress… $percent%" } }
                },validate={ file ->
                    val retriever=android.media.MediaMetadataRetriever()
                    try { retriever.setDataSource(file.absolutePath);check((retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0)>0) { "Invalid tutorial audio" } }
                    finally { retriever.release() }
                }) }.onSuccess { handler.post { if(dialog.isShowing)ready("Download Successfully") } }
                    .onFailure { e -> handler.post { if(dialog.isShowing) { status.text="Download failed: ${e.message}";download.text="Try Again";download.visibility=View.VISIBLE } } }
            }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) runCatching { tutorialPlayer?.seekTo(progress) } }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        play.setOnClickListener {
            if(!local.isFile)return@setOnClickListener
            service?.pause()
            tutorialPlayer?.release()
            val mp = MediaPlayer(); tutorialPlayer = mp
            try {
                mp.setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                mp.setDataSource(local.absolutePath)
                mp.setOnPreparedListener {
                    if (tutorialPlayer !== it || !dialog.isShowing) return@setOnPreparedListener
                    play.visibility = View.GONE; cancel.visibility = View.GONE; download.visibility = View.GONE
                    listOf(times, seek, rewind, pause, forward).forEach { v -> v.visibility = View.VISIBLE }
                    it.start(); seek.max = it.duration
                    tutorialPlaybackTick = object : Runnable {
                        override fun run() {
                            if (tutorialPlayer == null || !dialog.isShowing) return
                            runCatching { seek.progress = mp.currentPosition; times.text = "${time(mp.currentPosition)} / ${time(mp.duration)}"; pause.text = if (mp.isPlaying) "Pause" else "Play" }
                            handler.postDelayed(this, 500)
                        }
                    }; handler.post(tutorialPlaybackTick!!)
                }
                mp.setOnErrorListener { _, what, extra -> status.text = "Tutorial playback error ($what/$extra)"; true }
                status.text = "How to use Swift Player"; mp.prepareAsync()
            } catch (e: Exception) { status.text = "Playback failed: ${e.message}" }
        }
        dialog.setOnDismissListener { stopTutorial() }
    }
    private fun stopTutorial() {
        tutorialTransfer?.cancel(true);tutorialTransfer=null
        tutorialPlaybackTick?.let(handler::removeCallbacks); tutorialPlaybackTick = null
        runCatching { tutorialPlayer?.release() }; tutorialPlayer = null
    }
    private fun announce(message: String) {
        val manager = getSystemService(AccessibilityManager::class.java)
        if (manager.isEnabled) shell.announceForAccessibility(message)
        // Ordinary feedback has no Android Toast, avoiding the automatic app-name prefix.
    }
    private fun speak(message: String) {
        if (isDestroyed || isFinishing) return
        announce(message)
        val manager = getSystemService(AccessibilityManager::class.java)
        if (!manager.isEnabled && prefs.bool("spokenFeedback") && speechReady)
            speech?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "smart-player-message")
    }
    private fun copy(message: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Swift Player Error", message)); speak("Copied to clipboard")
    }
    private fun error(e: Throwable) {
        AppLog.record(this,"App operation",e)
        if (isFinishing || isDestroyed) return
        val message = "${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
        val field = EditText(this).apply { setText(message); setTextIsSelectable(true); contentDescription = "Error details" }
        AlertDialog.Builder(this).setTitle("Problem").setView(ScrollView(this).apply { addView(field) })
            .setPositiveButton("Copy") { _, _ -> copy(message) }.setNegativeButton("Close", null).show()
    }
    override fun onResume() {
        super.onResume()
        if (::prefs.isInitialized && screen == "browse") loadEntries()
        if (::updates.isInitialized) { updates.attach(); updates.installPendingIfPermitted() }
    }
    override fun onStop() {
        if (::prefs.isInitialized && !prefs.bool("background") && !isChangingConfigurations) service?.pause()
        if (tutorialPlayer != null) runCatching { tutorialPlayer?.pause() }
        service?.save(); if (::updates.isInitialized) updates.detach(); super.onStop()
    }
    // API 33+ is handled by the native OnBackInvokedDispatcher registered in onCreate.
    // Keep this override only for the Android 8-12 physical/gesture back path.
    @android.annotation.SuppressLint("GestureBackNavigation")
    @Deprecated("Legacy Android 8-12 back navigation")
    override fun onBackPressed() { navigateBack() }
    private fun navigateBack() {
        if(screen=="splash") {
            startupGeneration++;startupDone=null
            if(intent.action in listOf(Intent.ACTION_VIEW,Intent.ACTION_SEND,Intent.ACTION_SEND_MULTIPLE))backToCaller() else exitApp()
            return
        }
        if (screen == "player" && externalMode) backToCaller() else if (fullScreenVideo) setVideoFullScreen(false) else backAction()
    }
    override fun onDestroy() {
        service?.save(); service?.onChange = null; service?.setSurface(null)
        if (bound) { runCatching { unbindService(connected) }; bound = false }
        scanJob?.cancel(true); statsJob?.cancel(true); workers.shutdownNow()
        stopTutorial(); tutorialDialog?.dismiss(); handler.removeCallbacksAndMessages(null)
        runCatching { splashSound?.release() }; splashSound = null
        speech?.stop(); speech?.shutdown(); speech = null
        repo.close()
        if (::updates.isInitialized) updates.close()
        super.onDestroy()
    }
    companion object {
        const val EDIT_CONSENT=119
        const val EDIT_DOCUMENT=120
        const val OPEN_TREE = 111
        const val REQUEST_PERMISSIONS = 112
        const val TUTORIAL_URL = "https://raw.githubusercontent.com/ali71rb-star/-.-Swift-Player-created-by-A-brothers/main/How%20to%20use%20Swift%20Player%20created%20by%20A%20brothers.mp3"
    }
}
