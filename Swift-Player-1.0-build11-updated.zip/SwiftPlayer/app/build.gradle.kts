import java.security.KeyStore
import java.security.MessageDigest
plugins { id("com.android.application") }
android {
    namespace = "com.abrothers.swiftplayer"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.abrothers.swiftplayer"
        minSdk = 26
        targetSdk = 37
        versionCode = 11
        versionName = "1.0"
    }
    buildFeatures { buildConfig = true }
    signingConfigs { create("eliteRelease") {
        storeFile = file(System.getenv("ELITE_KEYSTORE") ?: "../signing/elite-release.p12")
        storePassword = System.getenv("ELITE_STORE_PASSWORD")
        keyAlias = "elite-player"
        keyPassword = System.getenv("ELITE_STORE_PASSWORD")
    } }
    buildTypes { getByName("release") {
        isMinifyEnabled = true
        isShrinkResources = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        isDebuggable = false
        signingConfig = signingConfigs.getByName("eliteRelease")
    } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildToolsVersion = "37.0.0"
    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all { it.maxHeapSize = "512m"; it.maxParallelForks = 1 }
    }
}
dependencies {
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}

kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

val verifyReleaseCertificate by tasks.registering {
    doLast {
        val path=System.getenv("ELITE_KEYSTORE") ?: error("Set ELITE_KEYSTORE to the original Swift release keystore")
        val password=System.getenv("ELITE_STORE_PASSWORD")?.toCharArray() ?: error("Set ELITE_STORE_PASSWORD")
        try {
            val store=KeyStore.getInstance("PKCS12")
            file(path).inputStream().use { store.load(it,password) }
            check(store.isKeyEntry("elite-player")) { "Release private key alias elite-player not found" }
            val cert=store.getCertificate("elite-player")
            val hash=MessageDigest.getInstance("SHA-256").digest(cert.encoded).joinToString("") { "%02x".format(it) }
            check(hash=="9a04a395fd00ec6556597f12a25c41ee9d7d4cc09128dd01e85895acb425e7ac") { "Wrong Swift release certificate. Use the original keystore." }
        } finally { password.fill('\u0000') }
    }
}
tasks.matching { it.name=="validateSigningRelease" }.configureEach { dependsOn(verifyReleaseCertificate) }
