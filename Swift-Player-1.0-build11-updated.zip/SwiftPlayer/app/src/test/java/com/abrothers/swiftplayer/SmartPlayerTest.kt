package com.abrothers.swiftplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper
import java.io.File
import java.util.concurrent.TimeUnit

/** JVM/Android-shadow checks; physical-device codec, routing and WhatsApp tests remain unconfirmed. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 28, 35])
class SmartPlayerTest {
    private lateinit var context: Context
    private lateinit var prefs: PlayerPrefs
    private lateinit var repo: MediaRepository
    private lateinit var temp: File
    @Before fun setup() {
        context = RuntimeEnvironment.getApplication()
        prefs = PlayerPrefs(context); prefs.raw.edit().clear().commit()
        prefs.put("autoUpdate", false)
        repo = MediaRepository(context)
        temp = File(context.cacheDir, "repository-test").apply { mkdirs() }
    }
    @After fun cleanup() { temp.deleteRecursively() }
    @Test fun completeOriginalAudioFormatList() {
        listOf("mp3", "m4a", "wav", "ogg", "amr", "opus", "aac").forEach { assertTrue(it, repo.matches("File.$it", "audio")) }
        assertTrue(repo.matches("FILE.MP3", "audio")); assertFalse(repo.matches("text.txt", "audio"))
        assertFalse(repo.matches("mp3.exe", "audio"))
    }
    @Test fun completeOriginalVideoFormatList() {
        listOf("mp4", "mkv", "3gp").forEach { assertTrue(repo.matches("video.$it", "video")) }
        assertFalse(repo.matches("sound.mp3", "video"))
    }
    @Test fun statusImageVideoVisibilityToggles() {
        assertTrue(repo.matches("status.jpg", "statuses")); assertTrue(repo.matches("status.mp4", "statuses"))
        prefs.put("statusImages", false); assertFalse(repo.matches("status.jpg", "statuses")); assertTrue(repo.matches("status.mp4", "statuses"))
        prefs.put("statusVideos", false); assertFalse(repo.matches("status.mp4", "statuses"))
    }
    @Test fun defaultsMatchOriginal() {
        assertEquals(10000L, prefs.ff)
        assertEquals(listOf(5000L, 10000L, 20000L, 30000L, 60000L), prefs.durations)
        assertEquals(1f, prefs.speed)
        listOf("background", "autoPlay", "showWhatsApp", "showBoost", "showSleep", "multiSelect").forEach { assertTrue(prefs.bool(it)) }
        assertFalse(prefs.bool("bypass", false))
    }
    @Test fun customSeekOptionsAndSpeedPersist() {
        prefs.durations = listOf(1000L, 25000L); prefs.ff = 25000; prefs.speed = 3.75f
        val restored = PlayerPrefs(context)
        assertEquals(listOf(1000L, 25000L), restored.durations); assertEquals(25000L, restored.ff); assertEquals(3.75f, restored.speed)
    }
    @Test fun queueRoundTripsUnicodeAndContentUris() {
        val items = listOf(MediaEntry("content://external/audio/42", "اردو audio.mp3", size = 1234), MediaEntry("/storage/emulated/0/a b.mp4", "a b.mp4", modified = 55))
        assertEquals(items, MediaEntry.decode(MediaEntry.encode(items)))
        assertTrue(MediaEntry.decode("not json").isEmpty())
    }
    @Test fun favoriteToggleRenameAndRemovalPersist() {
        val first = MediaEntry("/music/a.mp3", "a.mp3")
        val renamed = MediaEntry("/music/b.mp3", "b.mp3")
        assertTrue(prefs.toggleFavorite(first)); assertTrue(PlayerPrefs(context).favorite(first))
        prefs.renameFavorite(first.location, renamed)
        assertFalse(prefs.favorite(first)); assertTrue(prefs.favorite(renamed))
        assertFalse(prefs.toggleFavorite(renamed)); assertTrue(prefs.favorites().isEmpty())
    }
    @Test fun fourSortModesKeepFoldersFirst() {
        val a = MediaEntry("/a", "a.mp3", modified = 10)
        val b = MediaEntry("/b", "b.mp3", modified = 20)
        val folder = MediaEntry("/z", "z folder", true)
        val items = listOf(b, a, folder)
        assertEquals(listOf(folder, a, b), repo.sorted(items, "A-Z"))
        assertEquals(listOf(folder, b, a), repo.sorted(items, "Z-A"))
        assertEquals(listOf(folder, b, a), repo.sorted(items, "Newest"))
        assertEquals(listOf(folder, a, b), repo.sorted(items, "Oldest"))
    }
    @Test fun folderAndRecursiveScansFilterCorrectly() {
        File(temp, "top.mp3").writeBytes(byteArrayOf(1, 2))
        File(temp, "unrelated.txt").writeText("no")
        File(temp, "nested").mkdirs(); File(temp, "nested/child.opus").writeBytes(byteArrayOf(3))
        File(temp, ".hidden").mkdirs(); File(temp, ".hidden/secret.mp3").writeBytes(byteArrayOf(4))
        val folders = repo.list(temp.absolutePath, "audio", false)
        assertEquals(setOf("top.mp3", "nested"), folders.map { it.name }.toSet())
        val all = repo.list(temp.absolutePath, "audio", true)
        assertEquals(setOf("top.mp3", "child.opus"), all.map { it.name }.toSet())
        assertEquals(3L, all.sumOf { it.size })
    }
    @Test fun renamePreservesDataAndFavorite() {
        val f = File(temp, "old.mp3").apply { writeText("test-data") }
        val old = repo.fromFile(f); prefs.toggleFavorite(old)
        val renamed = repo.rename(old, "new.mp3")
        assertFalse(f.exists()); assertEquals("test-data", File(renamed.location).readText()); assertTrue(prefs.favorite(renamed))
    }
    @Test fun renameCannotOverwriteOrEscapeFolder() {
        val a = File(temp, "a.mp3").apply { writeText("A") }
        File(temp, "b.mp3").writeText("B")
        assertTrue(runCatching { repo.rename(repo.fromFile(a), "../outside.mp3") }.isFailure)
        assertTrue(runCatching { repo.rename(repo.fromFile(a), "b.mp3") }.isFailure)
        assertEquals("A", a.readText())
    }
    @Test fun selectionSizeAndConfirmedDeletionHelpers() {
        val dir = File(temp, "folder").apply { mkdirs() }
        File(dir, "a.mp3").writeBytes(ByteArray(40)); File(dir, "b.txt").writeBytes(ByteArray(60))
        assertEquals(100L, repo.size(repo.fromFile(dir)))
        assertTrue(repo.delete(repo.fromFile(dir))); assertFalse(dir.exists())
    }
    @Test fun mimeTypesAreConcrete() {
        assertEquals("video/x-matroska", repo.mime("clip.mkv")); assertEquals("audio/opus", repo.mime("note.opus"))
        assertEquals("video/3gpp", repo.mime("clip.3gp")); assertEquals("image/png", repo.mime("photo.png"))
    }
    @Test fun sizeFormatting() {
        assertEquals("1.00 MB", MediaRepository.formatSize(1024L * 1024))
        assertEquals("1.00 GB", MediaRepository.formatSize(1024L * 1024 * 1024))
    }
    @Test fun fileSharingUsesGrantedContentUris() {
        val file = File(temp, "a.mp3").apply { writeText("data") }
        val uri = repo.shareUri(repo.fromFile(file))
        assertEquals("content", uri.scheme); assertEquals(context.packageName + ".files", uri.authority)
        assertFalse(uri.toString().contains(temp.absolutePath))
    }
    @Test fun appNameIsExactEverywhere() {
        val info = context.packageManager.getApplicationInfo(context.packageName, 0)
        assertEquals("Swift Player Created by A brothers", context.packageManager.getApplicationLabel(info).toString())
        assertEquals("Swift Player Created by A brothers", context.getString(R.string.app_name))
    }
    @Test fun mainMenuHasOnlyTheSixRetainedActions() {
        val playback = newService()
        org.robolectric.Shadows.shadowOf(context as android.app.Application).setComponentNameAndServiceForBindService(
            android.content.ComponentName(context, PlaybackService::class.java), playback.get().onBind(Intent()))
        val controller = Robolectric.buildActivity(MainActivity::class.java).create().start().resume().visible()
        ShadowLooper.idleMainLooper(2, TimeUnit.SECONDS)
        val activity = controller.get()
        val labels = mutableListOf<String>()
        fun visit(v: View) {
            if (v is Button) labels.add(v.text.toString())
            if (v is ViewGroup) for (i in 0 until v.childCount) visit(v.getChildAt(i))
        }
        visit(activity.window.decorView)
        assertTrue(labels.containsAll(listOf("Scan", "WhatsApp Media", "Settings", "Exit App")))
        listOf("SMART PLAYER", "Audio • Video • WhatsApp Media", "Open a File", "Copy Error Details", "Back", "Minimize Player").forEach {
            assertFalse("unexpected UI text: $it", labels.contains(it))
        }
        assertFalse(labels.any { it.contains("Long-press a media file") })
        controller.pause().stop().destroy()
        playback.destroy()
    }
    @Test fun staleSplashIsReplacedByMenu() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).create().start().resume().visible()
        ShadowLooper.idleMainLooper(3, TimeUnit.SECONDS)
        var images = 0
        fun visit(v: View) { if (v is android.widget.ImageView) images++; if (v is ViewGroup) for (i in 0 until v.childCount) visit(v.getChildAt(i)) }
        visit(controller.get().window.decorView)
        assertEquals(0, images)
        controller.pause().stop().destroy()
    }
    @Test fun manifestRegistersAudioAndVideoOpenWith() {
        val pm = context.packageManager
        for (type in listOf("audio/mpeg", "audio/opus", "video/mp4", "video/x-matroska")) {
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://test.provider/media/42"), type).addCategory(Intent.CATEGORY_DEFAULT)
            @Suppress("DEPRECATION") val matches = pm.queryIntentActivities(intent, 0)
            assertTrue(type, matches.any { it.activityInfo.name == MainActivity::class.java.name })
        }
    }
    @Test fun bypassPreferenceIsSafeAndPersistent() {
        val controller = newService()
        prefs.put("bypass", false)
        assertTrue(controller.get().applyRouting().isNotBlank())
        prefs.put("bypass", true)
        assertTrue(controller.get().applyRouting().isNotBlank())
        assertTrue(PlayerPrefs(context).bool("bypass", false))
        controller.destroy()
    }
    @Test fun serviceSleepToggle() {
        val controller = newService()
        val service = controller.get()
        service.setSleep(true); assertTrue(service.sleepActive)
        service.setSleep(false); assertFalse(service.sleepActive)
        controller.destroy()
    }
    @Test fun exitClearsOnlyOnExplicitExitPath() {
        prefs.put("queue", MediaEntry.encode(listOf(MediaEntry("/a.mp3", "a.mp3"))))
        prefs.put("lastPosition", 4321L)
        prefs.put("exitPending", true)
        val controller = newService()
        controller.get().saveAndStop()
        assertEquals(4321L, PlayerPrefs(context).long("lastPosition"))
        assertEquals(1, MediaEntry.decode(PlayerPrefs(context).str("queue", "[]")).size)
        controller.destroy()
    }
    @Test fun statusMenuNoLongerClaimsAutomaticPosting() {
        val source = File("src/main/java/com/abrothers/swiftplayer/MainActivity.kt").readText()
        assertFalse(source.contains("Status added. Opening WhatsApp."))
        assertTrue(source.contains("statusShare"))
    }

    private fun launch(): org.robolectric.android.controller.ActivityController<MainActivity> {
        val controller = Robolectric.buildActivity(MainActivity::class.java).create().start().resume().visible()
        ShadowLooper.idleMainLooper(4000, TimeUnit.MILLISECONDS)
        return controller
    }
    private fun allViews(v: View): List<View> = listOf(v) + if (v is ViewGroup) (0 until v.childCount).flatMap { allViews(v.getChildAt(it)) } else emptyList()
    private fun invoke(activity: MainActivity, name: String) {
        MainActivity::class.java.getDeclaredMethod(name).apply { isAccessible = true }.invoke(activity)
    }
    @Test fun versionComparisonDoesNotShowSameOrOlderAsNew() {
        assertFalse(UpdateVersion.newer(UpdateVersion.parse("3.0.0"), 3, "3.0.0"))
        assertFalse(UpdateVersion.newer(UpdateVersion.parse("3"), 3, "3.0.0"))
        assertFalse(UpdateVersion.newer(UpdateVersion.parse("2.9.9"), 3, "3.0.0"))
        assertTrue(UpdateVersion.newer(UpdateVersion.parse("3.0.1"), 3, "3.0.0"))
        assertTrue(UpdateVersion.newer(UpdateVersion.parse("versionCode=1\nversionName=3.1.0"), 999, "3.0.0"))
        assertFalse(UpdateVersion.newer(UpdateVersion.parse("versionCode=999\nversionName=3.0.0"),1,"3.0.0"))
        assertTrue(runCatching { UpdateVersion.parse("") }.isFailure)
        assertTrue(runCatching { UpdateVersion.parse("<html>not a version</html>") }.isFailure)
    }
    @Test fun voiceNotesCanBeExcludedOnlyFromAllFiles() {
        val item = MediaEntry("content://media/audio/9", "PTT-20261113.opus", diskPath = "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Voice Notes/202647/PTT.opus")
        assertTrue(repo.allowedInAllFiles(item))
        prefs.put("voiceNotesInAll", false)
        assertFalse(repo.allowedInAllFiles(item))
        assertTrue(repo.matches(item.name, "audio"))
        assertTrue(repo.allowedInAllFiles(MediaEntry("/Music/song.opus", "song.opus")))
    }
    @Test fun settingsToggleKeepsExactlyTheSameViewAndParent() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "settingsMenu")
        val toggle = allViews(activity.window.decorView).filterIsInstance<android.widget.Switch>().first { it.tag == "toggle:multiSelect" }
        val parent = toggle.parent
        toggle.requestFocus()
        val before = toggle.isChecked
        toggle.performClick()
        assertEquals(!before, toggle.isChecked)
        assertTrue(parent === toggle.parent)
        val again = allViews(activity.window.decorView).first { it.tag == "toggle:multiSelect" }
        assertTrue(toggle === again)
        assertEquals(!before, prefs.bool("multiSelect"))
        controller.pause().stop().destroy()
    }
    @Test fun permissionManagerIsOnlyPlaceWithAppInfo() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "settingsMenu")
        val labels = allViews(activity.window.decorView).filterIsInstance<Button>().map { it.text.toString() }
        assertTrue(labels.contains("Permission Manager"))
        assertFalse(labels.contains("App Info")); assertFalse(labels.contains("Storage Doctor"))
        invoke(activity, "accessMenu")
        val dialog = org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        val managerList=allViews(dialog.window!!.decorView).filterIsInstance<android.widget.ListView>().first()
        val adapter = managerList.adapter
        val options = (0 until adapter.count).map { adapter.getItem(it).toString() }
        assertTrue(options.contains("App Info"))
        assertFalse(options.any { it.contains("Choose Folder") })
        dialog.dismiss(); controller.pause().stop().destroy()
    }
    @Test fun scanMenuOnlyHasInternalAndSdCard() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "storageMenu")
        val dialog = org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        val adapter = dialog.listView.adapter
        assertEquals(listOf("Internal Storage", "SD Card"), (0 until adapter.count).map { adapter.getItem(it).toString() })
        assertTrue(dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE) == null || dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).visibility != View.VISIBLE)
        dialog.dismiss(); controller.pause().stop().destroy()
    }
    @Test fun whatsAppManagerHasAllRequestedStableToggles() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "whatsAppManager")
        val toggles = allViews(activity.window.decorView).filterIsInstance<android.widget.Switch>()
        val labels = toggles.map { it.text.toString() }
        assertTrue(labels.containsAll(listOf("Show WhatsApp Official", "Show WhatsApp Business", "Show WhatsApp Voice Notes in All Files", "WhatsApp Voice Notes", "WhatsApp Business Voice Notes")))
        val target = toggles.first { it.tag == "toggle:waOfficial" }
        target.performClick(); assertFalse(prefs.bool("waOfficial"))
        assertTrue(allViews(activity.window.decorView).any { it === target })
        controller.pause().stop().destroy()
    }
    @Test fun playbackSpeedVisibilityToggleDoesNotRebuildAudioSettings() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "audioSettings")
        val views = allViews(activity.window.decorView)
        val target = views.filterIsInstance<android.widget.Switch>().first { it.tag == "toggle:showSpeed" }
        target.performClick(); assertFalse(prefs.bool("showSpeed"))
        assertTrue(allViews(activity.window.decorView).any { it === target })
        val labels = allViews(activity.window.decorView).filterIsInstance<Button>().map { it.text.toString() }
        assertFalse(labels.any { it.contains("Audio Channel") || it.contains("Output Route") })
        controller.pause().stop().destroy()
    }
    @Test fun settingsBackTraversesOneLevelInsteadOfHome() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "settingsMenu"); invoke(activity, "audioSettings")
        @Suppress("DEPRECATION") activity.onBackPressed()
        assertTrue(allViews(activity.window.decorView).filterIsInstance<Button>().any { it.text == "WhatsApp Manager" })
        @Suppress("DEPRECATION") activity.onBackPressed()
        assertTrue(allViews(activity.window.decorView).filterIsInstance<Button>().any { it.text == "Scan" })
        controller.pause().stop().destroy()
    }
    @Test fun folderBackUsesParentStackInsteadOfHome() {
        val controller = launch(); val activity = controller.get()
        val parent = File(temp, "parent").apply { mkdirs() }
        val child = File(parent, "child").apply { mkdirs() }
        fun set(name: String, value: Any) { MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.set(activity, value) }
        set("root", temp.absolutePath); set("browsePath", child.absolutePath); set("mode", "folders")
        set("browseParents", mutableListOf(temp.absolutePath, parent.absolutePath))
        invoke(activity, "browseScreen")
        @Suppress("DEPRECATION") activity.onBackPressed()
        val path = MainActivity::class.java.getDeclaredField("browsePath").apply { isAccessible = true }.get(activity)
        assertEquals(parent.absolutePath, path)
        controller.pause().stop().destroy()
    }
    @Test fun splashIsOnlyAnUndescribedPicture() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).create()
        val activity = controller.get()
        val picture = allViews(activity.window.decorView).filterIsInstance<android.widget.ImageView>().firstOrNull()
        assertTrue(picture != null)
        assertNull(picture?.contentDescription)
        assertEquals(View.IMPORTANT_FOR_ACCESSIBILITY_NO, picture?.importantForAccessibility)
        controller.destroy()
    }

    @Test fun deletingCurrentQueueEntryAdvancesToFollowingNotPrevious() {
        val controller = newService()
        val player = controller.get()
        val a = MediaEntry("/missing/a.mp3", "a.mp3")
        val b = MediaEntry("/missing/b.mp3", "b.mp3")
        val c = MediaEntry("/missing/c.mp3", "c.mp3")
        PlaybackService::class.java.getDeclaredField("queue").apply { isAccessible = true }.set(player, listOf(a,b,c))
        PlaybackService::class.java.getDeclaredField("index").apply { isAccessible = true }.setInt(player, 1)
        player.suspendForDeletion(); player.removeDeleted(listOf(b))
        assertEquals(listOf(a,c), player.queue)
        assertEquals(c, player.current)
        controller.destroy()
    }
    @Test fun selectionButtonsIncludeSelectedCount() {
        val controller = launch(); val activity = controller.get()
        invoke(activity, "browseScreen")
        val job = MainActivity::class.java.getDeclaredField("scanJob").apply { isAccessible = true }.get(activity) as? java.util.concurrent.Future<*>
        job?.cancel(true)
        val generation = MainActivity::class.java.getDeclaredField("scanGeneration").apply { isAccessible = true }
        generation.setInt(activity, generation.getInt(activity)+1)
        val entries = (1..3).map { MediaEntry("/music/$it.mp3", "$it.mp3", size=10) }
        MainActivity::class.java.getDeclaredField("entries").apply { isAccessible = true }.set(activity, entries)
        MainActivity::class.java.getDeclaredField("multi").apply { isAccessible = true }.setBoolean(activity, true)
        MainActivity::class.java.getDeclaredField("selected").apply { isAccessible = true }.set(activity, linkedSetOf(*entries.map { it.location }.toTypedArray()))
        invoke(activity, "updateRows")
        val buttons = allViews(activity.window.decorView).filterIsInstance<Button>()
        assertTrue(buttons.any { it.contentDescription == "Delete 3 items" })
        assertTrue(buttons.any { it.contentDescription == "Share 3 items" })
        controller.pause().stop().destroy()
    }
    @Test fun videoHasLandscapeFullscreenAndNoVisibleCancel() {
        val serviceController = newService()
        val player = serviceController.get()
        PlaybackService::class.java.getDeclaredField("queue").apply { isAccessible = true }.set(player, listOf(MediaEntry("/missing/clip.mp4", "clip.mp4")))
        val controller = launch(); val activity = controller.get()
        MainActivity::class.java.getDeclaredField("service").apply { isAccessible = true }.set(activity, player)
        invoke(activity, "playerScreen")
        val buttons = allViews(activity.window.decorView).filterIsInstance<Button>()
        val full = buttons.first { it.text == "Enter Full Screen" }
        full.performClick()
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, activity.requestedOrientation)
        @Suppress("DEPRECATION") activity.onBackPressed()
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, activity.requestedOrientation)
        assertFalse(buttons.any { it.text == "Cancel" && it.visibility == View.VISIBLE })
        controller.pause().stop().destroy(); serviceController.destroy()
    }

    private class FakeEngine : PlaybackEngine {
        private var playing=false; private var at=0
        var completion:(()->Unit)?=null
        override val isPlaying get()=playing
        override val currentPosition get()=at
        override val duration get()=60000
        override val audioSessionId get()=-1
        override var playbackSpeed=1f
        override fun open(uri: Uri, prepared: ()->Unit, completed: ()->Unit, failed: (String)->Unit) { completion=completed;prepared() }
        override fun start() { playing=true }
        override fun pause() { playing=false }
        override fun seekTo(position: Int) { at=position }
        override fun setDisplay(holder: android.view.SurfaceHolder?) {}
        override fun setVolume(left: Float,right: Float) {}
        override fun setPreferredDevice(device: android.media.AudioDeviceInfo?)=false
        override fun release() { playing=false }
    }
    private fun newService(): org.robolectric.android.controller.ServiceController<PlaybackService> {
        val c=Robolectric.buildService(PlaybackService::class.java)
        c.create(); c.get().engineFactory={ _,_->FakeEngine() }; return c
    }
    @Test fun swiftNamespaceAndExactOpenWithName() {
        assertEquals("com.abrothers.swiftplayer",context.packageName)
        assertEquals("Swift Player Created by A brothers",context.packageManager.getApplicationLabel(context.applicationInfo).toString())
    }
    @Test fun requestedAndAdditionalCommonFormatsRecognized() {
        listOf("mp4","mkv","3gp","avi","webm","mov","wmv","flv","mpeg","m2ts").forEach { ext ->
            assertTrue(ext,repo.matches("file.$ext","video")); assertTrue(ext,repo.isVideo(MediaEntry("/file.$ext","file.$ext")))
        }
        listOf("mp3","wav","aac","flac","ogg","m4a","opus","wma","aiff","ape").forEach { assertTrue(it,repo.matches("sound.$it","audio")) }
        assertEquals("video/x-msvideo",repo.mime("clip.avi"))
        assertEquals("video/webm",repo.mime("clip.webm"))
        assertEquals("audio/flac",repo.mime("song.flac"))
    }
    @Test fun fullscreenIsExactlyBetweenNextAndMoreOptions() {
        val service=newService(); val player=service.get()
        PlaybackService::class.java.getDeclaredField("queue").apply { isAccessible=true }.set(player,listOf(MediaEntry("/clip.mp4","clip.mp4")))
        val controller=launch();val activity=controller.get()
        MainActivity::class.java.getDeclaredField("service").apply { isAccessible=true }.set(activity,player)
        invoke(activity,"playerScreen")
        val row=allViews(activity.window.decorView).first { it.tag=="video-actions" } as android.widget.LinearLayout
        assertEquals(listOf("Next","Enter Full Screen","More Options"),(0 until row.childCount).map { (row.getChildAt(it) as Button).text.toString() })
        controller.pause().stop().destroy(); service.destroy()
    }
    @Test fun bypassRowHasDescriptionThenChannelThenToggle() {
        val controller=launch();val activity=controller.get();invoke(activity,"audioSettings")
        val row=allViews(activity.window.decorView).first { it.tag=="bypass-row" } as android.widget.LinearLayout
        assertEquals(listOf("bypass-description","bypass-channel","toggle:bypass"),(0 until row.childCount).map { row.getChildAt(it).tag.toString() })
        (row.getChildAt(1) as Button).performClick()
        val d=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        assertEquals(listOf("Notification","Music","Ringtone","Alarm","Media"),(0 until d.listView.adapter.count).map { d.listView.adapter.getItem(it).toString() })
        d.cancel();controller.pause().stop().destroy()
    }
    @Test fun whatsAppRootBackCanActuallyReachHomeWithoutLoop() {
        val controller=launch();val activity=controller.get()
        fun set(key:String,value:Any) { MainActivity::class.java.getDeclaredField(key).apply { isAccessible=true }.set(activity,value) }
        set("root",temp.absolutePath);set("browsePath",temp.absolutePath);set("waOrigin",false)
        set("mode","folders");invoke(activity,"browseScreen")
        @Suppress("DEPRECATION") activity.onBackPressed()
        val first=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog(); assertTrue(first.isShowing)
        first.cancel(); ShadowLooper.idleMainLooper(50,TimeUnit.MILLISECONDS)
        val second=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();assertTrue(second.isShowing)
        second.cancel(); ShadowLooper.idleMainLooper(50,TimeUnit.MILLISECONDS)
        val name=MainActivity::class.java.getDeclaredField("screen").apply { isAccessible=true }.get(activity)
        assertEquals("home",name)
        assertTrue(allViews(activity.window.decorView).filterIsInstance<Button>().any { it.text=="Scan" })
        controller.pause().stop().destroy()
    }
    @Test fun contactMessageHasRequestedEnglishFieldsAndPrivacyNote() {
        val controller=launch();val activity=controller.get();invoke(activity,"contactFeedback")
        val sent=org.robolectric.Shadows.shadowOf(activity).nextStartedActivity
        val message=sent.data!!.getQueryParameter("text")!!
        listOf("Name:","Device Brand/Company:","Device Model:","Android Version:","Processor:","Note This device information is collected only for troubleshooting and resolving app issues and for no other purpose").forEach { assertTrue(it,message.contains(it)) }
        controller.pause().stop().destroy()
    }
    @Test fun nestedFoldersStayInsideTheirParentAndIrrelevantDirectoriesStayHidden() {
        val deep=File(temp,"Download/Books/Urdu/poem.flac");deep.parentFile!!.mkdirs();deep.writeBytes(byteArrayOf(1))
        File(temp,"irrelevant/notes.txt").apply { parentFile!!.mkdirs();writeText("x") }
        File(temp,"videos/clip.mp4").apply { parentFile!!.mkdirs();writeText("x") }
        val audio=repo.list(temp.absolutePath,"audio",false)
        assertEquals(listOf("Download"),audio.map { it.name })
        assertFalse(audio.any { it.name.contains('/') })
        val nested=repo.list(File(temp,"Download").absolutePath,"audio",false)
        assertEquals(listOf("Books"),nested.map { it.name })
        assertEquals(listOf("videos"),repo.list(temp.absolutePath,"video",false).map { it.name })
    }
    @Test fun rescanButtonIsAfterSortByAndDoesNotRemoveSearch() {
        val controller=launch();val activity=controller.get();invoke(activity,"browseScreen")
        val sort=allViews(activity.window.decorView).filterIsInstance<Button>().first { it.text.startsWith("Sort By:") }
        val row=sort.parent as android.widget.LinearLayout
        assertTrue(row.getChildAt(0)===sort)
        assertEquals("Rescan",(row.getChildAt(1) as Button).text.toString())
        controller.pause().stop().destroy()
    }
    @Test fun externalPlayerHeadingIsExactAppName() {
        val controller=launch();val activity=controller.get()
        MainActivity::class.java.getDeclaredField("externalMode").apply { isAccessible=true }.setBoolean(activity,true)
        invoke(activity,"playerScreen")
        val title=MainActivity::class.java.getDeclaredField("heading").apply { isAccessible=true }.get(activity) as android.widget.TextView
        assertEquals("Swift Player Created by A brothers",title.text.toString())
        controller.pause().stop().destroy()
    }
    @Test fun sdCardMissingToastHasExactTextWithoutPunctuation() {
        val controller=launch();val activity=controller.get();invoke(activity,"storageMenu")
        val dialog=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        dialog.listView.performItemClick(null,1,1)
        assertEquals("SD Card is currently not inserted or mounted",org.robolectric.shadows.ShadowToast.getTextOfLatestToast())
        controller.pause().stop().destroy()
    }
    @Test fun repositoryDiscoveryDoesNotDependOnApkFilename() {
        val entries=listOf(GitHubRepository.Entry("sub/version.txt","nested"),GitHubRepository.Entry("version.txt","root"),GitHubRepository.Entry("another/whatsnew.txt","news"))
        assertEquals("root",GitHubRepository.selectMetadata(entries,"version.txt")!!.sha)
        assertTrue(GitHubRepository.raw("main","Folder/Any file.apk").endsWith("Folder/Any%20file.apk"))
        assertTrue(GitHubRepository.API.contains("-.-Swift-Player-created-by-A-brothers"))
        assertEquals("v:n",GitHubRepository.revision("v","n"))
    }
    @Test fun onlyVersionNumberTriggersUpdateNeverChangelogOrApkHash() {
        fun snap(version:String,sha:String)=GitHubRepository.Snapshot(UpdateVersion.parse(version),"notes","new:revision",GitHubRepository.Candidate("anything.apk","https://example.test/file.apk",sha))
        assertFalse(GitHubRepository.shouldOffer(snap("4.0.0","newapk"),4,"4.0.0","old:revision","installed"))
        assertFalse(GitHubRepository.shouldOffer(snap("4.0.0","installed"),4,"4.0.0","old:revision","installed"))
        assertFalse(GitHubRepository.shouldOffer(snap("3.0.0","newapk"),4,"4.0.0","old:revision","installed"))
        assertTrue(GitHubRepository.shouldOffer(snap("4.0.1","newapk"),4,"4.0.0","","installed"))
    }

    @Test fun deniedAudioFocusCannotLeaveDecoderRunningInBackground() {
        val c=newService();val service=c.get()
        val audio=service.getSystemService(android.media.AudioManager::class.java)
        val shadow=org.robolectric.Shadows.shadowOf(audio)
        shadow.setNextFocusRequestResponse(android.media.AudioManager.AUDIOFOCUS_REQUEST_FAILED)
        service.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        service.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        assertFalse(service.isPlaying)
        assertTrue(service.message.contains("Audio focus unavailable"))
        shadow.setNextFocusRequestResponse(android.media.AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
        service.resume();assertTrue(service.isPlaying)
        c.destroy()
    }
    @Test fun apkGitBlobUsesActualGitObjectHashNotOrdinaryFileSha() {
        val f=File(temp,"blob");f.writeText("hello\n")
        assertEquals("ce013625030ba8dba906f756967f9e9ca394464a",GitHubRepository.gitBlob(f))
    }

    @Test fun releaseDisplayVersionIsOneButInternalCodeCanUpdateOldBuild() {
        assertEquals("1.0",BuildConfig.VERSION_NAME);assertTrue(BuildConfig.VERSION_CODE>4)
    }
    @Test fun encryptedAssetsRoundTripBothNewCuesAndImageWithoutPlainResources() {
        val startup=ProtectedAssets.bytes(context,"s");val exit=ProtectedAssets.bytes(context,"e")
        assertEquals(24280,startup.size);assertEquals(23994,exit.size)
        assertTrue(!startup.contentEquals(exit))
        assertTrue(ProtectedAssets.bytes(context,"g").size>100000)
        assertTrue(context.assets.list("protected")!!.toSet()==setOf("s.bin","e.bin","g.bin"))
    }
    @Test fun noSpokenFeedbackSettingAndWhatsAppVisibilityLivesOnlyInManager() {
        val c=launch();val a=c.get();invoke(a,"settingsMenu")
        val controls=allViews(a.window.decorView)
        assertFalse(controls.any { it.tag=="toggle:spokenFeedback" || it.tag=="toggle:showWhatsApp" })
        invoke(a,"whatsAppManager")
        assertTrue(allViews(a.window.decorView).any { it.tag=="toggle:showWhatsApp" })
        c.pause().stop().destroy()
    }
    @Test fun customTimeSetKeepsTheSameDialogAndInputFocus() {
        val c=launch();val a=c.get();invoke(a,"audioSettings");invoke(a,"durationMenu")
        val first=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        val options=allViews(first.window!!.decorView).filterIsInstance<android.widget.ListView>().first()
        options.performItemClick(null,options.adapter.count-1,0)
        val custom=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        val field=allViews(custom.window!!.decorView).filterIsInstance<android.widget.EditText>().first()
        ShadowLooper.idleMainLooper()
        field.setText("27");custom.getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick()
        assertTrue("Custom dialog must remain open",custom.isShowing)
        assertTrue("Duration dialog must remain underneath",first.isShowing)
        assertEquals(27000L,prefs.ff)
        assertTrue(allViews(custom.window!!.decorView).any { it===field })
        custom.dismiss();first.dismiss();c.pause().stop().destroy()
    }
    @Test fun permissionManagerRemainsVisibleAfterGrantCallback() {
        val c=launch();val a=c.get();invoke(a,"settingsMenu");invoke(a,"accessMenu")
        val d=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        a.onRequestPermissionsResult(MainActivity.REQUEST_PERMISSIONS,arrayOf(android.Manifest.permission.READ_MEDIA_AUDIO),intArrayOf(android.content.pm.PackageManager.PERMISSION_GRANTED))
        assertTrue(d.isShowing)
        d.dismiss();c.pause().stop().destroy()
    }
    @Test fun screenReaderSliderProgressSeeksEvenWithoutTouchStopCallback() {
        val service=newService();val player=service.get()
        player.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        player.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        val c=launch();val a=c.get()
        MainActivity::class.java.getDeclaredField("service").apply { isAccessible=true }.set(a,player)
        invoke(a,"playerScreen")
        val slider=allViews(a.window.decorView).filterIsInstance<android.widget.SeekBar>().first { it.tag=="seek" }
        val listener=object:android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:android.widget.SeekBar?,p:Int,user:Boolean) {}
            override fun onStartTrackingTouch(s:android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(s:android.widget.SeekBar?) {}
        }
        val shadow=org.robolectric.Shadows.shadowOf(slider)
        shadow.onSeekBarChangeListener.onProgressChanged(slider,25000,true)
        assertEquals(25000,player.position)
        c.pause().stop().destroy();service.destroy()
    }
    @Test fun resumeSurvivesExplicitExitThenFreshServiceAtSavedPosition() {
        val first=newService();val p=first.get()
        p.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        p.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        p.seek(23456);p.pause();p.saveAndStop()
        assertEquals(23456L,prefs.long("lastPosition"))
        first.destroy()
        val next=newService();next.get().resume()
        assertEquals("test.mp3",next.get().current!!.name)
        assertEquals(23456,next.get().position);assertTrue(next.get().isPlaying)
        next.destroy()
    }
    @Test fun resumeFromStoppedBoundServiceDoesNotRestartAtZero() {
        val c=newService();val p=c.get();p.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        p.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1);p.seek(15678);p.saveAndStop()
        p.resume();assertEquals(15678,p.position);c.destroy()
    }
    @Test fun duplicateRenameNeverOverwritesEitherFileAndHasExactMessage() {
        val source=File(temp,"one.mp3").apply { writeText("first") }
        File(temp,"two.mp3").writeText("second")
        val error=runCatching { repo.rename(repo.fromFile(source),"two.mp3") }.exceptionOrNull()
        assertTrue(error is DuplicateNameException)
        assertEquals("Cannot rename this file. Already one file is present.",error!!.message)
        assertEquals("first",source.readText());assertEquals("second",File(temp,"two.mp3").readText())
    }
    @Test fun resumeCopyReferenceSurvivesPlaylistJsonRoundTrip() {
        val entry=MediaEntry("content://provider/read-only/4","clip.mp4",resumeLocation="/private/resume.mp4")
        assertEquals(entry,MediaEntry.decode(MediaEntry.encode(listOf(entry))).single())
    }
    @Test fun newTutorialUrlUsesRawUserRepositoryBytes() {
        assertTrue(MainActivity.TUTORIAL_URL.contains("-.-Swift-Player-created-by-A-brothers"))
        assertTrue(MainActivity.TUTORIAL_URL.contains("How%20to%20use%20Swift%20Player%20created%20by%20A%20brothers.mp3"))
        assertFalse(MainActivity.TUTORIAL_URL.contains("/blob/"))
    }
    @Suppress("UNCHECKED_CAST")
    private fun <T> getField(target:Any,name:String):T = target.javaClass.getDeclaredField(name).apply { isAccessible=true }.get(target) as T
    private fun setField(target:Any,name:String,value:Any) { target.javaClass.getDeclaredField(name).apply { isAccessible=true }.set(target,value) }
    private fun repoFixture(version:String="versionName=1.0\nversionCode=7"):MutableList<String> {
        val visited=mutableListOf<String>()
        fun blob(value:String)=org.json.JSONObject().put("encoding","base64").put("content",android.util.Base64.encodeToString(value.toByteArray(),android.util.Base64.NO_WRAP)).toString()
        GitHubRepository.transport={ url,_ ->
            visited.add(url)
            when {
                url==GitHubRepository.API -> "{\"default_branch\":\"main\"}"
                url.endsWith("/branches/main") -> "{\"commit\":{\"sha\":\"fixedcommit\",\"commit\":{\"tree\":{\"sha\":\"fixedtree\"}}}}"
                url.contains("/git/trees/") -> "{\"truncated\":false,\"tree\":[{\"type\":\"blob\",\"path\":\"version.txt\",\"sha\":\"versionhash\"},{\"type\":\"blob\",\"path\":\"whatsnew.txt\",\"sha\":\"newshash\"},{\"type\":\"blob\",\"path\":\"New name APK.apk\",\"sha\":\"apkhash\"}]}"
                url.endsWith("/git/blobs/versionhash") -> blob(version)
                url.endsWith("/git/blobs/newshash") -> blob("Startup, selection and update fixes")
                else -> throw IllegalStateException("Unexpected network call: "+url)
            }
        }
        return visited
    }
    @Test fun immutableRepositorySnapshotDiscoversAnyApkButIgnoresBuildOnlyUpdates() {
        val visited=repoFixture()
        try {
            val snapshot=GitHubRepository.discover()
            assertEquals("New name APK.apk",snapshot.apk.path)
            assertTrue(snapshot.apk.url.contains("/fixedcommit/"))
            assertTrue(snapshot.apk.url.endsWith("New%20name%20APK.apk"))
            assertEquals("Startup, selection and update fixes",snapshot.changes)
            assertFalse(GitHubRepository.shouldOffer(snapshot,6,"1.0","",""))
            assertFalse(GitHubRepository.shouldOffer(snapshot,7,"1.0","",""))
            assertFalse(visited.any { it.startsWith("https://raw.") })
        } finally { GitHubRepository.transport=null }
    }
    @Test fun equalVersionDoesNotOfferUpdateForNotesOnlyChange() {
        repoFixture("1.0")
        try { assertFalse(GitHubRepository.shouldOffer(GitHubRepository.discover(),6,"1.0","old","old")) }
        finally { GitHubRepository.transport=null }
    }
    @Test fun markhorStaysVisibleUntilStartupCueEndsForNormalAndExternalLaunch() {
        val intent=Intent(context,MainActivity::class.java).setAction(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://example.provider/audio/1"),"audio/mpeg")
        val c=Robolectric.buildActivity(MainActivity::class.java,intent).create().start().resume().visible()
        val a=c.get()
        ShadowLooper.idleMainLooper(100,TimeUnit.MILLISECONDS)
        val image=allViews(a.window.decorView).filterIsInstance<android.widget.ImageView>().first { it.tag=="startup-markhor" }
        assertTrue(image.isShown);assertTrue(image.drawable!=null)
        assertEquals("splash",getField<String>(a,"screen"))
        assertTrue(getField<Long>(a,"startupStartedAt")>=0)
        c.pause().stop().destroy()
        val normal=Robolectric.buildActivity(MainActivity::class.java).create().start().resume().visible()
        ShadowLooper.idleMainLooper(100,TimeUnit.MILLISECONDS)
        assertTrue(allViews(normal.get().window.decorView).any { it.tag=="startup-markhor" })
        normal.pause().stop().destroy()
    }
    @Test fun scanPlayerHasFullAppHeadingToo() {
        val c=launch();val a=c.get();setField(a,"externalMode",false);invoke(a,"playerScreen")
        assertTrue(allViews(a.window.decorView).filterIsInstance<TextView>().any { it.text.toString()=="Swift Player Created by A brothers" })
        assertFalse(allViews(a.window.decorView).filterIsInstance<TextView>().any { it.text.toString()=="Player" })
        c.pause().stop().destroy()
    }
    @Test fun normalRowsAreNotAccessibilityCheckboxesButLongPressRowsAre() {
        val c=launch();val a=c.get()
        invoke(a,"home");setField(a,"root",temp.absolutePath);setField(a,"browsePath",temp.absolutePath);setField(a,"mode","folders")
        invoke(a,"browseScreen")
        val item=MediaEntry(File(temp,"song.mp3").absolutePath,"song.mp3")
        setField(a,"entries",listOf(item));invoke(a,"updateRows")
        val list=getField<android.widget.ListView>(a,"list")
        val row=list.adapter.getView(0,null,list)
        val normal=row.createAccessibilityNodeInfo()
        assertFalse(normal.isCheckable);assertFalse(normal.isChecked)
        assertEquals("android.widget.Button",normal.className.toString())
        assertTrue(normal.isClickable)
        assertTrue(normal.actionList.any { it.id==android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK })
        setField(a,"multi",true)
        getField<MutableSet<String>>(a,"selected").add(item.location)
        val selected=list.adapter.getView(0,row,list).createAccessibilityNodeInfo()
        assertTrue(selected.isCheckable);assertTrue(selected.isChecked)
        assertEquals("android.widget.CheckBox",selected.className.toString())
        c.pause().stop().destroy()
    }
    @Test fun apkTesterShowsShareAndClearOnlyWhileChecked() {
        AppLog.enable(context,false)
        val c=launch();val a=c.get();invoke(a,"settingsMenu")
        assertFalse(allViews(a.window.decorView).filterIsInstance<Button>().any { it.text.toString()=="APK Tester" })
        invoke(a,"about")
        val buttons=allViews(a.window.decorView).filterIsInstance<Button>()
        val tester=buttons.first { it.text.toString()=="APK Tester" }
        val update=buttons.first { it.text.toString()=="Check for update" }
        assertTrue(tester.parent===update.parent)
        invoke(a,"testerScreen")
        val controls=allViews(a.window.decorView)
        val consent=controls.filterIsInstance<android.widget.CheckBox>().first { it.tag=="tester-consent" }
        val options=controls.first { it.tag=="tester-options" }
        assertEquals(View.GONE,options.visibility)
        consent.performClick();assertEquals(View.VISIBLE,options.visibility);assertTrue(AppLog.enabled(context))
        assertTrue(controls.any { it.tag=="tester-share" });assertTrue(controls.any { it.tag=="tester-clear" })
        consent.performClick();assertEquals(View.GONE,options.visibility);assertFalse(AppLog.enabled(context))
        c.pause().stop().destroy()
    }
    @Test fun apkTesterRecordsOnlyUsedFeaturesAndSimpleErrors() {
        ApkTester.clear(context)
        ApkTester.used(context,"Rewind 10 seconds")
        assertFalse(ApkTester.hasRecords(context))
        AppLog.enable(context,true)
        ApkTester.used(context,"Rewind 10 seconds")
        ApkTester.used(context,"More Options > Rename")
        AppLog.record(context,"Rename",SecurityException("provider supplied read-only access"))
        val report=ApkTester.reportText(context)
        assertTrue(report.contains("Rewind 10 seconds - used 1 time - No error seen"))
        assertTrue(report.contains("More Options > Rename - used 1 time - PROBLEM FOUND"))
        assertTrue(report.contains("only be read"))
        assertFalse(report.contains("Fast Forward"))
        val file=ApkTester.reportFile(context)
        assertEquals("text/plain",context.contentResolver.getType(ShareProvider.uri(context,file)))
        ApkTester.clear(context);assertFalse(ApkTester.hasRecords(context))
    }
    @Test fun alreadyWritableExternalFileResolvesWithoutRequestingNewGrant() {
        val file=File(temp,"editable.mp3").apply { writeText("audio") }
        val uri=MediaEntry("content://other.provider/one",file.name,diskPath=file.absolutePath)
        assertEquals(file.absolutePath,repo.editableEntry(uri).location)
        assertEquals("audio",file.readText())
        assertEquals("content://readonly.provider/one",repo.editableEntry(MediaEntry("content://readonly.provider/one","a.mp3")).location)
    }

    @Test fun speedAndBoostUpdateVisibleAndAccessibleLabelsWithoutReplacingViews() {
        val service=newService();val player=service.get()
        player.pendingQueue=listOf(MediaEntry("/sample.mp3","sample.mp3"))
        player.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        val c=launch();val a=c.get();setField(a,"service",player);invoke(a,"playerScreen")
        val speed=getField<Button>(a,"speedRef");val boost=getField<Button>(a,"boostRef")
        assertEquals("Playback Speed: Normal",speed.text.toString())
        player.onChange={ invoke(a,"updatePlayer") }
        player.setSpeed(1.5f)
        assertEquals("Playback Speed: 1.5x",speed.text.toString())
        assertEquals(speed.text.toString(),speed.contentDescription.toString())
        player.cycleBoost()
        assertEquals("Volume Boost: 1.5x",boost.text.toString())
        assertEquals(boost.text.toString(),boost.contentDescription.toString())
        assertTrue(speed===getField<Button>(a,"speedRef"));assertTrue(boost===getField<Button>(a,"boostRef"))
        player.setSpeed(1f);assertEquals("Playback Speed: Normal",speed.text.toString())
        c.pause().stop().destroy();service.destroy()
    }
    @Test fun replayAfterCompletionStartsAtZeroAndRetainsSameTrack() {
        prefs.put("autoPlay",false)
        val c=newService();val player=c.get();var latest:FakeEngine?=null
        player.engineFactory={ _,_->FakeEngine().also { latest=it } }
        player.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        player.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        player.seek(60000);latest!!.completion!!.invoke()
        assertFalse(player.isPlaying)
        player.toggle()
        assertTrue(player.isPlaying);assertEquals(0,player.position);assertEquals("test.mp3",player.current!!.name)
        c.destroy()
    }
    @Test fun appSoundsCheckboxPersistsAndSuppressesStartupAndExitCue() {
        val c=launch();val a=c.get();invoke(a,"settingsMenu")
        val checkbox=allViews(a.window.decorView).filterIsInstance<android.widget.CheckBox>().first { it.tag=="app-sounds" }
        assertTrue(checkbox.isChecked);checkbox.performClick()
        assertFalse(prefs.bool("playAppSounds",true))
        invoke(a,"playStartupSound");assertNull(getField<android.media.MediaPlayer?>(a,"splashSound"))
        invoke(a,"exitApp");assertTrue(a.isFinishing)
        c.pause().stop().destroy()
    }
    @Test fun semanticVersionDecisionNeverUsesVersionCode() {
        assertFalse(UpdateVersion.newer(UpdateVersion.Release("1.0",99999),0,"1.0"))
        assertTrue(UpdateVersion.newer(UpdateVersion.Release("1.1",0),99999,"1.0"))
        assertTrue(UpdateVersion.newer(UpdateVersion.Release("2.0",1),99999,"1.0"))
        assertFalse(UpdateVersion.newer(UpdateVersion.Release("0.9",99999),1,"1.0"))
    }
    @Test fun malformedPublishedApkIsRejectedWithActionableZipError() {
        val input=File(temp,"broken.apk").apply { writeBytes(byteArrayOf(80,75,3,4)+ByteArray(500)) }
        val failure=runCatching { ApkArchive.validate(input) }.exceptionOrNull()
        assertTrue(failure!=null)
        assertTrue(failure!!.message.orEmpty().contains("APK",true))
    }
    @Test fun structuralApkCheckRejectsHtmlAndPointersAndAcceptsCompiledManifestZip() {
        val html=File(temp,"bad.apk").apply { writeText("<html>"+"error".repeat(100)) }
        assertTrue(runCatching { ApkArchive.validate(html) }.isFailure)
        val pointer=File(temp,"pointer.apk").apply { writeText("version https://git-lfs.github.com/spec/v1\n"+"x".repeat(100)) }
        assertTrue(runCatching { ApkArchive.validate(pointer) }.isFailure)
        val valid=File(temp,"structural.apk")
        java.util.zip.ZipOutputStream(valid.outputStream()).use { zip ->
            zip.putNextEntry(java.util.zip.ZipEntry("AndroidManifest.xml"));zip.write(byteArrayOf(3,0,8,0,0,0,0,0));zip.closeEntry()
            zip.putNextEntry(java.util.zip.ZipEntry("classes.dex"));zip.write("dex code".toByteArray());zip.closeEntry()
        }
        ApkArchive.validate(valid) // Structural probe only; Android must still verify signature/manifest validity.
        assertEquals("application/vnd.android.package-archive",repo.mime("update.apk"))
    }
    @Test fun apkTesterNeverChangesUserSettings() {
        prefs.speed=1.75f;prefs.ff=42000;prefs.put("showWhatsApp",false)
        AppLog.enable(context,true);ApkTester.clear(context)
        ApkTester.used(context,"Playback Speed");ApkTester.reportFile(context)
        assertEquals(1.75f,prefs.speed);assertEquals(42000L,prefs.ff);assertFalse(prefs.bool("showWhatsApp"))
    }
    @Test fun renameHasOneYesButtonAndNoAdditionalAppPermissionPrompt() {
        val c=launch();val a=c.get()
        val file=File(temp,"rename.mp3").apply { writeText("data") }
        MainActivity::class.java.getDeclaredMethod("rename",MediaEntry::class.java).apply { isAccessible=true }.invoke(a,repo.fromFile(file))
        val dialog=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
        assertEquals("Yes",dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).text.toString())
        dialog.dismiss();c.pause().stop().destroy()
    }

    @Test fun privateDownloadsPreserveExactNamesAndRejectTraversal() {
        val folder=File(context.filesDir,"test-update-folder")
        val original="Swift Player release 1.0.apk"
        val target=PrivateDownloads.target(folder,original)
        assertEquals(original,target.name);assertEquals(folder,target.parentFile)
        assertTrue(runCatching { PrivateDownloads.target(folder,"../other.apk") }.isFailure)
        folder.deleteRecursively()
    }
    @Test fun sameNameAtDifferentLocationsNeverAuthorizesMutation() {
        val a=File(temp,"a/song.mp3");val b=File(temp,"b/song.mp3")
        assertFalse(repo.sameMutationTarget(repo.fromFile(a),repo.fromFile(b)))
        assertTrue(repo.sameMutationTarget(repo.fromFile(a),repo.fromFile(a)))
    }
    @Test fun stopActionClearsQueueAndSystemMediaSession() {
        val c=newService();val player=c.get()
        player.pendingQueue=listOf(MediaEntry("/test.mp3","test.mp3"))
        player.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        player.onStartCommand(Intent().setAction(PlaybackService.STOP),0,2)
        assertNull(player.current);assertFalse(player.isPlaying)
        val session=getField<android.media.session.MediaSession>(player,"session")
        assertFalse(session.isActive);c.destroy()
    }

    @Test fun openWithBackStopsSessionAndDoesNotDiscardResumeRecord() {
        prefs.put("playAppSounds",false)
        val c=launch();val a=c.get();val sc=newService();val svc=sc.get()
        svc.pendingQueue=listOf(MediaEntry("/sample.mp3","sample.mp3"))
        svc.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        setField(a,"service",svc);setField(a,"screen","player");setField(a,"externalMode",true)
        invoke(a,"navigateBack")
        assertTrue(a.isFinishing);assertFalse(svc.isPlaying);assertNull(svc.current)
        assertFalse(getField<android.media.session.MediaSession>(svc,"session").isActive)
        assertEquals("sample.mp3",MediaEntry.decode(prefs.str("queue")).first().name)
        c.pause().stop().destroy();sc.destroy()
    }
    @Test fun moreOptionsOrderAndOpenWithCleanup() {
        val c=launch();val a=c.get();val sc=newService();val svc=sc.get()
        svc.pendingQueue=listOf(MediaEntry("/sample.mp3","sample.mp3"))
        svc.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        setField(a,"service",svc)
        fun labels():List<String> { val d=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();return (0 until d.listView.count).map { d.listView.adapter.getItem(it).toString() } }
        invoke(a,"moreOptions")
        assertEquals(listOf("Share","Delete","Rename","Add to Favorite","Move / Copy"),labels())
        setField(a,"externalMode",true)
        invoke(a,"moreOptions")
        assertEquals(listOf("Share","Add to Favorite"),labels())
        c.pause().stop().destroy();sc.destroy()
    }
    @Test fun playerBottomRowIsRewindPauseFastForward() {
        val c=launch();val a=c.get();invoke(a,"playerScreen")
        val row=allViews(a.window.decorView).first { it.tag=="bottom-controls" } as ViewGroup
        val names=(0 until row.childCount).map { (row.getChildAt(it) as Button).text.toString() }
        assertEquals(listOf("Rewind 10 seconds","Play","Fast Forward 10 seconds"),names)
        val others=allViews(a.window.decorView).filterIsInstance<Button>().filter { it.parent!==row }.map { it.text.toString() }
        assertFalse(others.any { it.startsWith("Rewind") || it.startsWith("Fast Forward") || it=="Play" })
        c.pause().stop().destroy()
    }
    @Test fun copyKeepsSourceMoveRemovesItAndNamesNeverOverwrite() {
        val src=File(temp,"from/song.mp3").apply { parentFile!!.mkdirs();writeText("audio") }
        val dest=File(temp,"to").apply { mkdirs() }
        File(dest,"song.mp3").writeText("existing")
        var last=0L
        val copied=repo.transfer(repo.fromFile(src),dest,false,{ false }) { last=it }
        assertTrue(src.isFile);assertEquals("song_1.mp3",File(copied.entry.location).name);assertEquals("existing",File(dest,"song.mp3").readText())
        assertTrue(last>0)
        val moved=repo.transfer(repo.fromFile(src),dest,true,{ false }) { }
        assertFalse(src.exists());assertTrue(moved.sourceRemoved);assertEquals("audio",File(moved.entry.location).readText())
        assertTrue(dest.listFiles()!!.none { it.name.endsWith(".part") })
    }
    @Test fun cancelledCopyLeavesNoPartialFile() {
        val src=File(temp,"big.mp3").apply { writeBytes(ByteArray(300000)) }
        val dest=File(temp,"out").apply { mkdirs() }
        val result=runCatching { repo.transfer(repo.fromFile(src),dest,false,{ true }) { } }
        assertTrue(result.exceptionOrNull() is MediaRepository.TransferCancelledException)
        assertEquals(0,dest.listFiles()!!.size)
    }
    @Test fun notificationHasRewindAndFastForwardAroundPause() {
        val c=newService();val svc=c.get()
        svc.pendingQueue=listOf(MediaEntry("/sample.mp3","sample.mp3"))
        svc.onStartCommand(Intent().setAction(PlaybackService.LOAD),0,1)
        val n=PlaybackService::class.java.getDeclaredMethod("notification").apply { isAccessible=true }.invoke(svc) as android.app.Notification
        assertEquals(listOf("Previous","Rewind 10 seconds","Pause","Fast Forward 10 seconds","Next","Stop").map { it.replace("Pause","Play") },
            n.actions.map { it.title.toString().replace("Pause","Play") })
        c.destroy()
    }

}
