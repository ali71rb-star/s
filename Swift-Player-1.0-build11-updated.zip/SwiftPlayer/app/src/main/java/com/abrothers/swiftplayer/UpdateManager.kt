package com.abrothers.swiftplayer

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

/** User-supplied GitHub files. Never treat a missing/blank version as 'up to date'. */
object UpdateVersion {
    data class Release(val name: String, val code: Long? = null)
    fun parse(text: String): Release {
        val clean = text.trim().removePrefix("\uFEFF")
        require(clean.isNotEmpty()) { "GitHub version.txt is empty. Add the release version, for example 1.0." }
        val code = Regex("(?im)^\\s*versionCode\\s*[:=]\\s*(\\d+)\\s*$").find(clean)?.groupValues?.get(1)?.toLong()
        val name = Regex("(?im)^\\s*versionName\\s*[:=]\\s*([0-9]+(?:\\.[0-9]+){0,3})\\s*$").find(clean)?.groupValues?.get(1)
            ?: clean.takeIf { it.matches(Regex("[0-9]+(?:\\.[0-9]+){0,3}")) }
            ?: throw IllegalArgumentException("Invalid version.txt. Use a version such as 3.0.0, or versionCode=3 and versionName=3.0.0 on separate lines.")
        return Release(name, code)
    }
    fun compare(a: String, b: String): Int {
        val x = a.split('.').map { it.toLong() }; val y = b.split('.').map { it.toLong() }
        for (i in 0 until maxOf(x.size, y.size)) {
            val c = (x.getOrNull(i) ?: 0).compareTo(y.getOrNull(i) ?: 0)
            if (c != 0) return c
        }
        return 0
    }
    @Suppress("UNUSED_PARAMETER")
    fun newer(remote:Release,code:Long,name:String)=compare(remote.name,name)>0
}

class UpdateManager(private val activity: Activity) {
    private val prefs = PlayerPrefs(activity)
    private val executor = Executors.newSingleThreadExecutor()
    private var checking = false
    private var permissionFlow = false
    private var attached = false
    private var downloading=false
    private var offerDialog:AlertDialog?=null
    private var installing=false
    fun attach() { attached=true }
    fun detach() { attached=false }
    fun close() { detach();offerDialog?.dismiss();executor.shutdownNow() }
    fun check(manual: Boolean) {
        if (checking) return
        checking=true
        executor.submit {
            runCatching {
                val snapshot=GitHubRepository.discover()
                val downloadedVersion=prefs.str("downloadReleaseName")
                val downloadedBlob=prefs.str("downloadExpectedBlob")
                if(downloadedVersion.isNotBlank() && downloadedBlob.isNotBlank()) {
                    // A completed installation is recognized by identical APK bytes, never by versionCode.
                    val ownApk=File(activity.applicationInfo.sourceDir)
                    if(ownApk.isFile && GitHubRepository.gitBlob(ownApk)==downloadedBlob)
                        prefs.put("installedReleaseVersion",downloadedVersion)
                }
                val installedVersion=prefs.str("installedReleaseVersion",BuildConfig.VERSION_NAME)
                val offer=GitHubRepository.shouldOffer(snapshot,0,installedVersion,"","")
                if(!offer) prefs.put("repositoryRevision",snapshot.fingerprint)
                snapshot to offer
            }.onSuccess { (snapshot,offer) -> activity.runOnUiThread {
                checking=false
                if(activity.isDestroyed || activity.isFinishing || (!manual && !attached)) return@runOnUiThread
                if(offer) {
                    available(snapshot)
                } else if(manual) message("You are using latest version")
            } }.onFailure { e -> activity.runOnUiThread {
                checking=false
                AppLog.record(activity,"GitHub check",e)
                if(manual && !activity.isDestroyed && !activity.isFinishing) message("Could not check for update. ${e.message}")
            } }
        }
    }
    private fun message(text: String) {
        AlertDialog.Builder(activity).setMessage(text).setPositiveButton("OK", null).show()
    }
    private fun available(snapshot: GitHubRepository.Snapshot) {
        if(offerDialog?.isShowing==true)return
        val remote=snapshot.release; val changes=snapshot.changes
        val density = activity.resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()
        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(18), dp(22), dp(18)) }
        fun text(value: String, heading: Boolean = false) = TextView(activity).apply {
            id = View.generateViewId(); text = value; textSize = if (heading) 21f else 16f
            setPadding(0, dp(10), 0, dp(10)); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            isFocusable = true
            if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = heading
            col.addView(this, LinearLayout.LayoutParams(-1, -2))
        }
        val title = text("Update Available", true)
        val whatsNew = text("What's new", true)
        val changelog = text(changes.trim().ifEmpty { "No release notes have been published yet." })
        val version = text("Installed version: ${BuildConfig.VERSION_NAME}\nAvailable version: ${remote.name}")
        val cancel = Button(activity).apply { id = View.generateViewId(); text = "Cancel"; isAllCaps = false; col.addView(this) }
        val download = Button(activity).apply { id = View.generateViewId(); text = "Download"; isAllCaps = false; col.addView(this) }
        val order = listOf<View>(title, whatsNew, changelog, version, cancel, download)
        order.zipWithNext().forEach { (a, b) -> a.accessibilityTraversalBefore = b.id; b.accessibilityTraversalAfter = a.id }
        val dialog = AlertDialog.Builder(activity).setView(ScrollView(activity).apply { addView(col) }).create()
        cancel.setOnClickListener { dialog.dismiss() }
        download.setOnClickListener { dialog.dismiss(); download(snapshot) }
        offerDialog=dialog
        dialog.show()
        title.post { title.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null) }
    }
    private fun download(snapshot:GitHubRepository.Snapshot) {
        if(downloading || installing) { message("An update is already being processed.");return }
        downloading=true
        val folder=File(activity.filesDir,"updates")
        executor.submit {
            runCatching {
                val filename=snapshot.apk.path.substringAfterLast('/')
                require(filename.endsWith(".apk",true)) { "Invalid APK name" }
                val target=PrivateDownloads.target(folder,filename)
                PrivateDownloads.fetch(snapshot.apk.url,target,120L*1024*1024,validate={ file ->
                    require(GitHubRepository.gitBlob(file)==snapshot.apk.sha) { "Downloaded APK does not match GitHub." }
                    ReleaseIdentity.verify(activity,file)
                })
                prefs.raw.edit().putString("privateUpdateName",filename).putString("downloadExpectedBlob",snapshot.apk.sha)
                    .putString("downloadReleaseName",snapshot.release.name).putBoolean("updateReady",true).commit()
                folder.listFiles()?.filter { it!=target && it.isFile && (it.extension.equals("apk",true) || it.name.contains(".part.")) }?.forEach { it.delete() }
            }.onSuccess { activity.runOnUiThread { downloading=false;if(attached && !activity.isFinishing && !activity.isDestroyed)installPending() } }
                .onFailure { e -> AppLog.record(activity,"APK download",e);activity.runOnUiThread { downloading=false;if(attached && !activity.isDestroyed && !activity.isFinishing)message(e.message ?: "APK download failed") } }
        }
    }
    fun installPendingIfPermitted() {
        if(permissionFlow) {
            permissionFlow=false
            if(!activity.packageManager.canRequestPackageInstalls())return
        }
        if(prefs.bool("updateReady",false) && prefs.str("privateUpdateName").isNotBlank())installPending()
    }
    fun installPending() {
        if(installing || downloading || !attached || !prefs.bool("updateReady",false))return
        val name=prefs.str("privateUpdateName");if(name.isBlank())return
        if(!activity.packageManager.canRequestPackageInstalls()) {
            if(permissionFlow)return
            permissionFlow=true
            AlertDialog.Builder(activity).setMessage("Android requires Allow from this source to open the installer.")
                .setPositiveButton("Open Settings") { _,_-> runCatching { activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:${activity.packageName}"))) }.onFailure { permissionFlow=false;message(it.message.orEmpty()) } }
                .setOnCancelListener { permissionFlow=false;prefs.put("updateReady",false) }.show()
            return
        }
        installing=true
        executor.submit {
            runCatching {
                val file=PrivateDownloads.target(File(activity.filesDir,"updates"),name)
                require(file.isFile && GitHubRepository.gitBlob(file)==prefs.str("downloadExpectedBlob")) { "Saved APK is missing or damaged. Download it again." }
                ReleaseIdentity.verify(activity,file)
                file
            }.onSuccess { file -> activity.runOnUiThread {
                installing=false
                if(!attached || activity.isDestroyed || activity.isFinishing)return@runOnUiThread
                runCatching {
                    val uri=ShareProvider.uri(activity,file)
                    activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").apply {
                        clipData=ClipData.newRawUri("Swift Player update",uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                    prefs.put("updateReady",false)
                }.onFailure { message("Android installer could not open: ${it.message}") }
            } }.onFailure { e -> AppLog.record(activity,"APK installer",e);activity.runOnUiThread {
                installing=false;prefs.put("updateReady",false)
                if(attached && !activity.isDestroyed && !activity.isFinishing)message(e.message ?: "Update could not be opened")
            } }
        }
    }
}

internal object ReleaseIdentity {
    fun verify(context:Context,file:File) {
                ApkArchive.validate(file)
        @Suppress("DEPRECATION")
        fun readSigners(info:android.content.pm.PackageInfo?):Set<String> {
            val certificates=(if(Build.VERSION.SDK_INT>=28)info?.signingInfo?.apkContentsSigners else null)
                ?.takeIf { it.isNotEmpty() } ?: info?.signatures
            return certificates?.map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b->"%02x".format(b) } }?.toSet().orEmpty()
        }
        @Suppress("DEPRECATION")
        val flags = if(Build.VERSION.SDK_INT>=28)PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val pm=context.packageManager
        @Suppress("DEPRECATION")
        val next=pm.getPackageArchiveInfo(file.absolutePath,flags) ?: pm.getPackageArchiveInfo(file.absolutePath,0)
            ?: error("Android cannot read this APK. Publish the original signed release APK.")
        require(next.packageName==context.packageName) { "This download belongs to a different application" }
        @Suppress("DEPRECATION")
        val own=readSigners(pm.getPackageInfo(context.packageName,flags)).ifEmpty { readSigners(pm.getPackageInfo(context.packageName,PackageManager.GET_SIGNATURES)) }
        @Suppress("DEPRECATION")
        val incoming=readSigners(next).ifEmpty { readSigners(pm.getPackageArchiveInfo(file.absolutePath,PackageManager.GET_SIGNATURES)) }
        require(incoming.isNotEmpty() && own.isNotEmpty()) { "Android could not verify the signing certificate. Use the original signed release APK." }
        require(incoming==own) { "Signing certificates differ. Installed: ${own.sorted().joinToString()}. Downloaded: ${incoming.sorted().joinToString()}. Publish a release signed with the installed app's original key." }
    }
}
