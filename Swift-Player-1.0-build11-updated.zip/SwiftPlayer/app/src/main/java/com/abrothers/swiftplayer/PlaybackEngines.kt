package com.abrothers.swiftplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.MediaPlayer
import android.net.Uri
import android.os.PowerManager
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters

object PlayerAudioChannels {
    val choices=listOf("notification" to "Notification","music" to "Music","ringtone" to "Ringtone","alarm" to "Alarm","media" to "Media")
    fun label(key:String)=choices.firstOrNull { it.first==key }?.second ?: "Media"
    fun usage(key:String)=when(key) { "notification"->AudioAttributes.USAGE_NOTIFICATION;"ringtone"->AudioAttributes.USAGE_NOTIFICATION_RINGTONE;"alarm"->AudioAttributes.USAGE_ALARM;else->AudioAttributes.USAGE_MEDIA }
    fun attributes(key:String)=AudioAttributes.Builder().setUsage(usage(key)).setContentType(if(key in listOf("notification","ringtone","alarm")) AudioAttributes.CONTENT_TYPE_SONIFICATION else AudioAttributes.CONTENT_TYPE_MUSIC).build()
}
interface PlaybackEngine {
    val isPlaying:Boolean
    val currentPosition:Int
    val duration:Int
    val audioSessionId:Int
    val seekable:Boolean get()=true
    var playbackSpeed:Float
    fun open(uri:Uri,prepared:()->Unit,completed:()->Unit,failed:(String)->Unit)
    fun start()
    fun pause()
    fun seekTo(position:Int)
    fun setDisplay(holder:SurfaceHolder?)
    fun setVolume(left:Float,right:Float)
    fun setPreferredDevice(device:AudioDeviceInfo?):Boolean
    fun release()
    fun softwareBoost(stage:Int) {}
}
/** Small container/extractor layer; decoding uses Android MediaCodec rather than bundled native VLC. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class Media3PlaybackEngine(context:Context,channel:String):PlaybackEngine {
    private val player=ExoPlayer.Builder(context).build().apply {
        setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(PlayerAudioChannels.usage(channel)).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),false)
        setHandleAudioBecomingNoisy(false)
        setWakeMode(C.WAKE_MODE_LOCAL)
        setSeekParameters(SeekParameters.EXACT)
        playWhenReady=false
    }
    private var initialReady=false
    private var pendingSeek:Long?=null
    override val isPlaying get()=player.isPlaying
    override val currentPosition get()=player.currentPosition.coerceIn(0,Int.MAX_VALUE.toLong()).toInt()
    override val duration get()=player.duration.takeIf { it!=C.TIME_UNSET && it>0 }?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt() ?: 0
    override val seekable get()=player.isCurrentMediaItemSeekable
    override val audioSessionId get()=player.audioSessionId
    override var playbackSpeed:Float
        get()=player.playbackParameters.speed
        set(value) { player.playbackParameters=PlaybackParameters(value) }
    override fun open(uri:Uri,prepared:()->Unit,completed:()->Unit,failed:(String)->Unit) {
        player.addListener(object:Player.Listener {
            override fun onPlaybackStateChanged(state:Int) {
                if(state==Player.STATE_READY && !initialReady) { initialReady=true;prepared();pendingSeek?.let { player.seekTo(it);pendingSeek=null } }
                if(state==Player.STATE_ENDED) completed()
            }
            override fun onPlayerError(error:PlaybackException) { failed(error.message ?: "This device cannot decode this media") }
        })
        player.setMediaItem(MediaItem.fromUri(uri));player.prepare()
    }
    override fun start()=player.play()
    override fun pause()=player.pause()
    override fun seekTo(position:Int) { if(initialReady)player.seekTo(position.toLong()) else pendingSeek=position.toLong() }
    override fun setDisplay(holder:SurfaceHolder?) { if(holder==null)player.clearVideoSurface() else player.setVideoSurfaceHolder(holder) }
    override fun setVolume(left:Float,right:Float) { player.volume=minOf(left,right).coerceIn(0f,1f) }
    override fun setPreferredDevice(device:AudioDeviceInfo?):Boolean {
        player.setPreferredAudioDevice(device)
        // AudioTrack device preference is a request, not a guarantee about any other app's speech.
        return true
    }
    override fun release()=player.release()
}
class NativePlaybackEngine(private val context:Context,channel:String):PlaybackEngine {
    private val player=MediaPlayer().apply { setAudioAttributes(PlayerAudioChannels.attributes(channel));setWakeMode(context,PowerManager.PARTIAL_WAKE_LOCK) }
    override val isPlaying get()=player.isPlaying
    override val currentPosition get()=player.currentPosition
    override val duration get()=player.duration
    override val audioSessionId get()=player.audioSessionId
    override var playbackSpeed:Float
        get()=player.playbackParams.speed
        set(value) { player.playbackParams=player.playbackParams.setSpeed(value) }
    override fun open(uri:Uri,prepared:()->Unit,completed:()->Unit,failed:(String)->Unit) {
        player.setOnPreparedListener { prepared() };player.setOnCompletionListener { completed() }
        player.setOnErrorListener { _,what,extra->failed("$what/$extra");true }
        player.setDataSource(context,uri);player.prepareAsync()
    }
    override fun start()=player.start()
    override fun pause()=player.pause()
    override fun seekTo(position:Int)=player.seekTo(position.toLong(),MediaPlayer.SEEK_CLOSEST)
    override fun setDisplay(holder:SurfaceHolder?)=player.setDisplay(holder)
    override fun setVolume(left:Float,right:Float)=player.setVolume(left,right)
    override fun setPreferredDevice(device:AudioDeviceInfo?)=if(android.os.Build.VERSION.SDK_INT>=28)player.setPreferredDevice(device) else false
    override fun release()=player.release()
}
