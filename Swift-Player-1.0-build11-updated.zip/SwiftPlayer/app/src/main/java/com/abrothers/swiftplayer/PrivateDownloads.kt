package com.abrothers.swiftplayer

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

internal object PrivateDownloads {
    fun target(folder: File, name: String): File {
        require(name.isNotBlank() && name !in listOf(".","..") && name.none { it=='/' || it=='\\' || it.isISOControl() }) { "Invalid download filename" }
        check(folder.isDirectory || folder.mkdirs()) { "App data folder is unavailable" }
        return File(folder,name)
    }
    fun fetch(url:String, target:File, limit:Long, progress:(Long,Long)->Unit={_,_->}, validate:(File)->Unit={}) {
        require(URL(url).protocol=="https") { "Invalid download URL" }
        val part=File.createTempFile("transfer-", ".part.${target.extension}", target.parentFile!!)
        val connection=URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout=10000; connection.readTimeout=10000; connection.useCaches=false
        connection.setRequestProperty("Accept-Encoding","identity")
        val start=android.os.SystemClock.elapsedRealtime()
        try {
            require(connection.responseCode==200 && connection.url.protocol=="https") { "Download failed (HTTP ${connection.responseCode})" }
            val total=connection.contentLengthLong
            require(total<=limit) { "Download is too large" }
            var received=0L
            connection.inputStream.use { input -> part.outputStream().use { output ->
                val buffer=ByteArray(65536)
                while(true) {
                    check(!Thread.currentThread().isInterrupted && android.os.SystemClock.elapsedRealtime()-start < 180000) { "Download cancelled or timed out" }
                    val count=input.read(buffer);if(count<0)break
                    received+=count;require(received<=limit) { "Download is too large" };output.write(buffer,0,count);progress(received,total)
                }
            } }
            require(received>0 && (total<0 || received==total)) { "Download is incomplete" }
            validate(part)
            check(part.renameTo(target)) { "Could not save download in app storage" }
        } finally { connection.disconnect();part.delete() }
    }
}
