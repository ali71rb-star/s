package com.abrothers.swiftplayer

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.media.audiofx.LoudnessEnhancer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.*
import android.view.SurfaceHolder

class PlaybackService : Service() {
    inner class LocalBinder : Binder() { val service get() = this@PlaybackService }
    private val binder = LocalBinder()
    private lateinit var prefs: PlayerPrefs
    private lateinit var repo: MediaRepository
    private lateinit var audio: AudioManager
    private lateinit var session: MediaSession
    private var focus: AudioFocusRequest? = null
    private var enhancer: LoudnessEnhancer? = null
    private var media: PlaybackEngine? = null
    internal var engineFactory: ((Boolean,String) -> PlaybackEngine)? = null
    private var surface: SurfaceHolder? = null
    private val handler = Handler(Looper.getMainLooper())
    private var prepared = false
    private var waiting = false
    private var completed=false
    private var pendingPosition=0
    val isPrepared get()=prepared
    val canSeek get()=prepared && duration>0 && (media?.seekable ?: false)
    private val resumeWorker=java.util.concurrent.Executors.newSingleThreadExecutor()
    private var playWhenReady = true
    private var generation = 0
    private var resumeAfterFocus = false
    private var foreground = false
    var queue: List<MediaEntry> = emptyList(); private set
    var pendingQueue: List<MediaEntry>? = null
    var index = 0; private set
    val current get() = queue.getOrNull(index)
    val isPlaying get() = prepared && runCatching { media?.isPlaying == true }.getOrDefault(false)
    val position get() = if (prepared) runCatching { media?.currentPosition ?: 0 }.getOrDefault(0) else pendingPosition
    val duration get() = if (prepared) runCatching { media?.duration ?: 0 }.getOrDefault(0) else 0
    var speed: Float = 1f; private set
    var boost = 0; private set
    var sleepActive = false; private set
    private var sleepTarget: Long? = null
    var message: String = ""; private set
    var onChange: (() -> Unit)? = null
    private var lastSavedQueue: List<MediaEntry>? = null
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeAfterFocus = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { resumeAfterFocus = isPlaying; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> runCatching { media?.setVolume(0.2f, 0.2f) }
            AudioManager.AUDIOFOCUS_GAIN -> {
                runCatching { media?.setVolume(1f, 1f) }
                if (resumeAfterFocus) { resumeAfterFocus = false; resume() }
            }
        }
    }
    private val deviceRoutes=object:AudioDeviceCallback() {
        override fun onAudioDevicesAdded(devices:Array<out AudioDeviceInfo>) { if(::prefs.isInitialized && prefs.bool("bypass",false))applyRouting() }
        override fun onAudioDevicesRemoved(devices:Array<out AudioDeviceInfo>) { if(::prefs.isInitialized && prefs.bool("bypass",false))applyRouting() }
    }
    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pause() }
    }
    private val tick = object : Runnable {
        var cycles = 0
        override fun run() {
            if (sleepActive) {
                if (sleepTarget == null && prepared) sleepTarget = position.toLong() + prefs.long("sleepDuration")
                if (prepared && sleepTarget != null && position >= sleepTarget!!) {
                    sleepActive = false; sleepTarget = null; pause(); message = "Sleep timer finished"; changed()
                }
            }
            if (++cycles >= 1) { cycles = 0; save() }
            handler.postDelayed(this, 1000)
        }
    }
    override fun onCreate() {
        super.onCreate()
        prefs = PlayerPrefs(this); repo = MediaRepository(this)
        speed = prefs.speed
        audio = getSystemService(AudioManager::class.java)
        audio.registerAudioDeviceCallback(deviceRoutes,handler)
        session = MediaSession(this, "Swift Player Created by A brothers")
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { ApkTester.used(this@PlaybackService,"Notification: Play"); resume() }
            override fun onPause() { ApkTester.used(this@PlaybackService,"Notification: Pause"); pause() }
            override fun onSkipToNext() { ApkTester.used(this@PlaybackService,"Notification: Next"); next() }
            override fun onSkipToPrevious() { ApkTester.used(this@PlaybackService,"Notification: Previous"); previous() }
            override fun onSeekTo(pos: Long) = seek(pos)
            override fun onStop() = closePlayback()
            override fun onCustomAction(action:String, extras:Bundle?) {
                when(action) {
                    STOP -> { ApkTester.used(this@PlaybackService,"Notification: Stop"); closePlayback() }
                    REWIND -> { ApkTester.used(this@PlaybackService,"Notification: Rewind"); rewind() }
                    FORWARD -> { ApkTester.used(this@PlaybackService,"Notification: Fast Forward"); fastForward() }
                }
            }
        })
        session.isActive = true
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Swift Player Playback", NotificationManager.IMPORTANCE_LOW))
            focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setOnAudioFocusChangeListener(focusListener).build()
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        handler.post(tick)
    }
    override fun onBind(intent: Intent?) = binder
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            LOAD -> {
                val items = pendingQueue ?: MediaEntry.decode(intent.getStringExtra("queue") ?: prefs.str("pendingQueue", "[]"))
                pendingQueue = null
                if (items.isNotEmpty()) {
                    queue = items; index = intent.getIntExtra("index", 0).coerceIn(0, items.lastIndex)
                    ensureForeground()
                    load(intent.getIntExtra("position", 0))
                } else stopSelf(startId)
            }
            TOGGLE -> { ApkTester.used(this,"Notification: Pause or Play"); if (isPlaying) pause() else resume() }
            NEXT -> { ApkTester.used(this,"Notification: Next"); next() }
            PREV -> { ApkTester.used(this,"Notification: Previous"); previous() }
            REWIND -> { ApkTester.used(this,"Notification: Rewind"); rewind() }
            FORWARD -> { ApkTester.used(this,"Notification: Fast Forward"); fastForward() }
            STOP -> { ApkTester.used(this,"Notification: Stop"); closePlayback() }
        }
        return START_NOT_STICKY
    }
    private fun releaseMedia() {
        prepared = false
        runCatching { enhancer?.release() }; enhancer = null
        runCatching { media?.release() }; media = null
    }
    private fun load(startAt: Int = 0, autoStart: Boolean = true, fallback: Boolean = false) {
        val item = current ?: return
        ++generation; val mine = generation
        releaseMedia();completed=false;pendingPosition=startAt; waiting = true; playWhenReady = autoStart; message = ""; sleepTarget = null
        val software=fallback
        val channel = if (prefs.bool("bypass",false)) prefs.str("bypassChannel","media") else "media"
        try {
            val engine: PlaybackEngine = engineFactory?.invoke(software,channel) ?: if (fallback) NativePlaybackEngine(this,channel) else Media3PlaybackEngine(this,channel)
            media=engine
            runCatching { engine.setDisplay(surface) }
            val location=if(item.resumeLocation.isNotEmpty() && java.io.File(item.resumeLocation).isFile) item.resumeLocation else item.location
            engine.open(repo.asUri(location), {
                if (mine == generation) {
                    prepared=true; waiting=false; message=""
                    runCatching { engine.setDisplay(surface) }
                    if (startAt>0) engine.seekTo(startAt)
                    setSpeed(speed); applyBoost(); applyRouting()
                    if (playWhenReady) resume() else pause()
                    save(); changed()
                    if(item.resumeLocation.isEmpty() && item.location.startsWith("content:")) resumeWorker.submit {
                        runCatching { repo.saveResumeCopy(item) }.onSuccess { saved ->
                            if(saved!=item) {
                                // Keep a complete copy reference even if Activity/Service teardown removed main-thread callbacks.
                                val stored=MediaEntry.decode(prefs.str("queue","[]"))
                                prefs.raw.edit().putString("queue",MediaEntry.encode(stored.map { if(it.location==item.location)saved else it })).commit()
                                handler.post { queue=queue.map { if(it.location==item.location) saved else it };save(true) }
                            }
                        }
                    }
                }
            }, {
                if (mine == generation) {
                    save()
                    if (prefs.bool("autoPlay") && index < queue.lastIndex) { index++; ensureForeground(); load() }
                    else { completed=true;pause();sleepActive=false;sleepTarget=null;changed() }
                }
            }, { detail ->
                if (mine == generation) {
                    if (!software) handler.post { if (mine == generation) load(startAt,playWhenReady,true) }
                    else fail("Playback error: $detail")
                }
            })
        } catch (e: Exception) {
            if (!software) load(startAt,autoStart,true) else fail("${e.javaClass.simpleName}: ${e.message}")
        }
        changed()
    }
    fun reloadAudioChannel() {
        if (current != null && prepared) { val at=position; val playing=isPlaying; load(at,playing) }
        else applyRouting()
    }
    private fun fail(text: String) {
        AppLog.record(this,"Playback",IllegalStateException(text))
        waiting = false; message = text; releaseMedia()
        stopForegroundCompat(true); foreground = false
        abandonFocus(); changed()
    }
    private fun requestFocus(): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= 26) audio.requestAudioFocus(focus!!) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        else @Suppress("DEPRECATION") (audio.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
    }.getOrDefault(false)
    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) focus?.let { audio.abandonAudioFocusRequest(it) }
        else @Suppress("DEPRECATION") audio.abandonAudioFocus(focusListener)
    }
    fun resume() {
        if(current==null) {
            queue=MediaEntry.decode(prefs.str("queue","[]"))
            if(queue.isNotEmpty())index=prefs.long("queueIndex").toInt().coerceIn(0,queue.lastIndex)
            pendingPosition=prefs.long("lastPosition").coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
        playWhenReady = true
        if (!prepared) {
            if (!waiting && current != null) { ensureForeground(); load(pendingPosition) }
            return
        }
        if(completed) {
            completed=false;pendingPosition=0
            ensureForeground();load(0,true);return
        }
        ensureForeground()
        if (!requestFocus()) { runCatching { media?.pause() }; message = "Audio focus unavailable; try Play again"; stopForegroundCompat(false); foreground = false; changed(); return }
        try {
            media?.setVolume(1f,1f); media?.start(); setSpeed(speed); message = ""; notifyState(); changed()
        } catch (e: Exception) { fail(e.message ?: "Cannot play") }
    }
    fun pause() {
        playWhenReady = false
        if (prepared) runCatching { media?.pause() }
        save(true); abandonFocus(); notifyState()
        if (foreground) { stopForegroundCompat(false); foreground = false }
        changed()
    }
    fun toggle() { if (isPlaying) pause() else resume() }
    fun seek(value: Long) {
        if (canSeek) {
            completed=false
            pendingPosition=value.coerceIn(0,duration.toLong()).toInt()
            runCatching { media?.seekTo(pendingPosition) }.onFailure { message="This media source does not support seeking" }
        }
        save(); notifyState()
    }
    fun rewind() { seek(position.toLong() - prefs.ff) }
    fun fastForward() { seek(position.toLong() + prefs.ff) }
    fun next() { if (index < queue.lastIndex) { save(); index++; ensureForeground(); load() } else { message = "Last file"; changed() } }
    fun previous() { if (index > 0) { save(); index--; ensureForeground(); load() } else { message = "First file"; changed() } }
    fun setSurface(holder: SurfaceHolder?) { surface = holder; if (prepared) runCatching { media?.setDisplay(holder) } }
    /** Saves the resume position, releases audio and stops foreground, without clearing the saved queue. */
    fun saveAndStop() {
        save(true); playWhenReady = false
        if (prepared) runCatching { media?.pause() }
        ++generation; releaseMedia(); abandonFocus()
        stopForegroundCompat(true); foreground = false
        runCatching { getSystemService(NotificationManager::class.java).cancel(ID) }
        runCatching { session.isActive = false }
        changed(); stopSelf()
    }
    fun setSpeed(value: Float) {
        speed = value; prefs.speed = value
        if (prepared) runCatching {
            val wasPlaying = isPlaying
            media?.playbackSpeed = value
            if (!wasPlaying) media?.pause()
        }.onFailure { message = "Speed not supported by this file/device" }
        notifyState();changed()
    }
    fun cycleBoost() { boost = (boost + 1) % 4; applyBoost(); changed() }
    private fun applyBoost() {
        if (!prepared) return
        if ((media?.audioSessionId ?: -1) < 0) { media?.softwareBoost(boost); return }
        runCatching {
            if (enhancer == null) enhancer = LoudnessEnhancer(media!!.audioSessionId)
            enhancer?.setTargetGain(intArrayOf(0, 1200, 2500, 4000)[boost])
            enhancer?.enabled = boost != 0
        }.onFailure { message = "Volume boost is not available on this device" }
    }
    /** Best-effort media device preference; never claims control over another app's speech. */
    fun applyRouting(): String {
        if (!prefs.bool("bypass", false)) {
            runCatching { media?.setPreferredDevice(null) }
            return "Bluetooth Bypass off"
        }
        return runCatching {
            val target = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || (Build.VERSION.SDK_INT >= 31 &&
                    (it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER))
            } ?: return "Bluetooth Bypass saved. No Bluetooth media device is connected."
            val accepted = media?.setPreferredDevice(target) == true
            if (accepted) "Bluetooth media preference requested. Screen-reader speech output must be set in the screen reader itself."
            else "Bluetooth Bypass saved. Android has not confirmed a playback device yet."
        }.getOrElse { "Bluetooth Bypass unavailable: ${it.message}" }
    }
    /** Pause/release just the current decoder before deleting its file. Keep queue/index and player UI. */
    fun suspendForDeletion() {
        save(); ++generation; waiting = false; releaseMedia()
    }
    fun removeDeleted(deleted: List<MediaEntry>) {
        val before = queue; val oldIndex = index; val old = current
        val locations = deleted.map { it.location }.toSet()
        fun removed(e: MediaEntry) = e.location in locations || deleted.any {
            it.directory && e.diskPath.ifEmpty { e.location }.startsWith(it.location.trimEnd('/') + "/")
        }
        queue = before.filterNot(::removed)
        if (queue.isEmpty()) {
            ++generation; releaseMedia(); index = 0; waiting = false
            prefs.put("queue", "[]"); prefs.put("lastPosition", 0L)
            message = "No more files in this playlist"; stopForegroundCompat(true); foreground = false; changed(); return
        }
        if (old != null && removed(old)) {
            // Prefer the following surviving entry; fall back to the preceding file at playlist end.
            val following = before.drop(oldIndex + 1).firstOrNull { !removed(it) }
            index = if (following != null) queue.indexOfFirst { it.location == following.location } else queue.lastIndex
            prefs.put("lastPosition", 0L); ensureForeground(); load()
        } else {
            index = queue.indexOfFirst { it.location == old?.location }.coerceAtLeast(0)
            save(); changed()
        }
    }
    fun setSleep(enabled: Boolean) {
        sleepActive = enabled
        sleepTarget = if (enabled && prepared) position.toLong() + prefs.long("sleepDuration") else null
        changed()
    }
    fun replaceEntry(old: MediaEntry, replacement: MediaEntry) {
        val pos = position; val playing = isPlaying
        queue = queue.map { if (it.location == old.location) replacement else it }
        if (current?.location == replacement.location) {
            ensureForeground(); load(pos, playing)
        }
        save(); changed()
    }
    /** Points a queue entry at its new location (after Move) and restores the given position and play state. */
    fun replaceEntryAt(old: MediaEntry, replacement: MediaEntry, pos: Int, playing: Boolean) {
        queue = queue.map { if (it.location == old.location) replacement else it }
        if (current?.location == replacement.location) {
            ensureForeground(); load(pos, playing)
        }
        save(); changed()
    }
    fun contains(entry: MediaEntry): Boolean = current?.let {
        it.location == entry.location || (entry.directory && (it.diskPath.ifEmpty { it.location }).startsWith(entry.location.trimEnd('/') + "/"))
    } ?: false
    fun stopForDeletion() { closePlayback() }
    @Synchronized fun save(synchronous:Boolean=false) {
        if(queue.isEmpty()) return
        val edit=prefs.raw.edit().putLong("queueIndex",index.toLong())
        if(lastSavedQueue !== queue) { edit.putString("queue",MediaEntry.encode(queue));lastSavedQueue=queue }
        if(prepared) edit.putLong("lastPosition",position.toLong())
        if(synchronous) edit.commit() else edit.apply()
    }
    fun closePlayback() {
        saveAndStop()
        queue=emptyList();index=0;surface=null;waiting=false
        session.setPlaybackState(PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED,0L,0f).build())
        session.setMetadata(null);changed()
    }
    private fun changed() { onChange?.invoke() }
    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("showPlayer", true), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun action(code: Int, name: String, text: String) = Notification.Action.Builder(when(name) {
            PREV -> android.R.drawable.ic_media_previous
            NEXT -> android.R.drawable.ic_media_next
            REWIND -> android.R.drawable.ic_media_rew
            FORWARD -> android.R.drawable.ic_media_ff
            STOP -> android.R.drawable.ic_menu_close_clear_cancel
            else -> if(isPlaying)android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        }, text,
            PendingIntent.getService(this, code, Intent(this, PlaybackService::class.java).setAction(name), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)).build()
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(R.drawable.ic_notification).setContentTitle(current?.name ?: "Swift Player")
            .setContentText("").setContentIntent(open).setOngoing(isPlaying || waiting)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOnlyAlertOnce(true)
            .addAction(action(1, PREV, "Previous")).addAction(action(5, REWIND, "Rewind ${prefs.ff / 1000} seconds"))
            .addAction(action(2, TOGGLE, if (isPlaying) "Pause" else "Play"))
            .addAction(action(6, FORWARD, "Fast Forward ${prefs.ff / 1000} seconds")).addAction(action(3, NEXT, "Next"))
            .addAction(action(4, STOP, "Stop"))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 2, 4)).build()
    }
    private fun stopForegroundCompat(remove: Boolean) {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(if (remove) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        else @Suppress("DEPRECATION") stopForeground(remove)
    }
    private fun ensureForeground() {
        session.isActive = true
        val n = notification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(ID, n)
        foreground = true
    }
    private fun notifyState() {
        if (!::session.isInitialized) return
        val state = if (isPlaying) PlaybackState.STATE_PLAYING else if (waiting) PlaybackState.STATE_BUFFERING else PlaybackState.STATE_PAUSED
        val playback=PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP)
            .setState(state,position.toLong(),if(isPlaying)speed else 0f)
        if(current!=null) {
            playback.addCustomAction(REWIND,"Rewind ${prefs.ff / 1000} seconds",android.R.drawable.ic_media_rew)
            playback.addCustomAction(FORWARD,"Fast Forward ${prefs.ff / 1000} seconds",android.R.drawable.ic_media_ff)
        }
        if(Build.VERSION.SDK_INT>=33 && current!=null)playback.addCustomAction(STOP,"Stop",android.R.drawable.ic_menu_close_clear_cancel)
        session.setPlaybackState(playback.build())
        session.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, current?.name ?: "Swift Player")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "A Brothers").putLong(MediaMetadata.METADATA_KEY_DURATION, duration.toLong()).build())
        if (current != null) getSystemService(NotificationManager::class.java).notify(ID, notification())
    }
    override fun onTaskRemoved(rootIntent: Intent?) {
        save(true); if (!prefs.bool("background")) { pause(); stopSelf() }; super.onTaskRemoved(rootIntent)
    }
    override fun onDestroy() {
        save(true); ++generation; handler.removeCallbacksAndMessages(null); releaseMedia(); abandonFocus()
        resumeWorker.shutdown();repo.close()
        runCatching { unregisterReceiver(noisy) };audio.unregisterAudioDeviceCallback(deviceRoutes);session.release();onChange=null
        super.onDestroy()
    }
    companion object {
        const val CHANNEL = "smart_player_playback"
        const val ID = 9923
        const val LOAD = "com.abrothers.swiftplayer.LOAD"
        const val TOGGLE = "com.abrothers.swiftplayer.TOGGLE"
        const val NEXT = "com.abrothers.swiftplayer.NEXT"
        const val PREV = "com.abrothers.swiftplayer.PREV"
        const val STOP = "com.abrothers.swiftplayer.STOP"
        const val REWIND = "com.abrothers.swiftplayer.REWIND"
        const val FORWARD = "com.abrothers.swiftplayer.FORWARD"
    }
}
