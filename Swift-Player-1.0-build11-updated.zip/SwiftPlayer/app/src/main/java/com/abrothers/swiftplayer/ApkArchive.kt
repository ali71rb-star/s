package com.abrothers.swiftplayer

import java.io.File
import java.util.zip.ZipFile

/** No repairs/repacking: changing a signed APK archive invalidates its signature. */
object ApkArchive {
    fun validate(file:File) {
        require(file.isFile && file.length()>100) { "APK download is empty or incomplete. Download again." }
        val prefix=file.inputStream().use { input -> val b=ByteArray(160);val n=input.read(b);String(b,0,n.coerceAtLeast(0),Charsets.US_ASCII).trimStart() }
        require(!prefix.startsWith("<") && !prefix.startsWith("<!") && !prefix.startsWith("version https://git-lfs.github.com/spec/")) {
            "The repository returned a web page or Git LFS pointer instead of an APK. Upload the original APK binary."
        }
        try {
            ZipFile(file).use { zip ->
                val manifest=zip.getEntry("AndroidManifest.xml") ?: error("APK is missing AndroidManifest.xml. Upload the original signed release APK.")
                require(manifest.size in 8..2_000_000) { "APK manifest is damaged or incomplete." }
                val header=zip.getInputStream(manifest).use { input -> val bytes=ByteArray(8);var n=0;while(n<8) { val count=input.read(bytes,n,8-n);if(count<0)break;n+=count };bytes }
                require(header[0]==3.toByte() && header[1]==0.toByte()) { "APK does not contain a compiled Android manifest. Upload the signed APK produced by the build." }
                require(zip.getEntry("classes.dex")!=null) { "APK contains no application code. Upload the full application APK, not a split or archive." }
            }
        } catch(e:java.util.zip.ZipException) {
            throw IllegalArgumentException("The APK stored in GitHub is damaged or has an invalid ZIP structure. Replace it with the original signed APK; changing version.txt alone cannot fix it.",e)
        }
    }
}
