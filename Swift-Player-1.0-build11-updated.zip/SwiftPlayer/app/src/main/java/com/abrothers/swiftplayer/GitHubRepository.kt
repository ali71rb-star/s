package com.abrothers.swiftplayer

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Pin metadata and APK to one immutable commit, avoiding raw-CDN branch cache races. */
object GitHubRepository {
    const val OWNER="ali71rb-star"
    const val NAME="-.-Swift-Player-created-by-A-brothers"
    const val API="https://api.github.com/repos/$OWNER/$NAME"
    data class Entry(val path:String,val sha:String)
    data class Candidate(val path:String,val url:String,val sha:String)
    data class Snapshot(val release:UpdateVersion.Release,val changes:String,val fingerprint:String,val apk:Candidate)
    internal var transport:((String,Boolean)->String?)?=null
    fun read(url:String,optional:Boolean=false):String? {
        transport?.let { return it(url,optional) }
        val suffix=if(url.contains('?'))"&" else "?"
        val fresh=if(url.startsWith(API))url+suffix+"swift_refresh="+System.currentTimeMillis() else url
        val connection=URL(fresh).openConnection() as HttpURLConnection
        connection.useCaches=false;connection.connectTimeout=15000;connection.readTimeout=15000
        connection.setRequestProperty("User-Agent","Swift-Player-Android")
        connection.setRequestProperty("Accept",if(url.startsWith(API))"application/vnd.github+json" else "text/plain")
        connection.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0")
        connection.setRequestProperty("Pragma","no-cache")
        try {
            val status=connection.responseCode
            if(optional && status==404)return null
            require(status==200) { if(status==403 || status==429)"GitHub request limit reached. Please try again later." else "Repository returned HTTP $status" }
            return connection.inputStream.bufferedReader().use { reader ->
                val out=StringBuilder();val buffer=CharArray(8192)
                while(true) { val n=reader.read(buffer);if(n<0)break;require(out.length+n<=4_000_000) { "Repository listing is too large" };out.append(buffer,0,n) }
                out.toString()
            }
        } finally { connection.disconnect() }
    }
    private fun escape(path:String)=path.split('/').joinToString("/") { java.net.URLEncoder.encode(it,"UTF-8").replace("+","%20") }
    fun raw(branch:String,path:String)="https://raw.githubusercontent.com/$OWNER/$NAME/${escape(branch)}/${escape(path)}"
    fun selectMetadata(entries:List<Entry>,filename:String):Entry?=entries.filter { it.path.substringAfterLast('/').equals(filename,true) }.minWithOrNull(compareBy<Entry> { it.path.count { c->c=='/' } }.thenBy { it.path })
    fun revision(versionSha:String,changelogSha:String)=versionSha+":"+changelogSha
    private fun blob(entry:Entry,commit:String):String {
        // Small text files come from their exact git blob instead of a potentially stale branch URL.
        return runCatching {
            val value=JSONObject(read("$API/git/blobs/${entry.sha}")!!)
            check(value.getString("encoding")=="base64") { "Unsupported metadata encoding" }
            String(android.util.Base64.decode(value.getString("content"),android.util.Base64.DEFAULT),Charsets.UTF_8)
        }.getOrElse { read(raw(commit,entry.path)) ?: throw it }
    }
    fun discover():Snapshot {
        val repo=JSONObject(read(API)!!)
        val branch=repo.getString("default_branch")
        val head=JSONObject(read("$API/branches/${escape(branch)}")!!).getJSONObject("commit")
        val commit=head.getString("sha")
        val treeSha=head.getJSONObject("commit").getJSONObject("tree").getString("sha")
        val tree=JSONObject(read("$API/git/trees/$treeSha?recursive=1")!!)
        require(!tree.optBoolean("truncated")) { "Repository tree is truncated; keep release files in a smaller update repository" }
        val items=tree.getJSONArray("tree")
        val entries=(0 until items.length()).map { items.getJSONObject(it) }.filter { it.optString("type")=="blob" }.map { Entry(it.getString("path"),it.getString("sha")) }
        val version=selectMetadata(entries,"version.txt") ?: error("version.txt was not found in this repository")
        val news=selectMetadata(entries,"whatsnew.txt")
        val release=UpdateVersion.parse(blob(version,commit))
        val changes=news?.let { runCatching { blob(it,commit) }.getOrDefault("") }.orEmpty()
        val apks=entries.filter { it.path.endsWith(".apk",true) }
        require(apks.isNotEmpty()) { "No APK file exists in this repository" }
        require(apks.size<=30) { "More than 30 APKs found; keep only current release APKs in this repository" }
        val newest=if(apks.size==1)apks.first() else apks.map { apk ->
            val commits=JSONArray(read("$API/commits?path=${java.net.URLEncoder.encode(apk.path,"UTF-8")}&per_page=1&sha=$commit")!!)
            val date=if(commits.length()>0)commits.getJSONObject(0).getJSONObject("commit").getJSONObject("committer").getString("date") else ""
            apk to date
        }.sortedWith(compareByDescending<Pair<Entry,String>> { it.second }.thenBy { it.first.path }).first().first
        return Snapshot(release,changes,revision(version.sha,news?.sha.orEmpty()),Candidate(newest.path,raw(commit,newest.path),newest.sha))
    }
    fun shouldOffer(snapshot:Snapshot,installedCode:Long,installedName:String,lastRevision:String,installedBlob:String):Boolean=UpdateVersion.newer(snapshot.release,installedCode,installedName)
    fun gitBlob(file:java.io.File):String {
        val digest=MessageDigest.getInstance("SHA-1")
        digest.update("blob ${file.length()}\u0000".toByteArray(Charsets.UTF_8))
        file.inputStream().use { input -> val b=ByteArray(65536);while(true) { val n=input.read(b);if(n<0)break;digest.update(b,0,n) } }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
