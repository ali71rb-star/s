package com.abrothers.swiftplayer

import android.app.Application
import android.content.Context

/** The APK Tester checkbox state. Errors are handed to the manual APK Tester record only while it is on. */
object AppLog {
    fun enabled(context:Context)=PlayerPrefs(context).bool("appLog",false)
    fun enable(context:Context,value:Boolean) { PlayerPrefs(context).put("appLog",value) }
    fun record(context:Context,area:String,error:Throwable) { ApkTester.problem(context,area,error) }
}

class SwiftApplication:Application() {
    override fun onCreate() {
        super.onCreate()
        val previous=Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread,error ->
            AppLog.record(this,"Uncaught exception on ${thread.name}",error)
            if(previous!=null)previous.uncaughtException(thread,error)
            else { android.os.Process.killProcess(android.os.Process.myPid());kotlin.system.exitProcess(1) }
        }
    }
}
