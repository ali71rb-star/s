package com.abrothers.swiftplayer

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.widget.ImageView
import java.io.File
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** AES-GCM deters casual extraction. Offline client keys are recoverable; this is NOT DRM or an anti-analysis system. */
object ProtectedAssets {
    private fun key():ByteArray {
        val a=byteArrayOf(-78,-10,30,-33,-96,24,89,-89,-4,23,62,94,-52,112,-102,70,-37,93,-78,-3,49,-45,-13,-109,52,-80,-93,1,72,-33,-77,103)
        val b=byteArrayOf(86,27,-117,-107,-114,-36,-108,-2,41,13,-29,-107,12,91,30,12,-99,-69,24,-30,-76,-13,65,-59,10,107,-116,-46,35,-55,-53,49)
        return ByteArray(a.size) { i -> (a[i].toInt() xor b[i].toInt()).toByte() }
    }
    fun bytes(context:Context,id:String):ByteArray {
        require(id in setOf("g","s","e"))
        val data=context.assets.open("protected/$id.bin").use { it.readBytes() }
        require(String(data,0,5,Charsets.US_ASCII)=="SWFT1")
        val raw=key()
        try {
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE,SecretKeySpec(raw,"AES"),GCMParameterSpec(128,data.copyOfRange(5,17)))
            cipher.updateAAD(id.toByteArray())
            return cipher.doFinal(data.copyOfRange(17,data.size))
        } finally { raw.fill(0) }
    }
    fun image(context:Context,view:ImageView) {
        val raw=bytes(context,"g")
        try {
            val bitmap=BitmapFactory.decodeByteArray(raw,0,raw.size) ?: error("Startup image cannot be decoded")
            view.setImageBitmap(bitmap)
        } finally { raw.fill(0) }
    }
    fun sound(context:Context,id:String,done:()->Unit):MediaPlayer? {
        var file:File?=null
        var player:MediaPlayer?=null
        return try {
            file=File.createTempFile("cue-",".aac",context.cacheDir)
            val raw=bytes(context,id)
            try { file.writeBytes(raw) } finally { raw.fill(0) }
            val cue=MediaPlayer();player=cue
            cue.setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            file.inputStream().use { cue.setDataSource(it.fd) }
            file.delete()
            cue.setOnPreparedListener { it.start() }
            cue.setOnCompletionListener { it.release();done() }
            cue.setOnErrorListener { mp,_,_->mp.release();done();true }
            cue.prepareAsync();cue
        } catch(e:Exception) {
            AppLog.record(context,"Startup/Exit asset playback",e)
            runCatching { player?.release() };file?.delete();done();null
        }
    }
}
