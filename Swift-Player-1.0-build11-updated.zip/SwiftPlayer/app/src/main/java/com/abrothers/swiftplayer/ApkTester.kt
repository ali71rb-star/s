package com.abrothers.swiftplayer

import android.content.Context
import android.os.Build
import android.os.SystemClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * APK Tester: a manual testing record. While the checkbox is on, every button, option and setting the user
 * actually uses is written to a private local file together with any error it caused. Nothing is tested
 * automatically and nothing is uploaded. Errors are saved in plain words.
 */
object ApkTester {
    private val lock = Any()
    private const val RECORD = "apk-tester-record.txt"
    private const val MAX_BYTES = 200_000L
    @Volatile private var lastFeature = ""
    @Volatile private var lastAt = 0L
    data class Item(val time: String, val kind: String, val feature: String, val text: String)

    private fun stamp() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    private fun flat(value: String) = value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()
    private fun recordFile(context: Context) = File(context.filesDir, RECORD)

    private fun append(context: Context, kind: String, feature: String, text: String) {
        runCatching { synchronized(lock) {
            val file = recordFile(context)
            file.appendText("${stamp()}\t$kind\t${flat(feature)}\t${flat(text)}\n")
            if (file.length() > MAX_BYTES) file.writeText(file.readLines().takeLast(1500).joinToString("\n", postfix = "\n"))
        } }
    }
    /** The user used a button, option or setting. Does nothing unless the APK Tester checkbox is on. */
    fun used(context: Context, feature: String) {
        if (feature.isBlank() || !AppLog.enabled(context)) return
        lastFeature = feature; lastAt = SystemClock.elapsedRealtime()
        append(context, "U", feature, "")
    }
    /** An error happened. It is saved in simple words next to the feature the user was just testing. */
    fun problem(context: Context, area: String, error: Throwable) {
        if (!AppLog.enabled(context)) return
        val recent = lastFeature.isNotEmpty() && SystemClock.elapsedRealtime() - lastAt < 30_000
        val feature = if (area.startsWith("Uncaught")) "App stopped suddenly" else if (recent) lastFeature else friendlyArea(area)
        append(context, "P", feature, explain(area, error))
    }
    fun clear(context: Context) {
        synchronized(lock) { recordFile(context).delete() }
        lastFeature = ""; lastAt = 0L
    }
    fun hasRecords(context: Context) = synchronized(lock) { recordFile(context).let { it.isFile && it.length() > 0 } }

    private fun friendlyArea(area: String) = when {
        area.startsWith("Delete") -> "Delete"
        area.startsWith("Rename") -> "Rename"
        area.startsWith("Playback") -> "Playing a file"
        area.startsWith("Startup") -> "Opening the app"
        else -> "Using the app"
    }
    /** Plain-words description for people who do not know anything about apps or errors. */
    fun explain(area: String, error: Throwable): String {
        val message = error.message.orEmpty()
        val plain = when {
            area.startsWith("Uncaught") -> "The app stopped working suddenly. Please tell the developer what you were doing just before this happened."
            error is DuplicateNameException -> "A file with this name is already in this folder. Please choose a different name."
            error is SecurityException && message.contains("read-only", true) -> "This file can only be read. It can be changed only in the app that gave it to Swift Player."
            error is SecurityException || message.contains("permission", true) || message.contains("All Files Access", true) ->
                "Android did not allow this action. Open Permission Manager in Settings and allow access, or change the file in the app that owns it."
            error is java.io.FileNotFoundException -> "The file could not be found. It may have been moved or deleted, or the memory card or USB drive was removed."
            error is java.net.UnknownHostException || error is java.net.SocketTimeoutException || error is java.net.ConnectException || message.contains("HTTP") ->
                "The internet did not work. Please check your internet connection and try again."
            error is OutOfMemoryError -> "The phone ran out of memory. Close other apps and try again."
            message.contains("space", true) || message.contains("ENOSPC") -> "There is not enough free space on the phone, memory card or USB drive."
            message.contains("Playback", true) || message.contains("decoder", true) || message.contains("codec", true) ->
                "This file could not be played. The file may be damaged, or this phone may not support its format."
            message.contains("Rename failed", true) -> "The file could not be renamed. Please check the permission and try again."
            error is java.io.IOException -> "The phone could not read or write the file. Check that the storage is connected and has free space."
            else -> "Something went wrong while using this feature. Please tell the developer which button you pressed."
        }
        return "$plain (Error type: ${error.javaClass.simpleName.ifBlank { "Error" }})"
    }

    fun items(context: Context): List<Item> = synchronized(lock) {
        val file = recordFile(context)
        if (!file.isFile) emptyList() else file.readLines().mapNotNull { line ->
            val parts = line.split('\t')
            if (parts.size >= 3) Item(parts[0], parts[1], parts[2], parts.getOrElse(3) { "" }) else null
        }
    }
    fun reportText(context: Context): String {
        val all = items(context)
        val out = StringBuilder()
        out.append("APK TESTER REPORT\n")
        out.append("App: ${context.getString(R.string.app_name)}\nVersion: ${BuildConfig.VERSION_NAME}\n")
        out.append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        out.append("Report created: ${stamp()}\n\n")
        out.append("This report has only the buttons, options and settings that were used by hand while the APK Tester checkbox was on.\n\n")
        val uses = all.filter { it.kind == "U" }
        val problems = all.filter { it.kind == "P" }
        out.append("FEATURES TESTED\n")
        if (uses.isEmpty() && problems.isEmpty()) out.append("Nothing was recorded yet. Turn the checkbox on, use the player buttons and options one by one, then share the report.\n")
        val counts = linkedMapOf<String, Int>()
        uses.forEach { counts[it.feature] = (counts[it.feature] ?: 0) + 1 }
        val broken = problems.map { it.feature }.toSet()
        counts.entries.forEachIndexed { index, e ->
            out.append("${index + 1}. ${e.key} - used ${e.value} time${if (e.value == 1) "" else "s"} - ${if (e.key in broken) "PROBLEM FOUND" else "No error seen"}\n")
        }
        out.append("\nPROBLEMS FOUND\n")
        if (problems.isEmpty()) out.append("No error was recorded for the features you tested.\n")
        problems.forEachIndexed { index, p ->
            out.append("${index + 1}. ${p.feature} (${p.time})\n   What went wrong: ${p.text}\n")
        }
        return out.toString()
    }
    /** Writes the report to a private file so it can be shared. Only the five newest reports are kept. */
    fun reportFile(context: Context): File {
        val folder = File(context.filesDir, "tester-reports").apply { mkdirs() }
        val file = File(folder, "Swift-Player-APK-Tester-${System.currentTimeMillis()}.txt")
        file.writeText(reportText(context))
        folder.listFiles()?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
        return file
    }
}
